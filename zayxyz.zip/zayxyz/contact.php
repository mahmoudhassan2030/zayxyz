<?php
/**
 * Template Name: Contact Page
 * Description: Enhanced contact page template with interactive map and form
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'contact_form_submit') {
    // تحقق من nonce
    if (!isset($_POST['contact_nonce']) || !wp_verify_nonce($_POST['contact_nonce'], 'contact_form_nonce')) {
        wp_die('Security check failed');
    }

    // معالجة البيانات (مثال: إرسال بريد)
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $subject = sanitize_text_field($_POST['subject']);
    $message = sanitize_textarea_field($_POST['message']);

    $to = get_option('admin_email');
    $headers = ['Content-Type: text/html; charset=UTF-8', "From: $name <$email>"];
    $body = "Name: $name<br>Email: $email<br>Phone: $phone<br>Message: $message";

    wp_mail($to, $subject, $body, $headers);

    // إعادة التوجيه بشكل آمن إلى رابط الصفحة الحالي
    $redirect_url = add_query_arg('sent', '1', get_permalink(get_queried_object_id()));
    wp_redirect($redirect_url);
    exit;
}

if (isset($_GET['sent']) && $_GET['sent'] == '1'): ?>
    <div class="alert alert-success">Your message has been sent successfully!</div>
<?php endif; 

get_header(); ?>

<!-- Leaflet CSS for Map -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>

<div class="contact-page">
    <!-- Contact Header -->
    <?php
    $gradient_start = get_theme_mod('contact_header_bg_gradient_start', '#59ab6e');
    $gradient_end = get_theme_mod('contact_header_bg_gradient_end', '#4a8f5c');
    ?>
    <div class="contact-header" style="background: linear-gradient(135deg, <?php echo esc_attr($gradient_start); ?> 0%, <?php echo esc_attr($gradient_end); ?> 100%);">
        <div class="container">
            <h1><?php echo esc_html(get_theme_mod('contact_title', 'Contact Us')); ?></h1>
            <p><?php echo esc_html(get_theme_mod('contact_description', 'Proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet.')); ?></p>
        </div>
    </div>

    <div class="container">
        <!-- Interactive Map -->
        <div class="map-container">
            <div class="map-overlay">
                <h3><?php echo esc_html(get_theme_mod('map_location_title', 'Our Location')); ?></h3>
                <?php if (get_theme_mod('contact_show_location', true)) : ?>
                    <p><i class="fas fa-map-marker-alt"></i> <?php echo esc_html(get_theme_mod('contact_location_text', '1234 Consectetur at ligula 10660')); ?></p>
                <?php endif; ?>
                <?php if (get_theme_mod('contact_show_phone', true)) : ?>
                    <p><i class="fas fa-phone"></i> <?php echo esc_html(get_theme_mod('contact_phone_text', '010-020-03405')); ?></p>
                <?php endif; ?>
                <?php if (get_theme_mod('contact_show_email', true)) : ?>
                    <p><i class="fas fa-envelope"></i> <?php echo esc_html(get_theme_mod('contact_email_text', 'info@company.com')); ?></p>
                <?php endif; ?>
            </div>

            <div id="mapid"></div>
            <div class="map-zoom-controls">
                <button class="zoom-btn" id="zoom-in">+</button>
                <button class="zoom-btn" id="zoom-out">−</button>
            </div>
        </div>

        <!-- Contact Section -->
        <div class="contact-section">
            <div class="contact-container">
                <!-- Contact Information -->
                <div class="contact-info">
                    <h2><?php echo esc_html(get_theme_mod('contact_info_title', 'Get In Touch')); ?></h2>
                    
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-map-marker-alt"></i></div>
                        <div class="info-content">
                            <h4><?php echo esc_html(get_theme_mod('contact_info_location_label', 'Our Location')); ?></h4>
                            <p><?php echo esc_html(get_theme_mod('contact_info_location_data', '1234 Consectetur at ligula 10660')); ?></p>
                        </div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-phone"></i></div>
                        <div class="info-content">
                            <h4><?php echo esc_html(get_theme_mod('contact_info_phone_label', 'Phone Number')); ?></h4>
                            <p><?php echo esc_html(get_theme_mod('contact_info_phone_data', '010-020-03405')); ?></p>
                        </div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-envelope"></i></div>
                        <div class="info-content">
                            <h4><?php echo esc_html(get_theme_mod('contact_info_email_label', 'Email Address')); ?></h4>
                            <p><?php echo esc_html(get_theme_mod('contact_info_email_data', 'info@company.com')); ?></p>
                        </div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-clock"></i></div>
                        <div class="info-content">
                            <h4><?php echo esc_html(get_theme_mod('working_hours_label', 'Working Hours')); ?></h4>
                            <p><?php echo esc_html(get_theme_mod('working_hours_weekdays', 'Monday-Friday: 9AM-6PM')); ?></p>
                            <p><?php echo esc_html(get_theme_mod('working_hours_weekend', 'Saturday: 10AM-4PM')); ?></p>
                        </div>
                    </div>
                    
                    <div class="social-links">
                        <?php $socials = array('facebook','instagram','twitter','linkedin');
                        foreach($socials as $social) :
                            if (get_theme_mod('contact_show_'.$social, true) && get_theme_mod('contact_'.$social.'_url', '#') && get_theme_mod('contact_'.$social.'_url', '#') !== '#') : ?>
                                <a href="<?php echo esc_url(get_theme_mod('contact_'.$social.'_url')); ?>" target="_blank"><i class="fab fa-<?php echo $social === 'linkedin' ? 'linkedin-in' : $social; ?>"></i></a>
                        <?php endif; endforeach; ?>
                    </div>
                </div>
                
                <!-- Contact Form -->
                <div class="contact-form">
                    <h2><?php echo esc_html(get_theme_mod('contact_form_title', 'Send Us a Message')); ?></h2>
                    <form id="contact-form" method="post">
                        <?php wp_nonce_field('contact_form_nonce', 'contact_nonce'); ?>
                        <input type="hidden" name="action" value="contact_form_submit">
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label for="name"><?php echo esc_html(get_theme_mod('contact_form_name_label', 'Full Name')); ?></label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="<?php echo esc_attr(get_theme_mod('contact_form_name_placeholder', 'Your Name')); ?>" required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label for="email"><?php echo esc_html(get_theme_mod('contact_form_email_label', 'Email Address')); ?></label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="<?php echo esc_attr(get_theme_mod('contact_form_email_placeholder', 'Your Email')); ?>" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone"><?php echo esc_html(get_theme_mod('contact_form_phone_label', 'Phone Number')); ?></label>
                            <input type="tel" class="form-control" id="phone" name="phone" placeholder="<?php echo esc_attr(get_theme_mod('contact_form_phone_placeholder', 'Your Phone')); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="subject"><?php echo esc_html(get_theme_mod('contact_form_subject_label', 'Subject')); ?></label>
                            <input type="text" class="form-control" id="subject" name="subject" placeholder="<?php echo esc_attr(get_theme_mod('contact_form_subject_placeholder', 'Subject')); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="message"><?php echo esc_html(get_theme_mod('contact_form_message_label', 'Your Message')); ?></label>
                            <textarea class="form-control" id="message" name="message" placeholder="<?php echo esc_attr(get_theme_mod('contact_form_message_placeholder', 'Write your message here...')); ?>" required></textarea>
                        </div>
                        
                        <button type="submit" class="submit-btn" style="background-color: <?php echo esc_attr(get_theme_mod('contact_button_bg_color', '#59ab6e')); ?>;">
                            <?php echo esc_html(get_theme_mod('contact_form_submit_text', 'Send Message')); ?>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Toast Notification -->
    <div id="form-toast"></div>
</div>

<!-- Leaflet JS -->
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>

<script>
jQuery(document).ready(function($) {
    // Initialize the map with enhanced controls
    if (typeof L !== 'undefined' && $('#mapid').length) {
        try {
            const map = L.map('mapid', {
                zoomControl: false // Disable default zoom control
            }).setView([
                <?php echo get_theme_mod('map_latitude', '23.013104'); ?>,
                <?php echo get_theme_mod('map_longitude', '43.394365'); ?>
            ], <?php echo get_theme_mod('map_zoom', '15'); ?>);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a>',
                maxZoom: 18
            }).addTo(map);

            // Custom marker with pulse effect or image
            <?php $marker_image = get_theme_mod('map_marker_image'); ?>
            const marker = L.marker([
                <?php echo get_theme_mod('map_latitude', '23.013104'); ?>,
                <?php echo get_theme_mod('map_longitude', '43.394365'); ?>
            ], {
                icon: <?php if ($marker_image) : ?>
                    L.icon({
                        iconUrl: '<?php echo esc_url($marker_image); ?>',
                        iconSize: [48, 48],
                        iconAnchor: [24, 48],
                        popupAnchor: [0, -48]
                    })
                <?php else : ?>
                    L.divIcon({
                        className: 'custom-marker',
                        html: '<div class="marker-pulse"></div>',
                        iconSize: [30, 30]
                    })
                <?php endif; ?>
            }).addTo(map);

            marker.bindPopup(`
                <div class="map-popup-content">
                    <h4><?php echo esc_html(get_theme_mod('map_location_title', 'Our Location')); ?></h4>
                    <p><i class="fas fa-map-marker-alt"></i> <?php echo esc_html(get_theme_mod('map_location_address', '1234 Consectetur at ligula 10660')); ?></p>
                </div>
            `);

            // Enhanced zoom controls
            $('#zoom-in').click(function() {
                map.zoomIn();
                $(this).addClass('active').delay(300).queue(function() {
                    $(this).removeClass('active').dequeue();
                });
            });

            $('#zoom-out').click(function() {
                map.zoomOut();
                $(this).addClass('active').delay(300).queue(function() {
                    $(this).removeClass('active').dequeue();
                });
            });

            // Disable scroll zoom by default
            map.scrollWheelZoom.disable();

            // Refresh map on window resize
            $(window).on('resize', function() {
                setTimeout(() => map.invalidateSize(), 100);
            });

        } catch (error) {
            console.error('Map initialization error:', error);
            $('#mapid').html('<div class="map-error"><?php echo esc_html__("Map loading failed. Please try again later.", "textdomain"); ?></div>');
        }
    }

    // إضافة تأثير النبض للعلامة
    $('head').append('<style>.marker-pulse{width:100%;height:100%;background:#59ab6e;border-radius:50%;position:relative;animation:pulse 2s infinite}@keyframes pulse{0%{transform:scale(0.8);opacity:1}70%{transform:scale(1.3);opacity:0.7}100%{transform:scale(0.8);opacity:1}}</style>');
});
</script>

<?php get_footer(); ?>