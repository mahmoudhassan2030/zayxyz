<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ZayXYZ
 */

get_header(); ?>

<!-- Archive Page Wrapper -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <!-- Archive Header -->
                <header class="page-header mb-4">
                    <?php
                    the_archive_title('<h1 class="page-title">', '</h1>');
                    the_archive_description('<div class="archive-description">', '</div>');
                    ?>
                </header>

                <?php if (have_posts()) : ?>
                    <div class="archive-posts">
                        <?php
                        /* Start the Loop */
                        while (have_posts()) :
                            the_post();
                            ?>
                            <article id="post-<?php the_ID(); ?>" <?php post_class('archive-post-item mb-4 p-4 border rounded'); ?>>
                                <div class="row">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <div class="col-md-4">
                                            <div class="post-thumbnail">
                                                <a href="<?php the_permalink(); ?>">
                                                    <?php the_post_thumbnail('medium', array('class' => 'img-fluid rounded')); ?>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                    <?php else : ?>
                                        <div class="col-12">
                                    <?php endif; ?>
                                    
                                    <header class="entry-header">
                                        <h2 class="entry-title">
                                            <a href="<?php the_permalink(); ?>" class="text-decoration-none">
                                                <?php the_title(); ?>
                                            </a>
                                        </h2>
                                        
                                        <div class="entry-meta text-muted small mb-2">
                                            <span class="posted-on">
                                                <i class="fas fa-calendar-alt me-1"></i>
                                                <?php echo get_the_date(); ?>
                                            </span>
                                            <span class="byline ms-3">
                                                <i class="fas fa-user me-1"></i>
                                                <?php the_author_posts_link(); ?>
                                            </span>
                                            <?php if (has_category()) : ?>
                                                <span class="cat-links ms-3">
                                                    <i class="fas fa-folder me-1"></i>
                                                    <?php the_category(', '); ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </header>

                                    <div class="entry-summary">
                                        <?php the_excerpt(); ?>
                                    </div>

                                    <footer class="entry-footer">
                                        <a href="<?php the_permalink(); ?>" class="btn btn-primary btn-sm">
                                            <?php esc_html_e('Read More', 'zayxyz'); ?>
                                            <i class="fas fa-arrow-right ms-1"></i>
                                        </a>
                                    </footer>
                                </div>
                            </article>
                            <?php
                        endwhile;
                        ?>
                    </div>

                    <!-- Pagination -->
                    <nav class="pagination-wrapper" aria-label="<?php esc_attr_e('Archive navigation', 'zayxyz'); ?>">
                        <?php
                        the_posts_pagination(array(
                            'mid_size'  => 2,
                            'prev_text' => '<i class="fas fa-chevron-left"></i> ' . __('Previous', 'zayxyz'),
                            'next_text' => __('Next', 'zayxyz') . ' <i class="fas fa-chevron-right"></i>',
                            'class'     => 'pagination justify-content-center',
                        ));
                        ?>
                    </nav>

                <?php else : ?>
                    <div class="no-posts text-center py-5">
                        <i class="fas fa-archive fa-3x text-muted mb-3"></i>
                        <h2><?php esc_html_e('No posts found', 'zayxyz'); ?></h2>
                        <p class="text-muted">
                            <?php esc_html_e('It looks like nothing was found at this location. Maybe try a search?', 'zayxyz'); ?>
                        </p>
                        
                        <div class="search-form-wrapper mt-4">
                            <?php get_search_form(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-lg-4">
                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>

<?php
get_footer(); 