<?php
/**
 * codevers2e functions and definitions
 *
 * @package WordPress
 * @subpackage codevers2e
 * @since codevers2e 1.0
 */

// Includes
require get_template_directory() . '/inc/filter-cus.php';
require get_template_directory() . '/inc/subscribers-cus.php';
require get_template_directory() . '/inc/mssage-cus.php';

// الكود في بداية ملف functions.php
add_filter('duplicate_comment_id', '__return_false');

function enqueue_font_awesome() {
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
}
add_action('wp_enqueue_scripts', 'enqueue_font_awesome');
// تحميل النص الدولي أولاً
function codevers2e_load_theme_textdomain() {
    load_theme_textdomain('codevers2e', get_template_directory() . '/languages');
}
add_action('init', 'codevers2e_load_theme_textdomain');

// إعداد دعم السمات
add_action('after_setup_theme', function() {
    add_theme_support('automatic-feed-links');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(825, 510, true);
    
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'codevers2e'),
        'header'  => __('Header menu', 'codevers2e'),
        'footer'  => __('Footer menu', 'codevers2e'),
    ));
    
    add_theme_support('html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
    ));
    
    add_theme_support('post-formats', array(
        'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
    ));
    
    add_theme_support('custom-logo', array(
        'height' => 300,
        'width' => 300,
        'flex-height' => true,
        'flex-width' => true,
        'unlink-homepage-logo' => false,
        'header-text' => array('site-title', 'site-description'),
    ));
    
    add_theme_support('customize-selective-refresh-widgets');
    
    // دعم ووكومرس
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
});

// تسجيل منطقة الويدجات
function wpdocs_theme_slug_widgets_init() {
    register_sidebar(array(
        'name'          => __('Main Sidebar', 'codevers2e'),
        'id'            => 'sidebar-1',
        'description'   => __('Widgets in this area will be shown on all posts and pages.', 'codevers2e'),
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
        'after_widget'  => '</li>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'wpdocs_theme_slug_widgets_init');


// Favicon Functionality
function zayxyz_add_favicon_customizer($wp_customize) {
    $wp_customize->add_section('zayxyz_favicon_section', array(
        'title'      => __('Favicon', 'zayxyz'),
        'priority'   => 30,
    ));

    $wp_customize->add_setting('zayxyz_favicon', array(
        'default'           => '',
        'transport'         => 'refresh',
        'sanitize_callback' => 'esc_url_raw',
    ));

    $wp_customize->add_control(new WP_Customize_Image_control($wp_customize, 'zayxyz_favicon', array(
        'label'      => __('Upload Favicon', 'zayxyz'),
        'section'    => 'zayxyz_favicon_section',
        'settings'   => 'zayxyz_favicon',
    )));
}
add_action('customize_register', 'zayxyz_add_favicon_customizer');

// Register Custom Post Type
function create_monthly_category_post_type() {
    $labels = array(
        'name'                  => _x('Monthly Categories', 'Post Type General Name', 'textdomain'),
        'singular_name'         => _x('Monthly Category', 'Post Type Singular Name', 'textdomain'),
        'menu_name'             => __('Monthly Categories', 'textdomain'),
        'name_admin_bar'        => __('Monthly Category', 'textdomain'),
        'archives'              => __('Category Archives', 'textdomain'),
        'attributes'            => __('Category Attributes', 'textdomain'),
        'parent_item_colon'     => __('Parent Category:', 'textdomain'),
        'all_items'             => __('All Categories', 'textdomain'),
        'add_new_item'          => __('Add New Category', 'textdomain'),
        'add_new'               => __('Add New', 'textdomain'),
        'new_item'              => __('New Category', 'textdomain'),
        'edit_item'             => __('Edit Category', 'textdomain'),
        'update_item'           => __('Update Category', 'textdomain'),
        'view_item'             => __('View Category', 'textdomain'),
        'view_items'            => __('View Categories', 'textdomain'),
        'search_items'          => __('Search Category', 'textdomain'),
        'not_found'             => __('Not found', 'textdomain'),
        'not_found_in_trash'    => __('Not found in Trash', 'textdomain'),
        'featured_image'        => __('Category Image', 'textdomain'),
        'set_featured_image'    => __('Set category image', 'textdomain'),
        'remove_featured_image' => __('Remove category image', 'textdomain'),
        'use_featured_image'    => __('Use as category image', 'textdomain'),
        'insert_into_item'      => __('Insert into category', 'textdomain'),
        'uploaded_to_this_item' => __('Uploaded to this category', 'textdomain'),
        'items_list'            => __('Categories list', 'textdomain'),
        'items_list_navigation' => __('Categories list navigation', 'textdomain'),
        'filter_items_list'     => __('Filter categories list', 'textdomain'),
    );
    $args = array(
        'label'                 => __('Monthly Category', 'textdomain'),
        'description'           => __('Categories of the month', 'textdomain'),
        'labels'                => $labels,
        'supports'              => array('title', 'thumbnail', 'excerpt'),
        'taxonomies'            => array(),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-category',
        'show_in_admin_bar'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    );
    register_post_type('monthly_category', $args);
}
add_action('init', 'create_monthly_category_post_type', 0);

// مزامنة التصنيفات مع ووكومرس عند الحفظ
add_action('save_post_monthly_category', 'sync_monthly_category_with_woocommerce', 10, 3);

function sync_monthly_category_with_woocommerce($post_id, $post, $update) {
    // تجنب التنفيذ أثناء الحفظ التلقائي
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    
    // فقط لمنشورات الفئات الشهرية
    if ('monthly_category' !== $post->post_type) return;
    
    // بيانات الفئة
    $category_name = get_the_title($post_id);
    $category_slug = sanitize_title($category_name);
    $category_description = $post->post_content;
    $image_id = get_post_thumbnail_id($post_id);
    
    // التحقق من وجود الفئة في ووكومرس
    $existing_term = get_term_by('slug', $category_slug, 'product_cat');
    
    if ($existing_term) {
        // تحديث الفئة الموجودة
        wp_update_term($existing_term->term_id, 'product_cat', array(
            'name' => $category_name,
            'description' => $category_description
        ));
        
        // تحديث الصورة
        if ($image_id) {
            update_term_meta($existing_term->term_id, 'thumbnail_id', $image_id);
        }
        
        // حفظ رابط تصنيف المنتجات
        $term_link = get_term_link($existing_term->term_id, 'product_cat');
        update_post_meta($post_id, 'category_shop_url', $term_link);
    } else {
        // إنشاء فئة جديدة
        $new_term = wp_insert_term(
            $category_name,
            'product_cat',
            array(
                'slug' => $category_slug,
                'description' => $category_description
            )
        );
        
        // إضافة الصورة إذا تم إنشاء الفئة بنجاح
        if (!is_wp_error($new_term)) {
            if ($image_id) {
                update_term_meta($new_term['term_id'], 'thumbnail_id', $image_id);
            }
            
            // حفظ رابط تصنيف المنتجات
            $term_link = get_term_link($new_term['term_id'], 'product_cat');
            update_post_meta($post_id, 'category_shop_url', $term_link);
        }
    }
    
    // تفريغ التخزين المؤقت للفئات
    $transient_key = 'home_categories_'. get_locale();
    delete_transient($transient_key);
}

// مزامنة عند حذف الفئة
add_action('before_delete_post', 'delete_woocommerce_category_on_monthly_category_delete');

function delete_woocommerce_category_on_monthly_category_delete($post_id) {
    $post_type = get_post_type($post_id);
    
    if ('monthly_category' !== $post_type) return;
    
    $category_name = get_the_title($post_id);
    $category_slug = sanitize_title($category_name);
    
    // البحث عن الفئة في ووكومرس
    $term = get_term_by('slug', $category_slug, 'product_cat');
    
    // حذف الفئة إذا وجدت
    if ($term && !is_wp_error($term)) {
        wp_delete_term($term->term_id, 'product_cat');
    }
    
    // تفريغ التخزين المؤقت للفئات
    $transient_key = 'home_categories_' . get_locale();
    delete_transient($transient_key);
}

// توجيه روابط التصنيفات الشهرية إلى تصنيفات ووكومرس
add_action('template_redirect', 'redirect_monthly_category_to_woocommerce');

function redirect_monthly_category_to_woocommerce() {
    if (is_singular('monthly_category')) {
        $post_id = get_queried_object_id();
        $shop_url = get_post_meta($post_id, 'category_shop_url', true);
        
        if (!empty($shop_url) && !is_wp_error($shop_url)) {
            wp_redirect($shop_url, 301);
            exit;
        }
    }
}


// **************************************


// إضافة إعدادات التخصيص
// function zayxyz_customize_register_full($wp_customize) {
//     // كل إعدادات التخصيص هنا
// }
// add_action('customize_register', 'zayxyz_customize_register_full');

// AJAX handler for the contact form
function handle_contact_form_submission() {
    if (!isset($_POST['contact_nonce']) || !wp_verify_nonce($_POST['contact_nonce'], 'contact_form_nonce')) {
        wp_send_json_error(array('message' => 'Nonce verification failed.'));
        return;
    }

    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $subject = sanitize_text_field($_POST['subject']);
    $message = sanitize_textarea_field($_POST['message']);
    
    if (empty($name) || !is_email($email) || empty($subject) || empty($message)) {
        wp_send_json_error(array('message' => 'Please fill in all required fields.'));
        return;
    }
    
    $to = get_option('admin_email');
    $headers = array('Content-Type: text/html; charset=UTF-8', 'From: ' . $name . ' <' . $email . '>');
    $body = "<h2>New Contact Form Submission</h2>
             <p><strong>Name:</strong> {$name}</p>
             <p><strong>Email:</strong> {$email}</p>
             <p><strong>Subject:</strong> {$subject}</p>
             <p><strong>Message:</strong><br>{$message}</p>";

    if (wp_mail($to, $subject, $body, $headers)) {
        $success_message = get_theme_mod('contact_form_success_message', 'Your message has been sent successfully!');
        wp_send_json_success(array('message' => $success_message));
    } else {
        wp_send_json_error(array('message' => 'Failed to send the message. Please try again later.'));
    }
}
add_action('wp_ajax_contact_form_submit', 'handle_contact_form_submission');
add_action('wp_ajax_nopriv_contact_form_submit', 'handle_contact_form_submission');

// ================================================

function test_image_editing() {
    $tests = [
        'gd_supported' => false,
        'gd_functions' => [],
        'imagick_installed' => extension_loaded('imagick'),
        'server_environment' => [
            'php_version' => phpversion(),
            'memory_limit' => ini_get('memory_limit'),
            'upload_dir' => wp_upload_dir()
        ]
    ];

    // التحقق من توفر الدوال الأساسية
    $gd_functions = [
        'imagecreatetruecolor',
        'imagejpeg',
        'imagepng',
        'imagegif',
        'imagerotate'
    ];

    foreach ($gd_functions as $func) {
        $tests['gd_functions'][$func] = function_exists($func);
    }

    // crop image test
    if ($tests['gd_functions']['imagecreatetruecolor']) {
        try {
            $img = @imagecreatetruecolor(100, 100);
            if ($img) {
                $color = imagecolorallocate($img, 255, 0, 0);
                imagestring($img, 5, 10, 10, 'GD Test', $color);
                
                // حفظ الصورة للتأكد من الصلاحيات
                $upload_dir = wp_upload_dir();
                $test_path = $upload_dir['path'] . '/gd_test.jpg';
                $tests['gd_test_path'] = $test_path;
                
                if (imagejpeg($img, $test_path)) {
                    $tests['gd_write_test'] = file_exists($test_path);
                    // تنظيف
                    @unlink($test_path);
                }
                
                imagedestroy($img);
                $tests['gd_supported'] = true;
            }
        } catch (Exception $e) {
            $tests['gd_error'] = $e->getMessage();
        }
    }

    return $tests;
}
// =======================







// تسجيل السكربتات والأنماط
function theme_scripts() {
    // الأنماط
    wp_enqueue_style('bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', array(), '5.1.3');
    wp_enqueue_style('templatemo', get_template_directory_uri() . '/assets/css/templatemo.css');
    wp_enqueue_style('main-styles', get_template_directory_uri() . '/assets/css/main-styles.css', array('bootstrap'), filemtime(get_template_directory() . '/assets/css/main-styles.css'));
    wp_enqueue_style('merged-prices', get_template_directory_uri() . '/assets/css/merged-prices.css', array('main-styles'), filemtime(get_template_directory() . '/assets/css/merged-prices.css'));
    if (is_product()) {
        wp_enqueue_style('single-product', get_template_directory_uri() . '/assets/css/single-product.css', array('main-styles'), filemtime(get_template_directory() . '/assets/css/single-product.css'));
    }
    wp_enqueue_style('slick', get_template_directory_uri() . '/assets/css/slick.min.css', array(), '1.8.1');
    wp_enqueue_style('slick-theme', get_template_directory_uri() . '/assets/css/slick-theme.min.css', array('slick'), '1.8.1');
    // أضف تحميل custom.css إذا كان موجودًا
    if (file_exists(get_template_directory() . '/assets/css/custom.css')) {
        wp_enqueue_style('custom-css', get_template_directory_uri() . '/assets/css/custom.css', array(), filemtime(get_template_directory() . '/assets/css/custom.css'));
    }
    // أضف تحميل fontawesome.min.css إذا كان موجودًا
    if (file_exists(get_template_directory() . '/assets/css/fontawesome.min.css')) {
        wp_enqueue_style('fontawesome', get_template_directory_uri() . '/assets/css/fontawesome.min.css', array(), filemtime(get_template_directory() . '/assets/css/fontawesome.min.css'));
    }
    // السكربتات
    wp_enqueue_script('jquery'); // تحميل jQuery أولاً
    wp_enqueue_script('bootstrap-bundle', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array('jquery'), '5.1.3', true);
    wp_enqueue_script('slick', get_template_directory_uri() . '/assets/js/slick.min.js', array('jquery'), '1.8.1', true);
    wp_enqueue_script('templatemo', get_template_directory_uri() . '/assets/js/templatemo.js', array('jquery'), '1.0', true);
    wp_enqueue_script('main-functions', get_template_directory_uri() . '/assets/js/main-functions.js', array('jquery', 'slick'), filemtime(get_template_directory() . '/assets/js/main-functions.js'), true);
    // الوظائف العامة
    wp_localize_script('main-functions', 'zayxyz_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('zayxyz_quick_view_nonce')
    ));
    if (class_exists('WooCommerce')) {
        wp_localize_script('main-functions', 'ajax_cart_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'cart_url' => wc_get_cart_url(),
        ));
        wp_localize_script('main-functions', 'wc_cart_fragments_params', array(
            'cart_url' => wc_get_cart_url(),
            'checkout_url' => wc_get_checkout_url(),
        ));
    }
    // صفحة المنتج
    if (is_product()) {
        wp_enqueue_script('accounting', 'https://cdnjs.cloudflare.com/ajax/libs/accounting.js/0.4.1/accounting.min.js', array('jquery'), '0.4.1', true);
        wp_enqueue_script('main-product', get_template_directory_uri() . '/assets/js/main-product.js', array('jquery', 'slick', 'accounting'), filemtime(get_template_directory() . '/assets/js/main-product.js'), true);
        wp_localize_script('main-product', 'woocommerce_params', array(
            'currency_symbol' => get_woocommerce_currency_symbol(),
            'decimal_separator' => wc_get_price_decimal_separator(),
            'thousand_separator' => wc_get_price_thousand_separator(),
            'price_num_decimals' => wc_get_price_decimals(),
            'currency_pos' => get_option('woocommerce_currency_pos')
        ));
    }
    // صفحة اتصل بنا
    if (is_page_template('contact.php')) {
        wp_enqueue_style('contact-page', get_template_directory_uri() . '/assets/css/contact-page.css', array(), filemtime(get_template_directory() . '/assets/css/contact-page.css'));
    }
}
add_action('wp_enqueue_scripts', 'theme_scripts');

// دالة جلب بيانات المنتج للمعاينة السريعة (نسخة محسنة)
function zayxyz_get_product_quick_view() {
    check_ajax_referer('zayxyz_quick_view_nonce', 'nonce');

    if ( !isset($_POST['product_id']) ) {
        wp_send_json_error(array('message' => 'Product ID not provided.'));
        return;
    }

    $product_id = intval($_POST['product_id']);
    
    // تهيئة متغيرات وردبريس و WooCommerce
    global $post, $product;
    $post = get_post($product_id);
    $product = wc_get_product($product_id);

    if ( !$product ) {
        wp_send_json_error(array('message' => 'Product not found.'));
        return;
    }
    
    setup_postdata($post);

    ob_start();
    // استخدام القالب مباشرة بعد تهيئة المتغيرات
    wc_get_template('woocommerce/quick-view-content.php');
    $html = ob_get_clean();

    wp_reset_postdata();

    wp_send_json_success(array('html' => $html));
}
add_action('wp_ajax_zayxyz_get_product_quick_view', 'zayxyz_get_product_quick_view');
add_action('wp_ajax_nopriv_zayxyz_get_product_quick_view', 'zayxyz_get_product_quick_view');

// ==============================================


// وظائف ووكومرس
if (class_exists('WooCommerce')) {
    // تحديث السلة باستخدام AJAX
    function get_cart_details() {
        $cart_data = array(
            'count' => WC()->cart->get_cart_contents_count(),
            'total' => WC()->cart->get_cart_total()
        );
        wp_send_json($cart_data);
    }
    add_action('wp_ajax_get_cart_details', 'get_cart_details');
    add_action('wp_ajax_nopriv_get_cart_details', 'get_cart_details');
    
    // تخصيص عدد المنتجات في الصف
    add_filter('loop_shop_columns', function() {
        return 3;
    });
    
    // تخصيص عدد المنتجات في الصفحة
    add_filter('loop_shop_per_page', function() {
        return 9;
    });
    
    // تسجيل منطقة الويدجات للمتجر
    function codevers2e_shop_widgets_init() {
        register_sidebar(array(
            'name'          => 'Shop Sidebar',
            'id'            => 'shop-sidebar',
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>',
        ));
    }
    add_action('widgets_init', 'codevers2e_shop_widgets_init');
    
    // تخصيص زر إضافة إلى السلة
    add_filter('woocommerce_loop_add_to_cart_link', function($button, $product) {
        $button = str_replace('class="button', 'class="btn btn-success centered-button', $button);
        return $button;
    }, 10, 2);

    // إخفاء breadcrumb الافتراضي في WooCommerce
    remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0);
}

// وظيفة تسجيل قوائم الفوتر
function register_footer_menus() {
    register_nav_menus(
        array(
            'footer-products' => __('Footer Products Menu', 'codevers2e'),
            'footer-info'     => __('Footer Info Menu', 'codevers2e'),
        )
    );
}
add_action('init', 'register_footer_menus');

// وظيفة تسجيل الأخطاء
if (!function_exists('write_log')) {
    function write_log($log) {
        if (true === WP_DEBUG) {
            error_log(print_r($log, true));
        }
    }
}


// Add AJAX handlers for cart updates
add_action('wp_ajax_update_cart_item', 'update_cart_item');
add_action('wp_ajax_nopriv_update_cart_item', 'update_cart_item');

function zayxyz_get_refreshed_mini_cart() {
    ob_start();
    get_template_part('inc/mini-cart-content');
    $mini_cart_html = ob_get_clean();
    wp_send_json_success(array(
        'mini_cart_html' => $mini_cart_html
    ));
}
add_action('wp_ajax_get_refreshed_mini_cart', 'zayxyz_get_refreshed_mini_cart');
add_action('wp_ajax_nopriv_get_refreshed_mini_cart', 'zayxyz_get_refreshed_mini_cart');

function update_cart_item() {
    if (isset($_POST['cart_key']) && isset($_POST['quantity'])) {
        $cart_key = sanitize_text_field($_POST['cart_key']);
        $quantity = intval($_POST['quantity']);
        
        if ($cart_key && $quantity > 0) {
            WC()->cart->set_quantity($cart_key, $quantity);
            
            $cart_item = WC()->cart->get_cart_item($cart_key);
            
            wp_send_json(array(
                'success' => true,
                'cart_count' => WC()->cart->get_cart_contents_count(),
                'cart_total' => WC()->cart->get_cart_total(),
                'cart_subtotal' => WC()->cart->get_cart_subtotal(),
                'item_price' => WC()->cart->get_product_price($cart_item['data'])
            ));
        }
    }
    
    wp_send_json(array('success' => false));
}

// ... existing code ...
// حذف أي تكرار لدالة remove_cart_item أو أكواد مشابهة
add_action('wp_ajax_remove_cart_item', 'remove_cart_item');
add_action('wp_ajax_nopriv_remove_cart_item', 'remove_cart_item');

function remove_cart_item() {
    $cart_key = sanitize_text_field($_POST['cart_key']);
    
    if ($cart_key) {
        WC()->cart->remove_cart_item($cart_key);
        
        wp_send_json(array(
            'success' => true,
            'cart_count' => WC()->cart->get_cart_contents_count(),
            'cart_total' => WC()->cart->get_cart_total(),
            'cart_subtotal' => WC()->cart->get_cart_subtotal()
        ));
    }
    
    wp_send_json(array('success' => false));
}
// ... existing code ...

// دالة لعرض التعليقات
function codevers2e_review_callback($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    ?>
    <div <?php comment_class('review-item mb-4 p-3 border rounded'); ?> id="comment-<?php comment_ID(); ?>">
        <div class="d-flex align-items-center mb-2">
            <div class="review-avatar me-3">
                <?php echo get_avatar($comment, 60); ?>
            </div>
            <div>
                <h5 class="mb-0"><?php comment_author(); ?></h5>
                <div class="review-rating mb-1">
                    <?php
                    $rating = intval(get_comment_meta($comment->comment_ID, 'rating', true));
                    for ($i = 1; $i <= 5; $i++) {
                        if ($i <= $rating) {
                            echo '<i class="fas fa-star text-warning"></i>';
                        } else {
                            echo '<i class="far fa-star text-warning"></i>';
                        }
                    }
                    ?>
                </div>
                <small class="text-muted"><?php echo get_comment_date('F j, Y'); ?></small>
            </div>
        </div>
        <div class="review-content">
            <?php if ($comment->comment_approved == '0') : ?>
                <p class="text-info"><em><?php esc_html_e('Your review is awaiting approval', 'woocommerce'); ?></em></p>
            <?php endif; ?>
            <div class="review-text"><?php comment_text(); ?></div>
        </div>
    </div>
    <?php
}

// إضافة حقل رفع صورة وحقل اسم العميل في نموذج مراجعة المنتج
add_filter('comment_form_defaults', function($defaults) {
    if (is_singular('product')) {
        $defaults['fields']['author'] = '<p class="comment-form-author"><label for="author">' . __('Your Name') . '</label> <input id="author" name="author" type="text" value="" size="30" required /></p>';
        $defaults['fields']['review_image'] = '<p class="comment-form-review-image"><label for="review_image">' . __('Upload Product Image') . '</label> <input id="review_image" name="review_image" type="file" accept="image/*" /></p>';
    }
    return $defaults;
});

// حفظ صورة المراجعة في بيانات التعليق
add_action('comment_post', function($comment_id) {
    if (isset($_FILES['review_image']) && !empty($_FILES['review_image']['name'])) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        $uploaded = media_handle_upload('review_image', 0);
        if (!is_wp_error($uploaded)) {
            add_comment_meta($comment_id, 'review_image_id', $uploaded);
        }
    }
}, 20);

// عرض صورة المراجعة واسم العميل مع كل مراجعة
add_filter('woocommerce_review_gravatar', function($avatar, $comment) {
    $image_id = get_comment_meta($comment->comment_ID, 'review_image_id', true);
    if ($image_id) {
        $img = wp_get_attachment_image($image_id, 'thumbnail', false, ['class' => 'review-customer-image', 'style' => 'border-radius:50%;width:48px;height:48px;object-fit:cover;margin:0 8px 0 0;']);
        return $img . $avatar;
    }
    return $avatar;
}, 10, 2);
// إنشاء تصنيف العلامات التجارية إذا لم يكن موجوداً
function register_product_brand_taxonomy() {
    $labels = array(
        'name' => __('Brands', 'woocommerce'),
        'singular_name' => __('Brand', 'woocommerce'),
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'product-brand'),
    );
    
    register_taxonomy('product_brand', 'product', $args);
}
add_action('init', 'register_product_brand_taxonomy');


function custom_review_callback($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    ?>
    <div <?php comment_class('review-item mb-4 p-4 bg-light rounded'); ?> id="comment-<?php comment_ID(); ?>">
        <div class="d-flex mb-3">
            <div class="flex-shrink-0 me-3">
                <?php echo get_avatar($comment, 60, '', '', array('class' => 'rounded-circle')); ?>
            </div>
            <div class="flex-grow-1">
                <h5 class="mt-0 mb-1"><?php comment_author(); ?></h5>
                <div class="review-meta text-muted small mb-2">
                    <span><?php echo get_comment_date(); ?></span>
                </div>
                <div class="review-rating mb-3">
                    <?php 
                    $rating = get_comment_meta($comment->comment_ID, 'rating', true);
                    if ($rating) {
                        echo '<div class="star-rating text-warning">';
                        for ($i = 1; $i <= 5; $i++) {
                            $star_class = ($i <= $rating) ? 'fas fa-star' : 'far fa-star';
                            echo '<i class="' . $star_class . '"></i>';
                        }
                        echo '</div>';
                    }
                    ?>
                </div>
                <div class="review-content">
                    <?php comment_text(); ?>
                </div>
                
                <?php
                // عرض الصور المرفقة إذا وجدت
                $images = get_comment_meta($comment->comment_ID, 'review_images', true);
                if ($images && is_array($images)) {
                    echo '<div class="review-images mt-3">';
                    echo '<div class="row g-2">';
                    foreach ($images as $image_id) {
                        echo '<div class="col-3">';
                        echo wp_get_attachment_image($image_id, 'thumbnail', false, array('class' => 'img-fluid rounded'));
                        echo '</div>';
                    }
                    echo '</div></div>';
                }
                ?>
            </div>
        </div>
    </div>
    <?php
}


add_action('comment_post', 'save_review_images', 10, 3);
function save_review_images($comment_id, $comment_approved, $commentdata) {
    if (isset($_FILES['review_images']) && !empty($_FILES['review_images']['name'][0])) {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        
        $files = $_FILES['review_images'];
        $attachments = array();
        $max_images = 4; // الحد الأقصى للصور
        
        foreach ($files['name'] as $key => $value) {
            if ($files['name'][$key] && count($attachments) < $max_images) {
                $file = array(
                    'name'     => $files['name'][$key],
                    'type'     => $files['type'][$key],
                    'tmp_name' => $files['tmp_name'][$key],
                    'error'    => $files['error'][$key],
                    'size'     => $files['size'][$key]
                );
                
                $_FILES = array('upload_file' => $file);
                $attachment_id = media_handle_upload('upload_file', 0);
                
                if (!is_wp_error($attachment_id)) {
                    $attachments[] = $attachment_id;
                }
            }
        }
        
        if (!empty($attachments)) {
            update_comment_meta($comment_id, 'review_images', $attachments);
        }
    }
    
    // إعادة التوجيه مع معلمة النجاح
    wp_redirect(add_query_arg('review_submitted', 'true', get_permalink($commentdata['comment_post_ID']) . '#reviews'));
    exit;
}

// منع ظهور زر "View Cart" بعد الإضافة للسلة عبر AJAX
add_filter('woocommerce_add_to_cart_fragments', function($fragments) {
    if (isset($fragments['a.added_to_cart'])) {
        unset($fragments['a.added_to_cart']);
    }
    return $fragments;
}, 99);

/**
 * 1. Add a file input field to the review form.
 * This allows users to upload an image when they leave a product review.
 */
add_action('comment_form_logged_in_after', 'add_review_image_upload_field');
add_action('comment_form_after_fields', 'add_review_image_upload_field');
function add_review_image_upload_field() {
    // We add this field only on product pages
    if (is_product()) {
        echo '<p class="comment-form-image">';
        echo '<label for="review_image">' . __('Add an image', 'zayxyz') . ' (JPG, PNG, GIF)</label>';
        echo '<input type="file" id="review_image" name="review_image" accept="image/png, image/jpeg, image/gif" /></p>';
    }
}

/**
 * 2. Modify comment form fields to make them required and add placeholders.
 * This improves user experience and ensures necessary data is collected.
 */
add_filter('comment_form_defaults', 'zayxyz_custom_comment_form_fields');
function zayxyz_custom_comment_form_fields($defaults) {
    if (is_product()) {
        $commenter = wp_get_current_commenter();
        $req = get_option('require_name_email');
        $aria_req = ($req ? " aria-required='true'" : '');

        $defaults['fields']['author'] = '
            <p class="comment-form-author">
                <label for="author">' . __('Name', 'zayxyz') . '&nbsp;<span class="required">*</span></label>
                <input id="author" name="author" type="text" value="' . esc_attr($commenter['comment_author']) . '" size="30"' . $aria_req . ' required="required" placeholder="' . __('Your Name', 'zayxyz') . '" />
            </p>';

        $defaults['fields']['email'] = '
            <p class="comment-form-email">
                <label for="email">' . __('Email', 'zayxyz') . '&nbsp;<span class="required">*</span></label>
                <input id="email" name="email" type="email" value="' . esc_attr($commenter['comment_author_email']) . '" size="30"' . $aria_req . ' required="required" placeholder="' . __('Your Email', 'zayxyz') . '" />
            </p>';
        
        $defaults['comment_field'] = '
            <p class="comment-form-comment">
                <label for="comment">' . _x('Your review', 'noun', 'woocommerce') . '&nbsp;<span class="required">*</span></label>
                <textarea id="comment" name="comment" cols="45" rows="8" required="required" placeholder="' . __('Write your review here...', 'zayxyz') . '"></textarea>
            </p>';
            
        $defaults['label_submit'] = __( 'Submit Review', 'zayxyz' );
        $defaults['title_reply'] = __('Be the first to review', 'zayxyz') . ' &ldquo;'.get_the_title().'&rdquo;';
        $defaults['title_reply_to'] = __('Leave a Reply to %s', 'zayxyz');
        $defaults['cancel_reply_link'] = __('Cancel reply', 'zayxyz');
        
    }
    return $defaults;
}


/**
 * 3. Validate the review fields before saving the comment.
 * This function checks for rating, comment text, and the uploaded image.
 */
add_action('preprocess_comment', 'validate_review_fields');
function validate_review_fields($commentdata) {
    // Only validate for product reviews
    if (isset($_POST['woocommerce_product_review']) && 'product' === get_post_type($commentdata['comment_post_ID'])) {
        
        // Check for rating
        if (!isset($_POST['rating']) || empty($_POST['rating'])) {
            wp_die(
                __('Error: Please select a rating for the product.', 'zayxyz'),
                __('Review Submission Error', 'zayxyz'),
                array('response' => 400, 'back_link' => true)
            );
        }

        // Check for comment content
        if (empty($commentdata['comment_content'])) {
             wp_die(
                __('Error: Please write a review.', 'zayxyz'),
                __('Review Submission Error', 'zayxyz'),
                array('response' => 400, 'back_link' => true)
            );
        }

        // Check if an image was uploaded and handle potential upload errors
        if (isset($_FILES['review_image']) && !empty($_FILES['review_image']['name'])) {
            if ($_FILES['review_image']['error'] !== UPLOAD_ERR_OK) {
                wp_die(
                    __('Error: There was an error uploading your image. Please try again.', 'zayxyz'),
                    __('Image Upload Error', 'zayxyz'),
                    array('response' => 400, 'back_link' => true)
                );
            }
            // Further validation (file type, size) can be added here
            $allowed_types = array('image/jpeg', 'image/png', 'image/gif');
            if (!in_array($_FILES['review_image']['type'], $allowed_types)) {
                 wp_die(
                    __('Error: Please upload a valid image file (JPG, PNG, or GIF).', 'zayxyz'),
                    __('Invalid File Type', 'zayxyz'),
                    array('response' => 400, 'back_link' => true)
                );
            }
        }
    }
    return $commentdata;
}

/**
 * 4. Save the uploaded image and attach it to the review.
 * This function hooks into the comment creation process to handle the file upload.
 */
add_action('comment_post', 'save_review_image', 10, 2);
function save_review_image($comment_id, $comment_approved) {
    if (isset($_FILES['review_image']) && !empty($_FILES['review_image']['name'])) {
        // Ensure this is a product review comment
        if (isset($_POST['comment_post_ID']) && 'product' === get_post_type($_POST['comment_post_ID'])) {
            if (!function_exists('wp_handle_upload')) {
                require_once(ABSPATH . 'wp-admin/includes/file.php');
            }

            $uploaded_file = $_FILES['review_image'];
            $upload_overrides = array('test_form' => false);
            $movefile = wp_handle_upload($uploaded_file, $upload_overrides);

            if ($movefile && !isset($movefile['error'])) {
                $attachment = array(
                    'guid'           => $movefile['url'],
                    'post_mime_type' => $movefile['type'],
                    'post_title'     => preg_replace('/\.[^.]+$/', '', basename($movefile['file'])),
                    'post_content'   => '',
                    'post_status'    => 'inherit'
                );
                
                $attach_id = wp_insert_attachment($attachment, $movefile['file']);
                
                // Save attachment ID to comment meta
                if ($attach_id) {
                    add_comment_meta($comment_id, 'review_image_id', $attach_id, true);
                }
            }
        }
    }
}

/**
 * 5. Display the review image in the comments list.
 * We modify the comment text to include the uploaded image if it exists.
 */
add_filter('get_comment_text', 'display_review_image', 10, 3);
function display_review_image($comment_text, $comment, $args) {
    if ($comment && 'product' === get_post_type($comment->comment_post_ID)) {
        $image_id = get_comment_meta($comment->comment_ID, 'review_image_id', true);
        if ($image_id) {
            $image_url = wp_get_attachment_url($image_id);
            if ($image_url) {
                $image_html = '<div class="review-image" style="margin-top: 15px;">';
                $image_html .= '<a href="' . esc_url($image_url) . '" target="_blank" rel="noopener noreferrer">';
                $image_html .= '<img src="' . esc_url($image_url) . '" alt="' . __('Review image', 'zayxyz') . '" style="max-width: 150px; height: auto; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);" />';
                $image_html .= '</a></div>';
                $comment_text .= $image_html;
            }
        }
    }
    return $comment_text;
}

/**
 * 6. Add enctype to comment form to allow file uploads.
 * This is crucial for the file input to work correctly.
 */
add_action('comment_form_tag', 'add_enctype_to_comment_form');
function add_enctype_to_comment_form() {
    if (is_product()) {
        echo ' enctype="multipart/form-data"';
    }
}

/**
 * Filter the average rating to use our custom text field if it exists.
 * This function hooks into WooCommerce and changes the rating value on the fly.
 *
 * @param float $average The original average rating.
 * @param object $product The product object.
 * @return float The modified average rating.
 */
function zayxyz_filter_product_average_rating($average, $product) {
    if ($product && $product->get_id()) {
        $custom_rating_text = get_post_meta($product->get_id(), 'custom_rating', true);
        if (!empty($custom_rating_text) && is_string($custom_rating_text)) {
            // Count 's' or 'S' to determine the star rating and return it.
            return substr_count(strtolower($custom_rating_text), 's');
        }
    }
    return $average;
}
add_filter('woocommerce_product_get_average_rating', 'zayxyz_filter_product_average_rating', 20, 2);

/**
 * Filter the final rating HTML to remove the review count link for our custom-rated products.
 *
 * @param string $html The original rating HTML.
 * @param float $rating The product's rating.
 * @param int $count The total number of ratings.
 * @return string The modified rating HTML.
 */
function zayxyz_filter_rating_html($html, $rating, $count) {
    if ($count > 0) {
        $html = '<div class="star-rating" title="' . sprintf(__('Rated %s out of 5', 'woocommerce'), $rating) . '">';
        $html .= '<span style="width:' . (($rating / 5) * 100) . '%"></span>';
        $html .= '</div>';
        $html .= '<span class="rating-count">(' . $count . ')</span>';
    }
    return $html;
}
add_filter('woocommerce_get_rating_html', 'zayxyz_filter_rating_html', 20, 3);

// ============================================================================
// معالجة زر "شراء الآن" في صفحة المنتج البسيط
// ============================================================================

// ================================================
//   AJAX Add to Cart Handlers
// ================================================

// معالج AJAX لإضافة المنتجات إلى السلة
add_action('wp_ajax_zayxyz_ajax_add_to_cart', 'zayxyz_ajax_add_to_cart');
add_action('wp_ajax_nopriv_zayxyz_ajax_add_to_cart', 'zayxyz_ajax_add_to_cart');

function zayxyz_ajax_add_to_cart() {
    // التحقق من nonce
    if (!wp_verify_nonce($_POST['nonce'], 'woocommerce-add-to-cart')) {
        wp_send_json_error('Security check failed');
        return;
    }
    
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    $variation_id = isset($_POST['variation_id']) ? intval($_POST['variation_id']) : 0;
    $variations = isset($_POST['variations']) ? $_POST['variations'] : array();
    $buy_now = isset($_POST['buy_now']) && $_POST['buy_now'] === '1';
    
    // التحقق من صحة المنتج
    $product = wc_get_product($product_id);
    if (!$product) {
        wp_send_json_error('Product not found');
        return;
    }
    
    // التحقق من توفر المنتج
    if (!$product->is_purchasable() || !$product->is_in_stock()) {
        wp_send_json_error('Product is not available');
        return;
    }
    
    // إفراغ السلة إذا كان زر "شراء الآن"
    if ($buy_now) {
        WC()->cart->empty_cart();
    }
    
    // إضافة المنتج إلى السلة
    if ($variation_id > 0) {
        $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variations);
    } else {
        $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity);
    }
    
    if ($cart_item_key) {
        $response_data = array(
            'message' => $buy_now ? 'Product added to cart and redirecting to checkout' : 'Product added to cart successfully',
            'cart_count' => WC()->cart->get_cart_contents_count(),
            'cart_total' => WC()->cart->get_cart_total()
        );
        
        if ($buy_now) {
            $response_data['checkout_url'] = wc_get_checkout_url();
        }
        
        wp_send_json_success($response_data);
    } else {
        wp_send_json_error('Failed to add product to cart');
    }
}

// إضافة متغيرات JavaScript للـ AJAX
add_action('wp_enqueue_scripts', 'add_buy_now_script_vars');

function add_buy_now_script_vars() {
    if (is_product()) {
        wp_localize_script('jquery', 'wc_add_to_cart_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('woocommerce-add-to-cart')
        ));
    }
}

// تحسين مظهر صفحة المنتج
add_action('wp_head', 'add_product_page_styles');

function add_product_page_styles() {
    if (is_product()) {
        echo '<style>
        .product-summary-container {
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            border: 1px solid #e9ecef;
        }
        
        .product-summary-card {
            position: relative;
            z-index: 1;
        }
        
        .product-summary-card::before {
            content: "";
            position: absolute;
            top: -10px;
            left: -10px;
            right: -10px;
            bottom: -10px;
            background: linear-gradient(45deg, #59ab6e, #28a745, #20c997);
            border-radius: 25px;
            z-index: -1;
            opacity: 0.1;
        }
        
        .quantity.focused input[type="number"] {
            border-color: #59ab6e !important;
            box-shadow: 0 0 0 0.2rem rgba(89, 171, 110, 0.25) !important;
        }
        
        .hover-effect {
            animation: pulse 0.6s ease-in-out;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        </style>';
    }
}

// إضافة دعم للصور المتعددة في صفحة المنتج
add_filter('woocommerce_single_product_image_thumbnail_html', 'customize_product_image_html', 10, 2);

function customize_product_image_html($html, $attachment_id) {
    // إضافة تأثيرات بصرية للصور
    $html = str_replace('class="', 'class="product-gallery-image ', $html);
    return $html;
}

// إضافة معلومات إضافية للمنتج
add_action('woocommerce_single_product_summary', 'add_product_extra_info', 25);

function add_product_extra_info() {
    global $product;
    
    if ($product) {
        echo '<div class="product-extra-info">';
        
        // حالة المخزون
        if ($product->is_in_stock()) {
            echo '<div class="stock-status in-stock">';
            echo '<i class="fas fa-check-circle"></i> ' . esc_html__('In Stock', 'woocommerce');
            echo '</div>';
        } else {
            echo '<div class="stock-status out-of-stock">';
            echo '<i class="fas fa-times-circle"></i> ' . esc_html__('Out of stock', 'woocommerce');
            echo '</div>';
        }
        
        // رمز المنتج
        if ($product->get_sku()) {
            echo '<div class="product-sku">';
            echo '<i class="fas fa-barcode"></i> ' . esc_html__('SKU:', 'woocommerce') . ' ' . $product->get_sku();
            echo '</div>';
        }
        
        echo '</div>';
    }
}

// إضافة CSS للمعلومات الإضافية
add_action('wp_head', 'add_product_extra_info_styles');

function add_product_extra_info_styles() {
    if (is_product()) {
        echo '<style>
        .product-extra-info {
            margin: 20px 0;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            border-left: 4px solid #59ab6e;
        }
        
        .product-extra-info > div {
            margin: 8px 0;
            font-size: 0.95rem;
            color: #6c757d;
        }
        
        .product-extra-info i {
            margin-left: 8px;
            width: 16px;
        }
        
        .stock-status.in-stock {
            color: #28a745;
        }
        
        .stock-status.out-of-stock {
            color: #dc3545;
        }
        
        .product-sku {
            color: #6c757d;
        }
        </style>';
    }
}

/**
 * Conditionally hide PayPal button based on Customizer setting.
 */
add_action('wp_head', 'zayxyz_conditionally_hide_paypal_button');
function zayxyz_conditionally_hide_paypal_button() {
    if (is_product() && get_theme_mod('zayxyz_show_paypal_button', true) == false) {
        echo '<style>
            /* Hides the container for PayPal buttons on single product pages */
            .woocommerce-paypal-payments-product-button-container,
            div[data-paypal-source="product"],
            .ppc-button-wrapper {
                display: none !important;
            }
        </style>';
    }
}

// Remove default related products output
remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);

// Add custom related products slider
add_action('woocommerce_after_single_product_summary', 'zayxyz_output_related_products_slider', 20);

/**
 * Output the related products slider.
 *
 * @param array $args (default: array()).
 */
function zayxyz_output_related_products_slider($args = array()) {
    $args['posts_per_page'] = 12; // زيادة عدد المنتجات
    
    // إعدادات السلايدر
    $slider_options = apply_filters('zayxyz_related_products_slider_options', [
        'slidesToShow'   => 4,
        'slidesToScroll' => 1,
        'autoplay'       => true,
        'autoplaySpeed'  => 3000,
        'dots'           => true,
        'arrows'         => true,
        'responsive'     => [
            [
                'breakpoint' => 1200,
                'settings'   => ['slidesToShow' => 3]
            ],
            [
                'breakpoint' => 992,
                'settings'   => ['slidesToShow' => 2]
            ],
            [
                'breakpoint' => 768,
                'settings'   => ['slidesToShow' => 1, 'arrows' => false]
            ]
        ]
    ]);
    
    echo '<div class="related-products-slider" data-slick=\'' . json_encode($slider_options) . '\'>';
    woocommerce_related_products($args);
    echo '</div>';
}

/**
 * Remove default WooCommerce product gallery and replace with custom one.
 */
function zayxyz_remove_default_product_gallery() {
    // Remove the default WooCommerce product gallery
    remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images', 20 );
}
add_action( 'init', 'zayxyz_remove_default_product_gallery' );

/**
 * Rearrange WooCommerce single product page elements for a custom layout.
 */
function zayxyz_rearrange_single_product_elements() {
    // Remove tabs and related products from their default location to be called manually
    remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
    remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
}
add_action( 'init', 'zayxyz_rearrange_single_product_elements' );


/**
 * Enqueue scripts and styles for the single product page.
 * This ensures that the slider library and custom scripts are loaded only when needed.
 */
// Removed duplicate zayxyz_single_product_scripts function and its add_action to prevent conflicts. Only theme_scripts will enqueue single-product assets.


if ( ! function_exists( 'zay_scripts' ) ) {
    function zay_scripts() {
        // ... existing zay_scripts function content ...
    }
}

// Correctly format the price HTML for all product types
function zayxyz_custom_price_html($price, $product) {
    if ($product->is_on_sale()) {
        // For variable products, display a price range or a single price
        if ($product->is_type('variable')) {
            $prices = $product->get_variation_prices(true);
            $min_price = current($prices['price']);
            $max_price = end($prices['price']);
            $min_reg_price = current($prices['regular_price']);

            // If min and max prices are the same, show single price
            if ($min_price === $max_price) {
                return sprintf('<del>%s</del> <ins>%s</ins>', wc_price($min_reg_price), wc_price($min_price));
            } else {
                 // Otherwise, you might want to show a range, or just the minimum price.
                 // Here, we'll show the minimum sale price format.
                 return sprintf('<del>%s</del> <ins>%s</ins>', wc_price($min_reg_price), wc_price($min_price));
            }
        } 
        // For all other product types (simple, external, etc.)
        else {
            $regular_price = $product->get_regular_price();
            $sale_price = $product->get_sale_price();
            if ($regular_price && $sale_price) {
                return sprintf('<del>%s</del> <ins>%s</ins>', wc_price($regular_price), wc_price($sale_price));
            }
        }
    }
    return $price;
}
add_filter('woocommerce_get_price_html', 'zayxyz_custom_price_html', 10, 2);

// ================================================
//   Enhanced Add to Cart Functionality
// ================================================

// معالجة إضافة المنتجات إلى السلة (محسنة)
add_action('wp_loaded', 'zayxyz_handle_add_to_cart');

function zayxyz_handle_add_to_cart() {
    // منع المعالجة المزدوجة
    if (defined('DOING_AJAX') && DOING_AJAX) {
        return;
    }
    
    // معالجة المنتجات البسيطة
    if (isset($_POST['add-to-cart']) && !empty($_POST['add-to-cart'])) {
        $product_id = absint($_POST['add-to-cart']);
        $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
        $buy_now = isset($_POST['buy_now']) && $_POST['buy_now'] === '1';
        
        // التحقق من صحة المنتج
        $product = wc_get_product($product_id);
        if (!$product || !$product->is_purchasable() || !$product->is_in_stock()) {
            wc_add_notice(__('Product is not available for purchase.', 'zayxyz'), 'error');
            return;
        }
        
        // إفراغ السلة إذا كان زر "شراء الآن"
        if ($buy_now) {
            WC()->cart->empty_cart();
        }
        
        // إضافة المنتج إلى السلة
        $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity);
        
        if ($cart_item_key) {
            if ($buy_now) {
                // التوجيه إلى صفحة الدفع
                wp_redirect(wc_get_checkout_url());
                exit;
            } else {
                wc_add_notice(__('Product added to cart successfully!', 'zayxyz'), 'success');
            }
        } else {
            wc_add_notice(__('Failed to add product to cart.', 'zayxyz'), 'error');
        }
    }
    
    // معالجة المنتجات المتغيرة
    if (isset($_POST['variation_id']) && !empty($_POST['variation_id'])) {
        $variation_id = absint($_POST['variation_id']);
        $product_id = absint($_POST['product_id']);
        $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
        $buy_now = isset($_POST['buy_now']) && $_POST['buy_now'] === '1';
        $variations = array();
        
        // جمع المتغيرات المحددة
        foreach ($_POST as $key => $value) {
            if (strpos($key, 'attribute_') === 0) {
                $variations[$key] = $value;
            }
        }
        
        // التحقق من صحة المنتج المتغير
        $variation = wc_get_product($variation_id);
        if (!$variation || !$variation->is_purchasable() || !$variation->is_in_stock()) {
            wc_add_notice(__('Selected variation is not available for purchase.', 'zayxyz'), 'error');
            return;
        }
        
        // إفراغ السلة إذا كان زر "شراء الآن"
        if ($buy_now) {
            WC()->cart->empty_cart();
        }
        
        // إضافة المنتج المتغير إلى السلة
        $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variations);
        
        if ($cart_item_key) {
            if ($buy_now) {
                // التوجيه إلى صفحة الدفع
                wp_redirect(wc_get_checkout_url());
                exit;
            } else {
                wc_add_notice(__('Product variation added to cart successfully!', 'zayxyz'), 'success');
            }
        } else {
            wc_add_notice(__('Failed to add product variation to cart.', 'zayxyz'), 'error');
        }
    }
}



// إضافة متغيرات JavaScript للـ AJAX
add_action('wp_enqueue_scripts', 'add_cart_script_vars');

function add_cart_script_vars() {
    if (is_product()) {
        wp_localize_script('jquery', 'cart_ajax_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('woocommerce-add-to-cart'),
            'add_to_cart_text' => __('Add to cart', 'woocommerce'),
            'adding_to_cart_text' => __('Adding...', 'woocommerce'),
            'added_to_cart_text' => __('Added to cart!', 'woocommerce')
        ));
    }
}

/**
 * Custom comment callback function
 */
function zayxyz_comment_callback($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    ?>
    <li <?php comment_class('comment-item mb-4'); ?> id="comment-<?php comment_ID(); ?>">
        <div class="comment-body p-3 border rounded">
            <div class="d-flex">
                <div class="comment-avatar me-3">
                    <?php echo get_avatar($comment, $args['avatar_size']); ?>
                </div>
                <div class="comment-content flex-grow-1">
                    <div class="comment-meta mb-2">
                        <h6 class="comment-author mb-1">
                            <?php comment_author_link(); ?>
                        </h6>
                        <small class="text-muted">
                            <i class="fas fa-calendar-alt me-1"></i>
                            <?php comment_date(); ?>
                            <?php if ($comment->comment_approved == '0') : ?>
                                <span class="badge bg-warning ms-2"><?php esc_html_e('Awaiting moderation', 'zayxyz'); ?></span>
                            <?php endif; ?>
                        </small>
                    </div>
                    
                    <div class="comment-text">
                        <?php comment_text(); ?>
                    </div>
                    
                    <div class="comment-actions mt-2">
                        <?php
                        comment_reply_link(array_merge($args, array(
                            'add_below' => 'div-comment',
                            'depth'     => $depth,
                            'max_depth' => $args['max_depth'],
                            'before'    => '<span class="reply-link btn btn-outline-primary btn-sm">',
                            'after'     => '</span>'
                        )));
                        ?>
                    </div>
                </div>
            </div>
        </div>
    <?php
}

add_action('wp_loaded', function() {
    if (isset($_POST['buy-now']) && isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST']) !== false) {
        $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
        $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
        $variation_id = isset($_POST['variation_id']) ? absint($_POST['variation_id']) : 0;
        $variations = array();
        foreach ($_POST as $key => $value) {
            if (strpos($key, 'attribute_') === 0) {
                $variations[$key] = $value;
            }
        }
        if ($variation_id) {
            WC()->cart->empty_cart();
            WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variations);
        } else {
            WC()->cart->empty_cart();
            WC()->cart->add_to_cart($product_id, $quantity);
        }
        wp_redirect(wc_get_checkout_url());
        exit;
    }
});

add_action('woocommerce_after_add_to_cart_button', function() {
    global $product;
    echo '<button type="submit" name="buy-now" value="' . esc_attr($product->get_id()) . '" class="buy-now-btn button alt inline-buy-now">' . esc_html__('Buy Now', 'zayxyz') . '</button>';
});

add_action('wp_enqueue_scripts', function() {
    if (is_product()) {
        wp_enqueue_script('wc-add-to-cart-variation');
    }
});

if (!function_exists('zayxyz_sanitize_checkbox')) {
    function zayxyz_sanitize_checkbox($checked) {
        return (isset($checked) && true == $checked) ? true : false;
    }
}

function zayxyz_enqueue_quickview_scripts() {
    wp_enqueue_script('wc-add-to-cart-variation');
}
add_action('wp_enqueue_scripts', 'zayxyz_enqueue_quickview_scripts');

// Only require the customizer file for all theme options
require get_template_directory() . '/inc/customizer.php';

// Inject dynamic CSS for sidebar widget settings from customizer
add_action('wp_head', function() {
    $title_color = get_theme_mod('sidebar_widget_title_color', '#1565c0');
    $text_color = get_theme_mod('sidebar_widget_text_color', '#222');
    $bg_color = get_theme_mod('sidebar_widget_bg_color', '#fff');
    $title_bg = get_theme_mod('sidebar_widget_title_bg', '#1565c0');
    echo '<style id="sidebar-widget-customizer-css">
    /* عناوين الودجات الجانبية */
    .widget-title, .woocommerce-widget-title, .widget .widget-title, .widget h2, .widget h3, .widget h4 {
        color: ' . esc_attr($title_color) . ' !important;
        background: ' . esc_attr($title_bg) . ' !important;
        padding: 10px 18px;
        border-radius: 8px 8px 0 0;
        margin-bottom: 0;
    }
    /* نصوص الفلاتر والودجات */
    .widget, .widget *:not(h2):not(h3):not(h4):not(.widget-title) {
        color: ' . esc_attr($text_color) . ';
    }
    /* خلفية صناديق الفلاتر */
    .widget, .widget_price_filter, .widget_search, .widget_product_categories, .widget_layered_nav {
        background: ' . esc_attr($bg_color) . ' !important;
        border-radius: 14px;
    }
    </style>';
});

// تغيير نصوص عناوين الودجات الجانبية تلقائياً
add_filter('widget_title', function($title) {
    $custom_titles = array(
        'product categories' => get_theme_mod('sidebar_widget_title_categories', 'Product Categories'),
        'filter by price'    => get_theme_mod('sidebar_widget_title_filter', 'Filter by Price'),
        'search products'    => get_theme_mod('sidebar_widget_title_search', 'Search Products'),
    );
    $title_key = strtolower(trim(strip_tags($title)));
    foreach ($custom_titles as $key => $custom) {
        if (strpos($title_key, $key) !== false) {
            return $custom;
        }
    }
    return $title;
});

add_action('wp_head', function() {
    $cat_title = esc_js(get_theme_mod('sidebar_widget_title_categories', 'Product Categories'));
    $search_title = esc_js(get_theme_mod('sidebar_widget_title_search', 'Search Products'));
    echo "<script>
    document.addEventListener('DOMContentLoaded', function() {
        var catTitle = '$cat_title';
        var searchTitle = '$search_title';
        var selectors = 'h1, h2, h3, h4, div, span';
        document.querySelectorAll(selectors).forEach(function(el) {
            // غيّر فقط أول عقدة نصية إذا كانت هي النص المطلوب
            if (el.childNodes.length > 0 && el.childNodes[0].nodeType === 3) {
                var txt = el.childNodes[0].textContent.trim().toLowerCase();
                if (txt === 'product categories') {
                    el.childNodes[0].textContent = catTitle + ' ';
                }
                if (txt === 'search products') {
                    el.childNodes[0].textContent = searchTitle + ' ';
                }
            }
        });
    });
    </script>";
});

add_action('customize_controls_print_footer_scripts', function() {
    echo '<script>
    document.addEventListener("DOMContentLoaded", function() {
        // إخفاء قسم Site Icon (Favicon) الافتراضي
        var faviconSection = document.querySelector("li[id^=\\"accordion-section-site_icon\\"]");
        if (faviconSection) faviconSection.style.display = "none";
        var faviconPanel = document.querySelector("#customize-control-site_icon, #customize-control-custom_favicon");
        if (faviconPanel) faviconPanel.style.display = "none";
    });
    </script>';
});

// إخفاء تبويب المواصفات (المعلومات الإضافية) للمنتجات البسيطة فقط
add_filter('woocommerce_product_tabs', function($tabs) {
    global $product;
    if ($product && $product->is_type('simple')) {
        // تبويب المواصفات عادة يكون اسمه 'additional_information' أو 'additional'
        if (isset($tabs['additional_information'])) {
            unset($tabs['additional_information']);
        }
        if (isset($tabs['additional'])) {
            unset($tabs['additional']);
        }
    }
    return $tabs;
}, 99);

// ================================================
//   Unified Product Loops
// ================================================

// إضافة المنتجات المميزة في الصفحة الرئيسية
function zayxyz_display_featured_products() {
    if (is_front_page() || is_home()) {
        wc_get_template('loop/featured-products.php');
    }
}
add_action('woocommerce_after_main_content', 'zayxyz_display_featured_products');

// إضافة المنتجات الجديدة في الصفحة الرئيسية
function zayxyz_display_new_products() {
    if (is_front_page() || is_home()) {
        wc_get_template('loop/new-products.php');
    }
}
add_action('woocommerce_after_main_content', 'zayxyz_display_new_products', 15);

// تحويل قوائم المتغيرات إلى أزرار
add_filter('woocommerce_dropdown_variation_attribute_options_html', 'zayxyz_variation_buttons', 20, 2);
function zayxyz_variation_buttons($html, $args) {
    if (empty($args['options']) || empty($args['attribute'])) return $html;
    $attribute = $args['attribute'];
    $options = $args['options'];
    $product = $args['product'];
    $name = esc_attr($attribute);
    $id = esc_attr($attribute);

    // إذا كان هناك خيار واحد فقط، لا داعي للأزرار
    if (count($options) === 1) return $html;

    $buttons = '<div class="zayxyz-variation-buttons" data-attribute_name="attribute_' . $name . '">';
    foreach ($options as $option) {
        $option_label = esc_html(apply_filters('woocommerce_variation_option_name', $option));
        $buttons .= '<button type="button" class="zayxyz-variation-btn" data-value="' . esc_attr($option) . '">' . $option_label . '</button>';
    }
    $buttons .= '</div>';

    // إخفاء القائمة الأصلية (ستظل موجودة للوظائف)
    $html = '<div style="display:none;">' . $html . '</div>' . $buttons;
    return $html;
}



add_action('template_redirect', function() {
    if (isset($_POST['buy_now']) && $_POST['buy_now'] == '1') {
        // بعد إضافة المنتج للسلة، انتقل مباشرة لصفحة الدفع
        wp_safe_redirect(wc_get_checkout_url());
        exit;
    }
});

add_action('template_redirect', function() {
    if (
        isset($_POST['buy_now']) && $_POST['buy_now'] == '1' &&
        isset($_POST['add-to-cart']) && is_numeric($_POST['add-to-cart'])
    ) {
        wp_safe_redirect(wc_get_checkout_url());
        exit;
    }
});

add_action('woocommerce_add_to_cart_redirect', function($url) {
    if (
        isset($_POST['buy_now']) && $_POST['buy_now'] == '1' &&
        isset($_POST['add-to-cart']) && is_numeric($_POST['add-to-cart'])
    ) {
        return wc_get_checkout_url();
    }
    return $url;
});

// ... existing code ...
// توحيد جميع خصائص المنتج لتظهر كأزرار عصرية في صفحة المنتج المتغير
add_filter('woocommerce_dropdown_variation_attribute_options_html', 'zayxyz_all_variations_to_buttons', 99, 2);
function zayxyz_all_variations_to_buttons($html, $args) {
    if (empty($args['options']) || empty($args['attribute'])) return $html;
    $attribute = $args['attribute'];
    $options = $args['options'];
    $product = $args['product'];
    $name = esc_attr($attribute);
    $id = esc_attr($attribute);

    // إذا كان هناك خيار واحد فقط، لا داعي للأزرار
    if (count($options) === 1) return $html;

    $selected = isset($_REQUEST['attribute_' . $name]) ? wc_clean(wp_unslash($_REQUEST['attribute_' . $name])) : $product->get_variation_default_attribute($attribute);
    $buttons = '<div class="zayxyz-variation-buttons" data-attribute_name="attribute_' . $name . '">';
    foreach ($options as $option) {
        $option_label = esc_html(apply_filters('woocommerce_variation_option_name', $option));
        $is_active = $selected === $option ? 'active' : '';
        $buttons .= '<button type="button" class="zayxyz-variation-btn ' . $is_active . '" data-value="' . esc_attr($option) . '">' . $option_label . '</button>';
    }
    $buttons .= '</div>';

    // إخفاء القائمة الأصلية (ستظل موجودة للوظائف)
    $html = '<div style="display:none;">' . $html . '</div>' . $buttons;
    return $html;
}
// ... existing code ...

// ... existing code ...
// === [START] Unified Star Rating Output Function ===
/**
 * Unified function to output star rating HTML for reviews and products.
 *
 * @param int|float $rating
 * @param int $max
 * @param string $class
 * @return string
 */
function zayxyz_render_star_rating($rating, $max = 5, $class = 'text-warning') {
    $html = '<div class="star-rating ' . esc_attr($class) . '">';
    for ($i = 1; $i <= $max; $i++) {
        $star_class = ($i <= $rating) ? 'fas fa-star' : 'far fa-star';
        $html .= '<i class="' . $star_class . '"></i>';
    }
    $html .= '</div>';
    return $html;
}
// === [END] Unified Star Rating Output Function ===
// ... existing code ...
// === [START] Unified Review Image Upload Handler ===
/**
 * Handles single or multiple review image uploads and attaches them to the comment meta.
 *
 * @param int $comment_id
 * @param array $files
 * @param string $meta_key
 * @param int $max_images
 * @return array Attachment IDs
 */
function zayxyz_handle_review_image_upload($comment_id, $files, $meta_key = 'review_images', $max_images = 4) {
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    $attachments = array();
    if (isset($files['name']) && is_array($files['name'])) {
        // Multiple files
        foreach ($files['name'] as $key => $value) {
            if ($files['name'][$key] && count($attachments) < $max_images) {
                $file = array(
                    'name'     => $files['name'][$key],
                    'type'     => $files['type'][$key],
                    'tmp_name' => $files['tmp_name'][$key],
                    'error'    => $files['error'][$key],
                    'size'     => $files['size'][$key]
                );
                $_FILES = array('upload_file' => $file);
                $attachment_id = media_handle_upload('upload_file', 0);
                if (!is_wp_error($attachment_id)) {
                    $attachments[] = $attachment_id;
                }
            }
        }
    } elseif (!empty($files['name'])) {
        // Single file
        $attachment_id = media_handle_upload('review_image', 0);
        if (!is_wp_error($attachment_id)) {
            $attachments[] = $attachment_id;
        }
    }
    if (!empty($attachments)) {
        update_comment_meta($comment_id, $meta_key, $attachments);
    }
    return $attachments;
}
// === [END] Unified Review Image Upload Handler ===
// ... existing code ...
// استبدال جميع عمليات رفع الصور للمراجعات باستدعاء zayxyz_handle_review_image_upload
// ... existing code ...










