<?php
/**
 * The template for displaying all pages.
 *
 * @package codevers2e
 */

get_header(); ?>

<!-- Page Template Wrapper -->
<main id="main" class="site-main container py-5">
    <div class="main-content-card">
        <?php
        while (have_posts()) : the_post();
        ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('page-content-wrapper'); ?>>
                <header class="entry-header page-header-pro p-4 mb-4">
                    <h1 class="entry-title display-4 fw-bold mb-3"><?php the_title(); ?></h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb bg-light p-3 rounded">
                            <li class="breadcrumb-item">
                                <a href="<?php echo esc_url(home_url('/')); ?>">
                                    <?php esc_html_e('Home', 'codevers2e'); ?>
                                </a>
                            </li>
                            <?php if ($post->post_parent) : ?>
                                <li class="breadcrumb-item">
                                    <a href="<?php echo esc_url(get_permalink($post->post_parent)); ?>">
                                        <?php echo get_the_title($post->post_parent); ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li class="breadcrumb-item active" aria-current="page">
                                <?php the_title(); ?>
                            </li>
                        </ol>
                    </nav>
                </header>
                <?php if (has_post_thumbnail()) : ?>
                    <div class="featured-image-page mb-4">
                        <?php the_post_thumbnail('full', ['class' => 'img-fluid rounded w-100']); ?>
                    </div>
                <?php endif; ?>
                <div class="entry-content page-content-pro px-3 px-md-4 pb-4">
                    <?php
                    the_content();
                    wp_link_pages(array(
                        'before' => '<div class="page-links mt-4"><span class="page-links-title">' . esc_html__('Pages:', 'codevers2e') . '</span>',
                        'after' => '</div>',
                        'link_before' => '<span class="page-link-number">',
                        'link_after' => '</span>',
                    ));
                    ?>
                </div>
                <footer class="entry-footer mt-5 pt-4 border-top px-3 px-md-4 pb-4">
                    <?php
                    $child_pages = get_pages(array(
                        'child_of' => get_the_ID(),
                        'sort_column' => 'menu_order'
                    ));
                    if ($child_pages) : ?>
                        <div class="child-pages mb-4">
                            <h3 class="h5 mb-3"><?php esc_html_e('Related Pages', 'codevers2e'); ?></h3>
                            <div class="row">
                                <?php foreach ($child_pages as $child_page) : ?>
                                    <div class="col-md-6 mb-3">
                                        <a href="<?php echo esc_url(get_permalink($child_page->ID)); ?>" class="child-page-link d-block p-3 rounded border">
                                            <?php echo esc_html($child_page->post_title); ?>
                                        </a>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif;
                    edit_post_link(
                        sprintf(
                            esc_html__('Edit %s', 'codevers2e'),
                            the_title('<span class="screen-reader-text">"', '"</span>', false)
                        ),
                        '<span class="edit-link d-block mt-3"><i class="fas fa-edit me-1"></i>',
                        '</span>'
                    );
                    ?>
                </footer>
            </article>
            <?php
            if (comments_open() || get_comments_number()) :
                comments_template();
            endif;
            ?>
        <?php endwhile; ?>
    </div>
</main>

<?php get_footer(); ?>
