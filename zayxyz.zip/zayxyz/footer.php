<?php
// The old PHP handler for the subscription form is removed.
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<!-- Start Footer -->
<?php
$footer_grad_start = get_theme_mod('footer_bg_gradient_start', '#283e51');
$footer_grad_end = get_theme_mod('footer_bg_gradient_end', '#485563');
?>
<footer class="bg-dark text-light pt-5" id="tempaltemo_footer"
    style="background: linear-gradient(135deg, <?php echo esc_attr($footer_grad_start); ?>, <?php echo esc_attr($footer_grad_end); ?>) !important; background-color: unset !important;">
    <div class="container">
        <div class="row">
            <!-- Company Info -->
            <div class="col-md-4 col-lg-3 mb-5">
                <div class="d-flex align-items-center mb-4">
                    <?php
                    $custom_logo_id = get_theme_mod('custom_logo');
                    $logo = wp_get_attachment_image_src($custom_logo_id, 'full');
                    
                    if ($logo) : ?>
                        <img src="<?php echo esc_url($logo[0]); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" 
                             class="footer-logo me-3" width="60">
                    <?php endif; ?>
                    <h2 class="h4 text-success mb-0"><?php echo esc_html(get_theme_mod('footer_company_name', 'Zay Shop')); ?></h2>
                </div>
                
                <p class="mb-4"><?php echo esc_html(get_theme_mod('footer_tagline', 'Premium products for your everyday needs')); ?></p>
                
                <ul class="list-unstyled footer-link-list">
                    <li class="mb-2">
                        <i class="fas fa-map-marker-alt fa-fw me-2"></i>
                        <?php echo esc_html(get_theme_mod('footer_address', '123 Consectetur at ligula 10660')); ?>
                    </li>
                    <li class="mb-2">
                        <i class="fa fa-phone fa-fw me-2"></i>
                        <a class="text-decoration-none text-light" href="tel:<?php echo esc_attr(get_theme_mod('footer_phone', '010-020-0340')); ?>">
                            <?php echo esc_html(get_theme_mod('footer_phone', '010-020-0340')); ?>
                        </a>
                    </li>
                    <li>
                        <i class="fa fa-envelope fa-fw me-2"></i>
                        <a class="text-decoration-none text-light" href="mailto:<?php echo esc_attr(get_theme_mod('footer_email', 'info@company.com')); ?>">
                            <?php echo esc_html(get_theme_mod('footer_email', 'info@company.com')); ?>
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Products Links -->
            <div class="col-md-4 col-lg-3 mb-5">
                <h3 class="h4 text-light border-bottom pb-2 border-light mb-4">Products</h3>
                <ul class="list-unstyled">
                    <?php
                    wp_nav_menu( array(
                        'theme_location' => 'footer-products',
                        'container' => false,
                        'items_wrap' => '%3$s',
                        'fallback_cb' => 'footer_menu_fallback',
                        'walker' => new Footer_Menu_Walker()
                    ) );
                    
                    function footer_menu_fallback() {
                        echo '<li><a href="' . esc_url(home_url('/shop')) . '" class="text-light text-decoration-none">All Products</a></li>';
                        echo '<li><a href="' . esc_url(home_url('/new-arrivals')) . '" class="text-light text-decoration-none">New Arrivals</a></li>';
                        echo '<li><a href="' . esc_url(home_url('/best-sellers')) . '" class="text-light text-decoration-none">Best Sellers</a></li>';
                        echo '<li><a href="' . esc_url(home_url('/sale')) . '" class="text-light text-decoration-none">On Sale</a></li>';
                    }
                    
                    // التأكد من تعريف الكلاسات fallback مرة واحدة فقط
                    if (!class_exists('Footer_Menu_Walker')) {
                        class Footer_Menu_Walker extends Walker_Nav_Menu {
                            function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
                                $output .= '<li class="mb-2">';
                                $output .= '<a href="' . esc_url($item->url) . '" class="text-light text-decoration-none">';
                                $output .= '<i class="fas fa-chevron-right fa-xs me-2 text-muted"></i>' . esc_html($item->title);
                                $output .= '</a></li>';
                            }
                        }
                    }
                    ?>
                </ul>
            </div>

            <!-- Information Links -->
            <div class="col-md-4 col-lg-3 mb-5">
                <h3 class="h4 text-light border-bottom pb-2 border-light mb-4">Information</h3>
                <ul class="list-unstyled">
                    <?php
                    wp_nav_menu( array(
                        'theme_location' => 'footer-info',
                        'container' => false,
                        'items_wrap' => '%3$s',
                        'fallback_cb' => 'footer_info_fallback',
                        'walker' => new Footer_Menu_Walker()
                    ) );
                    
                    function footer_info_fallback() {
                        echo '<li><a href="' . esc_url(home_url('/about')) . '" class="text-light text-decoration-none">About Us</a></li>';
                        echo '<li><a href="' . esc_url(home_url('/contact')) . '" class="text-light text-decoration-none">Contact Us</a></li>';
                        echo '<li><a href="' . esc_url(home_url('/privacy-policy')) . '" class="text-light text-decoration-none">Privacy Policy</a></li>';
                        echo '<li><a href="' . esc_url(home_url('/terms')) . '" class="text-light text-decoration-none">Terms & Conditions</a></li>';
                    }
                    ?>
                </ul>
            </div>

            <!-- Newsletter & Social Media -->
            <div class="col-md-12 col-lg-3 mb-5">
                <h3 class="h4 text-light border-bottom pb-2 border-light mb-4"><?php echo esc_html(get_theme_mod('footer_newsletter_title', 'Newsletter')); ?></h3>
                <p class="mb-4"><?php echo esc_html(get_theme_mod('footer_newsletter_description', 'Subscribe to our newsletter for the latest updates and offers.')); ?></p>
                
                <form method="post" class="subscribe-form" id="footer-subscribe-form">
                    <?php wp_nonce_field('footer_subscribe', 'subscribe_nonce'); ?>
                    <div class="input-group mb-3">
                        <input type="email" class="form-control bg-dark border-light text-light" 
                               id="subscribeEmail" name="subscribe_email" 
                               placeholder="<?php echo esc_attr(get_theme_mod('footer_newsletter_placeholder', 'Your email address')); ?>" required>
                        <button type="submit" class="input-group-text btn-success text-light" 
                                name="subscribe_submit">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </form>
                <div id="subscribe-message" class="mt-2"></div>
                
                <div class="mt-4">
                    <h3 class="h4 text-light border-bottom pb-2 border-light mb-4"><?php echo esc_html(get_theme_mod('footer_social_media_title', 'Follow Us')); ?></h3>
                    <div class="social-icons d-flex">
                        <?php if(get_theme_mod('footer_facebook_url', '#')): ?>
                        <a class="social-icon me-2 rounded-circle d-flex align-items-center justify-content-center" 
                           target="_blank" rel="noopener" 
                           href="<?php echo esc_url(get_theme_mod('footer_facebook_url', '#')); ?>"
                           style="color: <?php echo esc_attr(get_theme_mod('footer_social_icon_color', '#fff')); ?>;">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <?php endif; ?>
                        
                        <?php if(get_theme_mod('footer_instagram_url', '#')): ?>
                        <a class="social-icon me-2 rounded-circle d-flex align-items-center justify-content-center" 
                           target="_blank" rel="noopener" 
                           href="<?php echo esc_url(get_theme_mod('footer_instagram_url', '#')); ?>"
                           style="color: <?php echo esc_attr(get_theme_mod('footer_social_icon_color', '#fff')); ?>;">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <?php endif; ?>
                        
                        <?php if(get_theme_mod('footer_twitter_url', '#')): ?>
                        <a class="social-icon me-2 rounded-circle d-flex align-items-center justify-content-center" 
                           target="_blank" rel="noopener" 
                           href="<?php echo esc_url(get_theme_mod('footer_twitter_url', '#')); ?>"
                           style="color: <?php echo esc_attr(get_theme_mod('footer_social_icon_color', '#fff')); ?>;">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <?php endif; ?>
                        
                        <?php if(get_theme_mod('footer_linkedin_url', '#')): ?>
                        <a class="social-icon me-2 rounded-circle d-flex align-items-center justify-content-center" 
                           target="_blank" rel="noopener" 
                           href="<?php echo esc_url(get_theme_mod('footer_linkedin_url', '#')); ?>"
                           style="color: <?php echo esc_attr(get_theme_mod('footer_social_icon_color', '#fff')); ?>;">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <?php endif; ?>
                        
                        <?php if(get_theme_mod('footer_youtube_url', '#')): ?>
                        <a class="social-icon me-2 rounded-circle d-flex align-items-center justify-content-center" 
                           target="_blank" rel="noopener" 
                           href="<?php echo esc_url(get_theme_mod('footer_youtube_url', '#')); ?>"
                           style="color: <?php echo esc_attr(get_theme_mod('footer_social_icon_color', '#fff')); ?>;">
                            <i class="fab fa-youtube"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row text-light py-4 border-top border-secondary">
            <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                <p class="mb-0">
                    <?php echo wp_kses_post(get_theme_mod('footer_copyright_text', '&copy; ' . date('Y') . ' Company Name. All rights reserved.')); ?>
                </p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <div class="payment-methods d-inline-flex align-items-center">
                    <span class="me-2"><?php echo esc_html(get_theme_mod('footer_payment_methods_title', 'Accepted payments:')); ?></span>
                    <?php if (get_theme_mod('footer_payment_visa_icon_enabled', true)) : ?><i class="fab fa-cc-visa me-2"></i><?php endif; ?>
                    <?php if (get_theme_mod('footer_payment_mastercard_icon_enabled', true)) : ?><i class="fab fa-cc-mastercard me-2"></i><?php endif; ?>
                    <?php if (get_theme_mod('footer_payment_paypal_icon_enabled', true)) : ?><i class="fab fa-cc-paypal me-2"></i><?php endif; ?>
                    <?php if (get_theme_mod('footer_payment_applepay_icon_enabled', true)) : ?><i class="fab fa-cc-apple-pay me-2"></i><?php endif; ?>
                    <?php if (get_theme_mod('footer_payment_amazonpay_icon_enabled', false)) : ?><i class="fab fa-amazon-pay"></i><?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Back to top button -->
    <button id="back-to-top" class="btn btn-success rounded-circle">
        <i class="fas fa-arrow-up"></i>
    </button>
</footer>
<!-- End Footer -->

<!-- Quick View Modal -->
<div class="modal fade" id="quickViewModal" tabindex="-1" aria-labelledby="quickViewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header border-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- Content will be loaded here via AJAX -->
        <div class="d-flex justify-content-center align-items-center" style="height: 300px;">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<?php wp_footer(); ?>

<script>
jQuery(document).ready(function($) {
    // Handle subscription form
    $('#footer-subscribe-form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var messageDiv = $('#subscribe-message');
        var email = form.find('input[name="subscribe_email"]').val();
        var nonce = form.find('input[name="subscribe_nonce"]').val();
        var submitButton = form.find('button[type="submit"]');
        var originalButtonHtml = submitButton.html();
        
        messageDiv.html('<span class="text-warning">Processing...</span>');
        submitButton.html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);

        $.ajax({
            type: 'POST',
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            data: {
                action: 'footer_subscribe',
                subscribe_email: email,
                subscribe_nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    messageDiv.html('<span class="text-success">' + response.data.message + '</span>');
                    form.trigger('reset');
                } else {
                    messageDiv.html('<span class="text-danger">' + response.data.message + '</span>');
                }
            },
            error: function() {
                messageDiv.html('<span class="text-danger">An error occurred. Please try again.</span>');
            },
            complete: function() {
                submitButton.html(originalButtonHtml).prop('disabled', false);
                 // Hide the message after 5 seconds
                setTimeout(function() {
                    messageDiv.html('');
                }, 5000);
            }
        });
    });

    // Back to top button (if it exists)
    var backToTop = $('#back-to-top');
    if (backToTop.length) {
        $(window).on('scroll', function() {
            if ($(this).scrollTop() > 300) {
                backToTop.fadeIn();
            } else {
                backToTop.fadeOut();
            }
        });

        backToTop.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop: 0}, 600);
        });
    }
});
</script>

</body>
</html>