<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ZayXYZ
 */

/*
 * If the current post is protected by a password and
 * the visitor has not entered the password we will
 * return early without loading the comments.
 */
if (post_password_required()) {
    return;
}
?>

<div id="comments" class="comments-area">

    <?php
    // You can start editing here -- including this comment!
    if (have_comments()) :
        ?>
        <h2 class="comments-title">
            <?php
            $zayxyz_comment_count = get_comments_number();
            if ('1' === $zayxyz_comment_count) {
                printf(
                    /* translators: 1: title. */
                    esc_html__('One thought on &ldquo;%1$s&rdquo;', 'zayxyz'),
                    '<span>' . wp_kses_post(get_the_title()) . '</span>'
                );
            } else {
                printf(
                    /* translators: 1: comment count number, 2: title. */
                    esc_html(_nx('%1$s thought on &ldquo;%2$s&rdquo;', '%1$s thoughts on &ldquo;%2$s&rdquo;', $zayxyz_comment_count, 'comments title', 'zayxyz')),
                    number_format_i18n($zayxyz_comment_count),
                    '<span>' . wp_kses_post(get_the_title()) . '</span>'
                );
            }
            ?>
        </h2><!-- .comments-title -->

        <?php the_comments_navigation(); ?>

        <ol class="comment-list">
            <?php
            wp_list_comments(
                array(
                    'style'      => 'ol',
                    'short_ping' => true,
                    'avatar_size' => 60,
                    'callback'   => 'zayxyz_comment_callback',
                )
            );
            ?>
        </ol><!-- .comment-list -->

        <?php
        the_comments_navigation();

        // If comments are closed and there are comments, let's leave a little note, shall we?
        if (!comments_open()) :
            ?>
            <p class="no-comments alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                <?php esc_html_e('Comments are closed.', 'zayxyz'); ?>
            </p>
            <?php
        endif;

    endif; // Check for have_comments().

    // Custom comment form
    $commenter = wp_get_current_commenter();
    $req = get_option('require_name_email');
    $html_req = ($req ? " required='required'" : '');

    $fields = array(
        'author' => '<div class="row"><div class="col-md-6"><div class="form-group mb-3"><label for="author" class="form-label">' . __('Name', 'zayxyz') . ($req ? ' <span class="required text-danger">*</span>' : '') . '</label><input id="author" name="author" type="text" class="form-control" value="' . esc_attr($commenter['comment_author']) . '" size="30" maxlength="245"' . $html_req . '></div></div>',
        'email'  => '<div class="col-md-6"><div class="form-group mb-3"><label for="email" class="form-label">' . __('Email', 'zayxyz') . ($req ? ' <span class="required text-danger">*</span>' : '') . '</label><input id="email" name="email" type="email" class="form-control" value="' . esc_attr($commenter['comment_author_email']) . '" size="30" maxlength="100" aria-describedby="email-notes"' . $html_req . '></div></div></div>',
        'url'    => '<div class="form-group mb-3"><label for="url" class="form-label">' . __('Website', 'zayxyz') . '</label><input id="url" name="url" type="url" class="form-control" value="' . esc_attr($commenter['comment_author_url']) . '" size="30" maxlength="200"></div>',
    );

    $comments_args = array(
        'fields'               => $fields,
        'comment_field'        => '<div class="form-group mb-3"><label for="comment" class="form-label">' . _x('Comment', 'noun', 'zayxyz') . ' <span class="required text-danger">*</span></label><textarea id="comment" name="comment" class="form-control" rows="5" maxlength="65525" required="required" placeholder="' . esc_attr__('Write your comment here...', 'zayxyz') . '"></textarea></div>',
        'class_form'           => 'comment-form',
        'class_submit'         => 'btn btn-primary',
        'title_reply'          => '<h3 class="reply-title">' . __('Leave a Comment', 'zayxyz') . '</h3>',
        'title_reply_to'       => '<h3 class="reply-title">' . __('Reply to %s', 'zayxyz') . '</h3>',
        'cancel_reply_link'    => '<span class="btn btn-outline-secondary btn-sm">' . __('Cancel Reply', 'zayxyz') . '</span>',
        'label_submit'         => __('Post Comment', 'zayxyz'),
        'format'               => 'html5',
    );

    comment_form($comments_args);
    ?>

</div><!-- #comments --> 