<?php
/**
 * The template for displaying search forms
 *
 * @package ZayXYZ
 */

?>

<form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
    <div class="input-group">
        <input type="search" 
               class="form-control" 
               placeholder="<?php echo esc_attr_x('Search for...', 'placeholder', 'zayxyz'); ?>" 
               value="<?php echo get_search_query(); ?>" 
               name="s" 
               aria-label="<?php echo esc_attr_x('Search for:', 'label', 'zayxyz'); ?>"
               required>
        <button class="btn btn-primary" type="submit" aria-label="<?php echo esc_attr_x('Search', 'submit button', 'zayxyz'); ?>">
            <i class="fas fa-search"></i>
            <span class="d-none d-sm-inline ms-1"><?php echo esc_html_x('Search', 'submit button', 'zayxyz'); ?></span>
        </button>
    </div>
</form> 