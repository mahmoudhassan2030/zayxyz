<?php
$slides = array();
for ($i = 1; $i <= 6; $i++) {
    $img = get_theme_mod("slider_image_$i");
    $img_url = '';
    if (!empty($img)) {
        if (is_numeric($img)) {
            $img_url = wp_get_attachment_url($img);
        } elseif (filter_var($img, FILTER_VALIDATE_URL)) {
            $img_url = $img;
        }
    }
    $bg_color = get_theme_mod("slider_bg_color_$i", '#ffffff');
    $title = get_theme_mod("slider_title_$i");
    $sub_title = get_theme_mod("slider_sub_title_$i");
    $desc = get_theme_mod("slider_desc_$i");
    $btn_text = get_theme_mod("slider_button_text_$i");
    $btn_url = get_theme_mod("slider_button_url_$i");
    if ($img_url) {
        $slides[] = array(
            'img' => $img_url,
            'bg_color' => $bg_color,
            'title' => $title,
            'sub_title' => $sub_title,
            'desc' => $desc,
            'btn_text' => $btn_text,
            'btn_url' => $btn_url,
        );
    }
}
?>
<div id="custom-home-slider" class="carousel slide" data-bs-ride="carousel" data-aos="fade-up">
    <?php if (!empty($slides)) : ?>
        <ol class="carousel-indicators">
            <?php foreach ($slides as $i => $slide) : ?>
                <li data-bs-target="#custom-home-slider" data-bs-slide-to="<?php echo esc_attr($i); ?>" class="<?php echo ($i === 0) ? 'active' : ''; ?>"></li>
            <?php endforeach; ?>
        </ol>
        <div class="carousel-inner">
            <?php foreach ($slides as $i => $slide) : ?>
                <div class="carousel-item <?php echo ($i === 0) ? 'active' : ''; ?>" style="background: <?php echo esc_attr($slide['bg_color']); ?>;">
                    <div class="container">
                        <div class="row align-items-center min-vh-70 py-5">
                            <div class="col-lg-6 mb-5 mb-lg-0" data-aos="fade-right">
                                <div class="px-4">
                                    <?php if (!empty($slide['title'])) : ?>
                                        <h1 class="display-4 fw-bold mb-3"><?php echo esc_html($slide['title']); ?></h1>
                                    <?php endif; ?>
                                    <h3 class="h2 text-primary mb-4">
                                        <?php echo !empty($slide['sub_title']) ? esc_html($slide['sub_title']) : ''; ?>
                                    </h3>
                                    <?php if (!empty($slide['desc'])) : ?>
                                        <p class="lead mb-4"><?php echo wp_kses_post($slide['desc']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-lg-6" data-aos="zoom-in">
                                <div class="position-relative text-center">
                                    <img class="img-fluid rounded-3 shadow-lg animated" src="<?php echo esc_url($slide['img']); ?>" alt="Slide <?php echo esc_attr($i+1); ?>">
                                    <?php if (!empty($slide['btn_text'])) : ?>
                                        <a href="<?php echo esc_url($slide['btn_url']); ?>" class="btn btn-primary mt-3 position-absolute top-100 start-50 translate-middle-x">
                                            <?php echo esc_html($slide['btn_text']); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#custom-home-slider" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden"><?php esc_html_e('Previous', 'zayxyz'); ?></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#custom-home-slider" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden"><?php esc_html_e('Next', 'zayxyz'); ?></span>
        </button>
    <?php else : ?>
        <div class="alert alert-info text-center py-5 my-5">
            <h4><?php esc_html_e('No slides available', 'zayxyz'); ?></h4>
            <p><?php esc_html_e('Please add slides from the Customizer (Appearance > Customize > Slider Settings)', 'zayxyz'); ?></p>
        </div>
    <?php endif; ?>
</div> 