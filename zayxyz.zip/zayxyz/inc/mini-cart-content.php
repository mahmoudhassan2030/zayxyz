<?php
/**
 * Mini-cart content
 *
 * @package WordPress
 * @subpackage zayxyz
 * @since zayxyz 1.0
 */
?>
<!-- Updated Cart Dropdown - محسن -->
<div class="cart-dropdown">
    <a class="nav-icon position-relative text-decoration-none" href="<?php echo esc_url(wc_get_cart_url()); ?>" title="View Cart">
        <i class="fa fa-fw fa-shopping-cart"></i>
        <span class="position-absolute top-0 left-100 translate-middle badge rounded-pill cart-count cart-count-badge">
            <?php echo WC()->cart->get_cart_contents_count(); ?>
        </span>
        <span class="cart-total-text"><?php echo WC()->cart->get_cart_total(); ?></span>
    </a>
    <div class="cart-dropdown-content">
        <div class="cart-items">
            <?php
            $cart_items = WC()->cart->get_cart();
            
            if (empty($cart_items)) : ?>
                <div class="text-center py-4">
                    <i class="fas fa-shopping-cart fa-2x text-muted mb-3"></i>
                    <p class="mb-0 text-muted"><?php esc_html_e('Cart is empty', 'textdomain'); ?></p>
                </div>
            <?php else : 
                foreach ($cart_items as $cart_item_key => $cart_item) :
                    $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                    $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
                    
                    if ($_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_cart_item_visible', true, $cart_item, $cart_item_key)) :
                        $product_permalink = apply_filters('woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink($cart_item) : '', $cart_item, $cart_item_key);
                        ?>
                        <div class="cart-item" data-key="<?php echo esc_attr($cart_item_key); ?>">
                            <div class="cart-item-image-container">
                                <?php
                                $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key);
                                if (!$product_permalink) {
                                    echo $thumbnail;
                                } else {
                                    printf('<a href="%s">%s</a>', esc_url($product_permalink), $thumbnail);
                                }
                                ?>
                            </div>
                            <div class="cart-item-details">
                                <div class="cart-item-title">
                                    <?php
                                    if (!$product_permalink) {
                                        echo wp_kses_post(apply_filters(
                                            'woocommerce_cart_item_name', 
                                            $_product->get_name(), 
                                            $cart_item, 
                                            $cart_item_key
                                        )) . '&nbsp;';
                                    } else {
                                        $product_link = sprintf(
                                            '<a href="%s">%s</a>',
                                            esc_url($product_permalink),
                                            $_product->get_name()
                                        );
                                        
                                        echo wp_kses_post(apply_filters(
                                            'woocommerce_cart_item_name',
                                            $product_link,
                                            $cart_item,
                                            $cart_item_key
                                        ));
                                    }
                                    ?>
                                </div>
                                <div class="cart-item-price">
                                    <?php echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key); ?>
                                </div>
                                <div class="cart-item-quantity">
                                    <span class="quantity-btn minus" data-key="<?php echo esc_attr($cart_item_key); ?>" title="Decrease quantity">
                                        <i class="fas fa-minus"></i>
                                    </span>
                                    <input type="number" class="quantity-input" 
                                        value="<?php echo $cart_item['quantity']; ?>" 
                                        min="1" 
                                        data-key="<?php echo esc_attr($cart_item_key); ?>">
                                    <span class="quantity-btn plus" data-key="<?php echo esc_attr($cart_item_key); ?>" title="Increase quantity">
                                        <i class="fas fa-plus"></i>
                                    </span>
                                    <span class="remove-item" data-key="<?php echo esc_attr($cart_item_key); ?>" title="Remove item">
                                        <i class="fas fa-trash"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endif;
                endforeach;
            endif; ?>
        </div>
        <div class="cart-summary">
            <div class="cart-total" style="font-size:1.1rem;font-weight:700;display:flex;justify-content:space-between;padding:10px 0 0 0;">
                <span><?php esc_html_e('Total', 'textdomain'); ?>:</span>
                <span><?php echo WC()->cart->get_cart_total(); ?></span>
            </div>
            <?php if (!empty($cart_items)) : ?>
            <div class="cart-buttons">
                <a href="<?php echo esc_url(wc_get_cart_url()); ?>" class="btn btn-outline-primary">
                    <?php esc_html_e('View Cart', 'textdomain'); ?>
                </a>
                <a href="<?php echo esc_url(wc_get_checkout_url()); ?>" class="btn btn-primary">
                    <?php esc_html_e('Checkout', 'textdomain'); ?>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div> 