<?php
/**
 * Custom Price Filter Widget
 */
class codevers2e_Price_Filter_Widget extends WC_Widget {
    
    public function __construct() {
        $this->widget_cssclass = 'woocommerce widget_price_filter';
        $this->widget_description = __('Display a slider to filter products in your store by price.', 'woocommerce');
        $this->widget_id = 'codevers2e_price_filter';
        $this->widget_name = __('Price Filter Slider', 'woocommerce');
        $this->settings = array(
            'title' => array(
                'type' => 'text',
                'std' => __('Filter by price', 'woocommerce'),
                'label' => __('Title', 'woocommerce'),
            ),
        );
        
        parent::__construct();
    }
    
    public function widget($args, $instance) {
        global $wp;
        
        if (!is_shop() && !is_product_taxonomy()) {
            return;
        }
        
        wp_enqueue_script('wc-price-slider');
        
        // Find min and max price in current result set
        $prices = $this->get_filtered_price();
        $min = floor($prices->min_price);
        $max = ceil($prices->max_price);
        
        if ($min === $max) {
            return;
        }
        
        // Set max to 10000 if it's less than that
        $max = max($max, 10000);
        
        $min_price = isset($_GET['min_price']) ? wc_clean(wp_unslash($_GET['min_price'])) : $min;
        $max_price = isset($_GET['max_price']) ? wc_clean(wp_unslash($_GET['max_price'])) : $max;
        
        echo $args['before_widget'];
        
        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title'], $instance, $this->id_base) . $args['after_title'];
        }
        
        $step = max(apply_filters('woocommerce_price_filter_widget_step', 10), 1);
        
        wp_localize_script(
            'wc-price-slider',
            'woocommerce_price_slider_params',
            array(
                'currency_format_num_decimals' => 0,
                'currency_format_symbol' => get_woocommerce_currency_symbol(),
                'currency_format_decimal_sep' => esc_attr(wc_get_price_decimal_separator()),
                'currency_format_thousand_sep' => esc_attr(wc_get_price_thousand_separator()),
                'currency_format' => esc_attr(str_replace(array('%1$s', '%2$s'), array('%s', '%v'), get_woocommerce_price_format())),
            )
        );
        
        $base_link = $this->get_current_page_url();
        ?>
        
        <form method="get" action="<?php echo esc_url($base_link); ?>" class="price_slider_wrapper">
            <div class="price_slider" style="display:none;"></div>
            <div class="price_slider_amount" data-step="<?php echo esc_attr($step); ?>">
                <input type="text" id="min_price" name="min_price" value="<?php echo esc_attr($min_price); ?>" data-min="<?php echo esc_attr($min); ?>" placeholder="<?php echo esc_attr__('Min price', 'woocommerce'); ?>" />
                <input type="text" id="max_price" name="max_price" value="<?php echo esc_attr($max_price); ?>" data-max="<?php echo esc_attr($max); ?>" placeholder="<?php echo esc_attr__('Max price', 'woocommerce'); ?>" />
                <button type="submit" class="button"><?php echo esc_html__('Filter', 'woocommerce'); ?></button>
                <div class="price_label" style="display:none;">
                    <?php echo esc_html__('Price:', 'woocommerce'); ?> <span class="from"></span> &mdash; <span class="to"></span>
                </div>
                <?php echo wc_query_string_form_fields(null, array('min_price', 'max_price', 'paged'), '', true); ?>
                <div class="clear"></div>
            </div>
        </form>
        
        <?php
        echo $args['after_widget'];
    }
    
    protected function get_filtered_price() {
        global $wpdb;
        
        $args = WC()->query->get_main_query()->query_vars;
        $tax_query = isset($args['tax_query']) ? $args['tax_query'] : array();
        $meta_query = isset($args['meta_query']) ? $args['meta_query'] : array();
        
        if (!is_post_type_archive('product') && !empty($args['taxonomy']) && !empty($args['term'])) {
            $tax_query[] = WC()->query->get_main_tax_query();
        }
        
        foreach ($meta_query + $tax_query as $key => $query) {
            if (!empty($query['price_filter']) || !empty($query['rating_filter'])) {
                unset($meta_query[$key]);
            }
        }
        
        $meta_query = new WP_Meta_Query($meta_query);
        $tax_query = new WP_Tax_Query($tax_query);
        $meta_query_sql = $meta_query->get_sql('post', $wpdb->posts, 'ID');
        $tax_query_sql = $tax_query->get_sql($wpdb->posts, 'ID');
        
        $sql = "SELECT min( FLOOR( price_meta.meta_value ) ) as min_price, max( CEILING( price_meta.meta_value ) ) as max_price FROM {$wpdb->posts} ";
        $sql .= " LEFT JOIN {$wpdb->postmeta} as price_meta ON {$wpdb->posts}.ID = price_meta.post_id " . $tax_query_sql['join'] . $meta_query_sql['join'];
        $sql .= " WHERE {$wpdb->posts}.post_type IN ('" . implode("','", array_map('esc_sql', apply_filters('woocommerce_price_filter_post_type', array('product')))) . "')
            AND {$wpdb->posts}.post_status = 'publish'
            AND price_meta.meta_key IN ('" . implode("','", array_map('esc_sql', apply_filters('woocommerce_price_filter_meta_keys', array('_price')))) . "')
            AND price_meta.meta_value > '' ";
        $sql .= $tax_query_sql['where'] . $meta_query_sql['where'];
        
        return $wpdb->get_row($sql);
    }
    
    protected function get_current_page_url() {
        if (defined('SHOP_IS_ON_FRONT')) {
            $link = home_url();
        } elseif (is_shop()) {
            $link = get_permalink(wc_get_page_id('shop'));
        } elseif (is_product_category()) {
            $link = get_term_link(get_query_var('product_cat'), 'product_cat');
        } elseif (is_product_tag()) {
            $link = get_term_link(get_query_var('product_tag'), 'product_tag');
        } else {
            $queried_object = get_queried_object();
            $link = get_term_link($queried_object->slug, $queried_object->taxonomy);
        }
        
        return $link;
    }
}

function enqueue_price_filter_scripts() {
    wp_enqueue_script('jquery-ui-core');
    wp_enqueue_script('jquery-ui-slider');
    wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
    
    // إضافة سكريبت مخصص لتهيئة السلايدر
    wp_add_inline_script('jquery-ui-slider', '
        jQuery(document).ready(function($) {
            $("#price-range").slider({
                range: true,
                min: 0,
                max: 10000,
                values: [
                    parseInt($(".min_price").val() || 0),
                    parseInt($(".max_price").val() || 10000)
                ],
                slide: function(event, ui) {
                    $("#price-min").text(accounting.formatMoney(ui.values[0], {
                        symbol: "$",
                        format: "%s%v"
                    }));
                    $("#price-max").text(accounting.formatMoney(ui.values[1], {
                        symbol: "$",
                        format: "%s%v"
                    }));
                    $(".min_price").val(ui.values[0]);
                    $(".max_price").val(ui.values[1]);
                }
            });
        });
    ');
}
add_action('wp_enqueue_scripts', 'enqueue_price_filter_scripts');



// 1. Price: show first variation price instead of a range
add_filter( 'woocommerce_variable_price_html', 'zayxyz_first_variation_price', 10, 2 );
function zayxyz_first_variation_price( $price_html, $product ) {
    if ( $product instanceof WC_Product_Variable ) {
        $variations = $product->get_available_variations();
        if ( ! empty( $variations ) ) {
            $first          = $variations[0];
            $sale_price     = $first['display_price'];
            $regular_price  = $first['display_regular_price'];

            $price_html = ( $sale_price < $regular_price )
                ? wc_format_sale_price( $regular_price, $sale_price )
                : wc_price( $sale_price );
        }
    }
    return $price_html;
}

function zayxyz_body_classes($classes) {
    // ... existing code ...
}