<?php
// --- Newsletter Subscription: Save Email to DB and Admin Page ---
// إنشاء جدول المشتركين إذا لم يكن موجوداً
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table = $wpdb->prefix . 'footer_subscribers';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $table (
        id INT NOT NULL AUTO_INCREMENT,
        email VARCHAR(255) NOT NULL,
        subscribed_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY email (email)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
});

// إضافة صفحة في لوحة التحكم لعرض المشتركين
add_action('admin_menu', function() {
    add_menu_page(
        __('Footer Subscribers','codevers2e'),
        __('Footer Subscribers','codevers2e'),
        'manage_options',
        'footer-subscribers',
        'show_footer_subscribers',
        'dashicons-email-alt',
        26
    );
});

function show_footer_subscribers() {
    global $wpdb;
    $table = $wpdb->prefix . 'footer_subscribers';
    $results = $wpdb->get_results("SELECT * FROM $table ORDER BY subscribed_at DESC");
    echo '<a href="' . admin_url('admin-ajax.php?action=download_footer_subscribers_csv') . '" class="button button-primary" style="margin-bottom:15px;">' . __('Download all emails (CSV)', 'codevers2e') . '</a>';
    ?>
    <div class="wrap">
        <h1><?php _e('Footer Subscribers','codevers2e'); ?></h1>
        <table class="widefat">
            <thead>
                <tr>
                    <th><?php _e('Email','codevers2e'); ?></th>
                    <th><?php _e('Subscribed At','codevers2e'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row): ?>
                    <tr>
                        <td><?php echo esc_html($row->email); ?></td>
                        <td><?php echo esc_html($row->subscribed_at); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// نقطة نهاية لتحميل CSV
add_action('admin_init', function() {
    if (isset($_GET['action']) && $_GET['action'] === 'download_footer_subscribers_csv' && current_user_can('manage_options')) {
        global $wpdb;
        $table = $wpdb->prefix . 'footer_subscribers';
        $results = $wpdb->get_results("SELECT email, subscribed_at FROM $table ORDER BY subscribed_at DESC", ARRAY_A);
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=footer_subscribers.csv');
        $output = fopen('php://output', 'w');
        fputcsv($output, array('Email', 'Subscribed At'));
        foreach ($results as $row) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit;
    }
});

// نقطة نهاية AJAX للاشتراك في النشرة البريدية
// AJAX endpoint for newsletter subscription
add_action('wp_ajax_footer_subscribe','footer_subscribe_ajax_handler');
add_action('wp_ajax_nopriv_footer_subscribe','footer_subscribe_ajax_handler');
function footer_subscribe_ajax_handler() {
    check_ajax_referer('footer_subscribe', 'subscribe_nonce');
    $email = isset($_POST['subscribe_email']) ? sanitize_email($_POST['subscribe_email']) : '';
    if (!is_email($email)) {
        wp_send_json_error(['message' => 'Invalid email address.']);
    }
    global $wpdb;
    $table = $wpdb->prefix . 'footer_subscribers';
    $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE email = %s", $email));
    if ($exists) {
        wp_send_json_error(['message' => 'This email is already subscribed.']);
    }
    $wpdb->insert($table, [
        'email' => $email,
        'subscribed_at' => current_time('mysql')
    ]);
    wp_send_json_success(['message' => 'Subscribed successfully!']);
}

add_action('admin_head-nav-menus.php', function() {
    echo '<style>
        #add-category { display: none !important; }
    </style>';
});

// Full-featured product search including title, content, excerpt, SKU, and short description.
function zayxyz_comprehensive_product_search($search, $wp_query) {
    global $wpdb;
    
    // Apply only on frontend product searches
    if (!is_admin() && $wp_query->is_search() && isset($wp_query->query_vars['s'])) {
        $search_term = $wp_query->query_vars['s'];
        
        if (empty($search_term)) {
            return $search;
        }

        // Check if this is a product search
        $post_type = $wp_query->get('post_type');
        if ($post_type !== 'product' && !(is_array($post_type) && in_array('product', $post_type))) {
            // If not a product search, return default search
             return $search;
        }

        $like_term = '%' . $wpdb->esc_like($search_term) . '%';
        
        // Start building a new comprehensive search query
        $search_sql = $wpdb->prepare(
            " AND (
                ({$wpdb->posts}.post_title LIKE %s)
                OR ({$wpdb->posts}.post_excerpt LIKE %s)
                OR ({$wpdb->posts}.post_content LIKE %s)
                OR EXISTS (
                    SELECT 1 FROM {$wpdb->postmeta}
                    WHERE post_id = {$wpdb->posts}.ID
                    AND meta_key = '_sku'
                    AND meta_value LIKE %s
                )
                OR EXISTS (
                    SELECT 1 FROM {$wpdb->postmeta}
                    WHERE post_id = {$wpdb->posts}.ID
                    AND meta_key = '_short_description'
                    AND meta_value LIKE %s
                )
            )",
            $like_term,
            $like_term,
            $like_term,
            $like_term,
            $like_term
        );
        
        return $search_sql;
    }
    
    return $search;
}
add_filter('posts_search', 'zayxyz_comprehensive_product_search', 10, 2);
