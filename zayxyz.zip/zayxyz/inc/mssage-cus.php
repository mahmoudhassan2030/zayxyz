<?php
// إنشاء قائمة الإدارة
// Create the admin menu
add_action('admin_menu', 'register_contact_messages_page');

function register_contact_messages_page() {
    add_menu_page(
        'Contact Messages',
        'Contact Messages',
        'manage_options',
        'contact-messages',
        'display_contact_messages_page',
        'dashicons-email-alt',
        25
    );
}

// دالة عرض الصفحة
// Function to display the page
function display_contact_messages_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'contact_messages';
    
    // جلب الرسائل مع ترقيم الصفحات
    // Fetch messages with pagination
    $paged = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
    $per_page = 20;
    $offset = ($paged - 1) * $per_page;
    
    $messages = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name ORDER BY submitted_at DESC LIMIT %d OFFSET %d",
        $per_page,
        $offset
    ));
    
    $total_messages = $wpdb->get_var("SELECT COUNT(id) FROM $table_name");
    $total_pages = ceil($total_messages / $per_page);
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">Contact Messages</h1>
        
        <div style="margin-bottom: 20px;">
            <a href="<?php echo admin_url('admin.php?page=contact-messages&export=csv'); ?>" class="button">
                Export to CSV
            </a>
        </div>
        
        <?php if (empty($messages)) : ?>
            <div class="notice notice-info">
                <p>No messages found.</p>
            </div>
        <?php else : ?>
            <?php if ($total_pages > 1) : ?>
                <div class="tablenav top">
                    <div class="tablenav-pages">
                        <?php
                        echo paginate_links(array(
                            'base' => add_query_arg('paged', '%#%'),
                            'format' => '',
                            'prev_text' => __('&laquo;'),
                            'next_text' => __('&raquo;'),
                            'total' => $total_pages,
                            'current' => $paged
                        ));
                        ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Subject</th>
                        <th>Message</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($messages as $message) : ?>
                    <tr>
                        <td><?php echo $message->id; ?></td>
                        <td><?php echo esc_html($message->name); ?></td>
                        <td><?php echo esc_html($message->email); ?></td>
                        <td><?php echo esc_html($message->phone); ?></td>
                        <td><?php echo esc_html($message->subject); ?></td>
                        <td><?php echo esc_html(wp_trim_words($message->message, 10)); ?></td>
                        <td><?php echo date('Y-m-d H:i', strtotime($message->submitted_at)); ?></td>
                        <td>
                            <a href="#" class="view-message button" data-message="<?php echo esc_attr($message->message); ?>">View</a>
                            <a href="<?php echo wp_nonce_url(
                                admin_url('admin.php?page=contact-messages&delete=' . $message->id),
                                'delete_message_' . $message->id
                            ); ?>" class="button delete-message">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <?php if ($total_pages > 1) : ?>
                <div class="tablenav bottom">
                    <div class="tablenav-pages">
                        <?php
                        echo paginate_links(array(
                            'base' => add_query_arg('paged', '%#%'),
                            'format' => '',
                            'prev_text' => __('&laquo;'),
                            'next_text' => __('&raquo;'),
                            'total' => $total_pages,
                            'current' => $paged
                        ));
                        ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <div id="messageModal" style="display:none;">
                <div style="padding: 20px; background: white; max-width: 600px; margin: 20px auto;">
                    <h3>Message Details</h3>
                    <div id="messageContent" style="white-space: pre-wrap; margin: 15px 0; padding: 15px; border: 1px solid #ddd;"></div>
                    <button id="closeModal" class="button">Close</button>
                </div>
            </div>
            
            <script>
            jQuery(document).ready(function($) {
                $('.view-message').on('click', function(e) {
                    e.preventDefault();
                    const message = $(this).data('message');
                    $('#messageContent').text(message);
                    $('#messageModal').show();
                });
                
                $('#closeModal').on('click', function() {
                    $('#messageModal').hide();
                });
                
                $('.delete-message').on('click', function(e) {
                    if (!confirm('Are you sure you want to delete this message?')) {
                        e.preventDefault();
                    }
                });
            });
            </script>
            
            <style>
            #messageModal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.7);
                z-index: 9999;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            </style>
        <?php endif; ?>
    </div>
    <?php
}

// تصدير الرسائل إلى CSV قبل أي مخرجات HTML
// Export messages to CSV before any HTML output
add_action('admin_init', 'export_contact_messages_csv');
function export_contact_messages_csv() {
    if (isset($_GET['page']) && $_GET['page'] === 'contact-messages' && isset($_GET['export']) && $_GET['export'] === 'csv') {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized access');
        }
        global $wpdb;
        $table_name = $wpdb->prefix . 'contact_messages';
        $messages = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC");
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=contact-messages-' . date('Y-m-d') . '.csv');
        // دعم العربية في الإكسل
        // Support for Arabic in Excel (can be removed if not needed)
        echo "\xEF\xBB\xBF";
        $output = fopen('php://output', 'w');
        fputcsv($output, array('ID', 'Name', 'Email', 'Phone', 'Subject', 'Message', 'Date'));
        foreach ($messages as $message) {
            fputcsv($output, array(
                $message->id,
                $message->name,
                $message->email,
                $message->phone,
                $message->subject,
                $message->message,
                $message->submitted_at
            ));
        }
        fclose($output);
        exit;
    }
}

// معالجة حذف الرسائل
// Handle message deletion
add_action('admin_init', 'handle_message_deletion');

function handle_message_deletion() {
    if (isset($_GET['delete'])) {
        // التحقق من الصلاحيات
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized access');
        }
        
        // التحقق من الـ nonce
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'delete_message_' . $_GET['delete'])) {
            wp_die('Security check failed');
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'contact_messages';
        $message_id = intval($_GET['delete']);
        
        $result = $wpdb->delete(
            $table_name,
            ['id' => $message_id],
            ['%d']
        );
        
        if ($result) {
            wp_redirect(admin_url('admin.php?page=contact-messages&deleted=1'));
            exit;
        } else {
            wp_redirect(admin_url('admin.php?page=contact-messages&error=1'));
            exit;
        }
    }
}

// إضافة إشعارات بعد الحذف
add_action('admin_notices', 'display_deletion_notices');

function display_deletion_notices() {
    if (isset($_GET['deleted'])) {
        echo '<div class="notice notice-success"><p>Message deleted successfully.</p></div>';
    } elseif (isset($_GET['error'])) {
        echo '<div class="notice notice-error"><p>Error deleting message.</p></div>';
    }
}