<?php
/**
 * ZayXYZ Theme Customizer - Home Settings (All in one section)
 */

function zayxyz_customize_register_home($wp_customize) {
    // قسم رئيسي واحد للصفحة الرئيسية
    $wp_customize->add_section('home_settings', array(
        'title'    => __('Home Settings', 'textdomain'),
        'priority' => 10,
    ));

    // قسم جديد لإعدادات الجسم (Body Settings)
    $wp_customize->add_section('zayxyz_body_settings', array(
        'title'    => __('Body Settings', 'zayxyz'),
        'priority' => 20,
    ));

    // قسم إعدادات العروض (Offer Settings)
    $wp_customize->add_section('zayxyz_offer_settings', array(
        'title'    => __('Offer Settings', 'zayxyz'),
        'priority' => 30,
    ));

    // قسم إعدادات الفوتر (Footer Settings)
    $wp_customize->add_section('zayxyz_footer_settings', array(
        'title'    => __('Footer Settings', 'zayxyz'),
        'priority' => 40,
    ));

    // قسم جديد للسلادير
    $wp_customize->add_section('slider_settings', array(
        'title'    => __('Slider Settings', 'zayxyz'),
        'priority' => 25,
    ));

    // [1] شعار الموقع
    $wp_customize->add_setting('site_logo_text', array(
        'default'   => get_bloginfo('name'),
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('site_logo_text', array(
        'label'    => __('Site Logo Text', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'site_logo_text',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('force_logo_text', array(
        'default'   => false,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('force_logo_text', array(
        'label'    => __('Always show logo as text (ignore image)', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'force_logo_text',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('site_logo_color', array(
        'default'   => '#59ab6e',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'site_logo_color', array(
        'label'    => __('Logo Text Color', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'site_logo_color',
    )));

    // [2] وسائل التواصل الاجتماعي
    $wp_customize->add_setting('show_social_icons', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('show_social_icons', array(
        'label'    => __('Show Social Icons', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'show_social_icons',
        'type'     => 'checkbox',
    ));
    $socials = array('facebook','twitter','instagram','linkedin','youtube','whatsapp');
    foreach ($socials as $social) {
        $wp_customize->add_setting('social_'.$social, array(
            'default'   => '',
            'transport' => 'refresh',
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control('social_'.$social, array(
            'label'    => __(ucfirst($social).' URL', 'zayxyz'),
            'section'  => 'home_settings',
            'settings' => 'social_'.$social,
            'type'     => 'url',
        ));
        $wp_customize->add_setting('show_'.$social.'_icon', array(
            'default'   => true,
            'transport' => 'refresh',
            'sanitize_callback' => 'wp_validate_boolean',
        ));
        $wp_customize->add_control('show_'.$social.'_icon', array(
            'label'    => __('Show '.ucfirst($social).' Icon', 'zayxyz'),
            'section'  => 'home_settings',
            'settings' => 'show_'.$social.'_icon',
            'type'     => 'checkbox',
        ));
    }

    // [2.1] لون أيقونات السوشيال ميديا
    $wp_customize->add_setting('social_icons_color', array(
        'default'   => '#ffffff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'social_icons_color', array(
        'label'    => __('Social Icons Color', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'social_icons_color',
    )));

    // [2.2] لون خلفية الشريط العلوي (الإيميل والهاتف والسوشيال)
    $wp_customize->add_setting('topbar_bg_color', array(
        'default'   => '#222',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'topbar_bg_color', array(
        'label'    => __('Top Bar Background Color', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'topbar_bg_color',
    )));

    // [3] البريد الإلكتروني
    $wp_customize->add_setting('company_email', array(
        'default'   => 'info@company.com',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_email',
    ));
    $wp_customize->add_control('company_email', array(
        'label'    => __('Company Email', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'company_email',
        'type'     => 'email',
    ));

    // [3.1] لون نص الإيميل
    $wp_customize->add_setting('email_text_color', array(
        'default'   => '#ffffff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'email_text_color', array(
        'label'    => __('Email Text Color', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'email_text_color',
    )));

    // [3.2] لون أيقونة الإيميل
    $wp_customize->add_setting('email_icon_color', array(
        'default'   => '#ffffff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'email_icon_color', array(
        'label'    => __('Email Icon Color', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'email_icon_color',
    )));

    // [4] رقم الهاتف
    $wp_customize->add_setting('company_phone', array(
        'default'   => '010-020-0340',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('company_phone', array(
        'label'    => __('Company Phone', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'company_phone',
        'type'     => 'text',
    ));

    // [4.1] لون نص التليفون
    $wp_customize->add_setting('phone_text_color', array(
        'default'   => '#ffffff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'phone_text_color', array(
        'label'    => __('Phone Text Color', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'phone_text_color',
    )));

    // [4.2] لون أيقونة التليفون
    $wp_customize->add_setting('phone_icon_color', array(
        'default'   => '#ffffff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'phone_icon_color', array(
        'label'    => __('Phone Icon Color', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'phone_icon_color',
    )));

    // إعدادات قسم Categories of The Month
    $wp_customize->add_setting('categories_section_title', array(
        'default'   => 'CATEGORIES OF THE MONTH!',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('categories_section_title', array(
        'label'    => __('Categories Section Title', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'categories_section_title',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('categories_section_desc', array(
        'default'   => 'Discover our curated collection of premium products!',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('categories_section_desc', array(
        'label'    => __('Categories Section Description', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'categories_section_desc',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('categories_title_color', array(
        'default'   => '#1565c0',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'categories_title_color', array(
        'label'    => __('Categories Title Color', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'categories_title_color',
    )));
    $wp_customize->add_setting('categories_desc_color', array(
        'default'   => '#1976d2',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'categories_desc_color', array(
        'label'    => __('Categories Description Color', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'categories_desc_color',
    )));
    // زر القسم
    $wp_customize->add_setting('categories_btn_show', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('categories_btn_show', array(
        'label'    => __('Show Categories Button', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'categories_btn_show',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('categories_btn_text', array(
        'default'   => 'Shop Now',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('categories_btn_text', array(
        'label'    => __('Categories Button Text', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'categories_btn_text',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('categories_btn_url', array(
        'default'   => '#',
        'transport' => 'refresh',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('categories_btn_url', array(
        'label'    => __('Categories Button URL', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'categories_btn_url',
        'type'     => 'url',
    ));
    $wp_customize->add_setting('categories_btn_bg', array(
        'default'   => '#1565c0',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'categories_btn_bg', array(
        'label'    => __('Categories Button Background', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'categories_btn_bg',
    )));
    $wp_customize->add_setting('categories_btn_color', array(
        'default'   => '#fff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'categories_btn_color', array(
        'label'    => __('Categories Button Text Color', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'categories_btn_color',
    )));

    // إعدادات قسم Product Spotlight
    $wp_customize->add_setting('spotlight_section_title', array(
        'default'   => 'Product Spotlight!',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('spotlight_section_title', array(
        'label'    => __('Spotlight Section Title', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'spotlight_section_title',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('spotlight_section_desc', array(
        'default'   => 'Take a closer look at our most recommended items?',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('spotlight_section_desc', array(
        'label'    => __('Spotlight Section Description', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'spotlight_section_desc',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('spotlight_title_color', array(
        'default'   => '#1565c0',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'spotlight_title_color', array(
        'label'    => __('Spotlight Title Color', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'spotlight_title_color',
    )));
    $wp_customize->add_setting('spotlight_desc_color', array(
        'default'   => '#1976d2',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'spotlight_desc_color', array(
        'label'    => __('Spotlight Description Color', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'spotlight_desc_color',
    )));
    // زر القسم
    $wp_customize->add_setting('spotlight_btn_show', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('spotlight_btn_show', array(
        'label'    => __('Show Spotlight Button', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'spotlight_btn_show',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('spotlight_btn_text', array(
        'default'   => 'See More',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('spotlight_btn_text', array(
        'label'    => __('Spotlight Button Text', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'spotlight_btn_text',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('spotlight_btn_url', array(
        'default'   => '#',
        'transport' => 'refresh',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('spotlight_btn_url', array(
        'label'    => __('Spotlight Button URL', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'spotlight_btn_url',
        'type'     => 'url',
    ));
    $wp_customize->add_setting('spotlight_btn_bg', array(
        'default'   => '#1565c0',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'spotlight_btn_bg', array(
        'label'    => __('Spotlight Button Background', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'spotlight_btn_bg',
    )));
    $wp_customize->add_setting('spotlight_btn_color', array(
        'default'   => '#fff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'spotlight_btn_color', array(
        'label'    => __('Spotlight Button Text Color', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'spotlight_btn_color',
    )));

    // إعدادات ألوان الأزرار العامة
    $wp_customize->add_setting('global_btn_bg', array(
        'default'   => '#1565c0',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'global_btn_bg', array(
        'label'    => __('Global Button Background', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'global_btn_bg',
    )));
    $wp_customize->add_setting('global_btn_color', array(
        'default'   => '#fff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'global_btn_color', array(
        'label'    => __('Global Button Text Color', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'global_btn_color',
    )));
    $wp_customize->add_setting('global_btn_bg_hover', array(
        'default'   => '#1976d2',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'global_btn_bg_hover', array(
        'label'    => __('Global Button Hover Background', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'global_btn_bg_hover',
    )));
    $wp_customize->add_setting('global_btn_color_hover', array(
        'default'   => '#fff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'global_btn_color_hover', array(
        'label'    => __('Global Button Hover Text Color', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'global_btn_color_hover',
    )));

    // إظهار/إخفاء القسم
    $wp_customize->add_setting('offer_show', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('offer_show', array(
        'label'    => __('Show Offer Section', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_show',
        'type'     => 'checkbox',
    ));

    // عنوان العرض
    $wp_customize->add_setting('offer_title', array(
        'default'   => 'Special Offer!',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_title', array(
        'label'    => __('Offer Title', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_title',
        'type'     => 'text',
    ));

    // وصف العرض
    $wp_customize->add_setting('offer_desc', array(
        'default'   => 'Get 30% off on all summer collection items. Limited time offer!',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_desc', array(
        'label'    => __('Offer Description', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_desc',
        'type'     => 'text',
    ));

    // لون العنوان
    $wp_customize->add_setting('offer_title_color', array(
        'default'   => '#1565c0',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'offer_title_color', array(
        'label'    => __('Offer Title Color', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_title_color',
    )));

    // لون الوصف
    $wp_customize->add_setting('offer_desc_color', array(
        'default'   => '#1976d2',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'offer_desc_color', array(
        'label'    => __('Offer Description Color', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_desc_color',
    )));

    // نص الزر
    $wp_customize->add_setting('offer_btn_text', array(
        'default'   => 'Shop Now',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_btn_text', array(
        'label'    => __('Offer Button Text', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_btn_text',
        'type'     => 'text',
    ));

    // رابط الزر
    $wp_customize->add_setting('offer_btn_url', array(
        'default'   => '#',
        'transport' => 'refresh',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('offer_btn_url', array(
        'label'    => __('Offer Button URL', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_btn_url',
        'type'     => 'url',
    ));

    // لون خلفية القسم
    $wp_customize->add_setting('offer_bg', array(
        'default'   => '#f5f6fa',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'offer_bg', array(
        'label'    => __('Offer Section Background', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_bg',
    )));

    // صورة العرض 1
    $wp_customize->add_setting('offer_image_1', array(
        'default'   => get_template_directory_uri() . '/assets/img/offer-1.jpg',
        'transport' => 'refresh',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'offer_image_1', array(
        'label'    => __('Offer Image 1', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_image_1',
    )));
    // صورة العرض 2
    $wp_customize->add_setting('offer_image_2', array(
        'default'   => get_template_directory_uri() . '/assets/img/offer-2.jpg',
        'transport' => 'refresh',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'offer_image_2', array(
        'label'    => __('Offer Image 2', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_image_2',
    )));
    // إظهار/إخفاء العداد
    $wp_customize->add_setting('offer_timer_show', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('offer_timer_show', array(
        'label'    => __('Show Offer Timer', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_timer_show',
        'type'     => 'checkbox',
    ));
    // نص العداد
    $wp_customize->add_setting('offer_timer_text', array(
        'default'   => 'Offer ends in:',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_timer_text', array(
        'label'    => __('Offer Timer Text', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_timer_text',
        'type'     => 'text',
    ));
    // تاريخ نهاية العرض
    $wp_customize->add_setting('offer_end_date', array(
        'default'   => date('Y-m-d', strtotime('+7 days')),
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_end_date', array(
        'label'    => __('Offer End Date', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_end_date',
        'type'     => 'date',
    ));
    // وقت نهاية العرض
    $wp_customize->add_setting('offer_end_time', array(
        'default'   => '23:59',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_end_time', array(
        'label'    => __('Offer End Time', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_end_time',
        'type'     => 'time',
    ));
    // لون نص العداد
    $wp_customize->add_setting('offer_timer_color', array(
        'default'   => '#1565c0',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'offer_timer_color', array(
        'label'    => __('Offer Timer Text Color', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_timer_color',
    )));

    // إظهار/إخفاء شريط الخصم
    $wp_customize->add_setting('offer_discount_bar_show', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('offer_discount_bar_show', array(
        'label'    => __('Show Discount Bar', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_discount_bar_show',
        'type'     => 'checkbox',
    ));
    // نص نسبة الخصم
    $wp_customize->add_setting('offer_discount_text', array(
        'default'   => '30% OFF',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_discount_text', array(
        'label'    => __('Discount Text', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_discount_text',
        'type'     => 'text',
    ));
    // لون خلفية شارة الخصم
    $wp_customize->add_setting('offer_discount_color', array(
        'default'   => '#fff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'offer_discount_color', array(
        'label'    => __('Discount Badge Text Color', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_discount_color',
    )));
    // السعر القديم
    $wp_customize->add_setting('offer_old_price', array(
        'default'   => '133',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_old_price', array(
        'label'    => __('Old Price', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_old_price',
        'type'     => 'text',
    ));
    // السعر الجديد
    $wp_customize->add_setting('offer_new_price', array(
        'default'   => '111',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_new_price', array(
        'label'    => __('New Price', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_new_price',
        'type'     => 'text',
    ));
    // لون بداية التدرج لشريط الخصم
    $wp_customize->add_setting('offer_bar_gradient_start', array(
        'default'   => '#ff9800',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'offer_bar_gradient_start', array(
        'label'    => __('Discount Bar Gradient Start', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_bar_gradient_start',
    )));
    // لون نهاية التدرج لشريط الخصم
    $wp_customize->add_setting('offer_bar_gradient_end', array(
        'default'   => '#ffe259',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'offer_bar_gradient_end', array(
        'label'    => __('Discount Bar Gradient End', 'zayxyz'),
        'section'  => 'zayxyz_offer_settings',
        'settings' => 'offer_bar_gradient_end',
    )));

    // لون خلفية الفوتر
    $wp_customize->add_setting('footer_bg_gradient_start', array(
        'default'   => '#283e51',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_bg_gradient_start', array(
        'label'    => __('Footer Background Gradient Start', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_bg_gradient_start',
    )));
    $wp_customize->add_setting('footer_bg_gradient_end', array(
        'default'   => '#485563',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_bg_gradient_end', array(
        'label'    => __('Footer Background Gradient End', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_bg_gradient_end',
    )));
    // وصف الشركة
    $wp_customize->add_setting('footer_tagline', array(
        'default'   => 'Premium products for your everyday needs',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_tagline', array(
        'label'    => __('Footer Company Tagline', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_tagline',
        'type'     => 'text',
    ));
    // نص الحقوق
    $wp_customize->add_setting('footer_copyright_text', array(
        'default'   => '&copy; ' . date('Y') . ' Company Name. All rights reserved.',
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('footer_copyright_text', array(
        'label'    => __('Footer Copyright Text', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_copyright_text',
        'type'     => 'textarea',
    ));
    // ألوان أيقونات السوشيال
    $wp_customize->add_setting('footer_social_icon_color', array(
        'default'   => '#fff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_social_icon_color', array(
        'label'    => __('Footer Social Icon Color', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_social_icon_color',
    )));
    // روابط السوشيال
    $socials = array('facebook','instagram','twitter','linkedin','youtube');
    foreach ($socials as $social) {
        $wp_customize->add_setting('footer_' . $social . '_url', array(
            'default'   => '#',
            'transport' => 'refresh',
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control('footer_' . $social . '_url', array(
            'label'    => __(ucfirst($social) . ' URL', 'zayxyz'),
            'section'  => 'zayxyz_footer_settings',
            'settings' => 'footer_' . $social . '_url',
            'type'     => 'url',
        ));
    }
    // نص الشركة
    $wp_customize->add_setting('footer_company_name', array(
        'default'   => 'Zay Shop',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_company_name', array(
        'label'    => __('Footer Company Name', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_company_name',
        'type'     => 'text',
    ));
    // العنوان
    $wp_customize->add_setting('footer_address', array(
        'default'   => '123 Consectetur at ligula 10660',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_address', array(
        'label'    => __('Footer Address', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_address',
        'type'     => 'text',
    ));
    // الهاتف
    $wp_customize->add_setting('footer_phone', array(
        'default'   => '010-020-0340',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_phone', array(
        'label'    => __('Footer Phone', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_phone',
        'type'     => 'text',
    ));
    // الإيميل
    $wp_customize->add_setting('footer_email', array(
        'default'   => 'info@company.com',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_email',
    ));
    $wp_customize->add_control('footer_email', array(
        'label'    => __('Footer Email', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_email',
        'type'     => 'email',
    ));
    // نص النشرة البريدية
    $wp_customize->add_setting('footer_newsletter_title', array(
        'default'   => 'Newsletter',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_newsletter_title', array(
        'label'    => __('Footer Newsletter Title', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_newsletter_title',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('footer_newsletter_description', array(
        'default'   => 'Subscribe to our newsletter for the latest updates and offers.',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_newsletter_description', array(
        'label'    => __('Footer Newsletter Description', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_newsletter_description',
        'type'     => 'text',
    ));
    // نص وسائل الدفع
    $wp_customize->add_setting('footer_payment_methods_title', array(
        'default'   => 'Accepted payments:',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_payment_methods_title', array(
        'label'    => __('Footer Payment Methods Title', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_payment_methods_title',
        'type'     => 'text',
    ));
    // إظهار/إخفاء أيقونات الدفع
    $wp_customize->add_setting('footer_payment_visa_icon_enabled', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('footer_payment_visa_icon_enabled', array(
        'label'    => __('Show Visa Icon', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_payment_visa_icon_enabled',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('footer_payment_mastercard_icon_enabled', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('footer_payment_mastercard_icon_enabled', array(
        'label'    => __('Show Mastercard Icon', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_payment_mastercard_icon_enabled',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('footer_payment_paypal_icon_enabled', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('footer_payment_paypal_icon_enabled', array(
        'label'    => __('Show Paypal Icon', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_payment_paypal_icon_enabled',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('footer_payment_applepay_icon_enabled', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('footer_payment_applepay_icon_enabled', array(
        'label'    => __('Show ApplePay Icon', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_payment_applepay_icon_enabled',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('footer_payment_amazonpay_icon_enabled', array(
        'default'   => false,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('footer_payment_amazonpay_icon_enabled', array(
        'label'    => __('Show AmazonPay Icon', 'zayxyz'),
        'section'  => 'zayxyz_footer_settings',
        'settings' => 'footer_payment_amazonpay_icon_enabled',
        'type'     => 'checkbox',
    ));

    // إضافة إعداد لون خلفية الموقع بالكامل
    $wp_customize->add_setting('body_bg_color', array(
        'default'   => '#f5f6fa',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'body_bg_color', array(
        'label'    => __('Site Background Color', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'body_bg_color',
    )));

  

    // إعدادات تدرج خلفية الموقع بالكامل
    $wp_customize->add_setting('body_bg_gradient_start', array(
        'default'   => '#f5f6fa',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'body_bg_gradient_start', array(
        'label'    => __('Site Background Gradient Start', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'body_bg_gradient_start',
    )));
    $wp_customize->add_setting('body_bg_gradient_end', array(
        'default'   => '#e0e0e0',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'body_bg_gradient_end', array(
        'label'    => __('Site Background Gradient End', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'body_bg_gradient_end',
    )));
    // إعدادات تدرج الهيدر/القوائم
    $wp_customize->add_setting('header_bg_gradient_start', array(
        'default'   => '#6a82fb',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header_bg_gradient_start', array(
        'label'    => __('Header & Navbar Gradient Start', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'header_bg_gradient_start',
    )));
    $wp_customize->add_setting('header_bg_gradient_end', array(
        'default'   => '#2dce89',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header_bg_gradient_end', array(
        'label'    => __('Header & Navbar Gradient End', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'header_bg_gradient_end',
    )));
    // إعدادات تدرج الشريط العلوي
    $wp_customize->add_setting('topbar_bg_gradient_start', array(
        'default'   => '#59ab6e',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'topbar_bg_gradient_start', array(
        'label'    => __('Top Bar Gradient Start', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'topbar_bg_gradient_start',
    )));
    $wp_customize->add_setting('topbar_bg_gradient_end', array(
        'default'   => '#4a8f5c',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'topbar_bg_gradient_end', array(
        'label'    => __('Top Bar Gradient End', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'settings' => 'topbar_bg_gradient_end',
    )));

    // إضافة لحقول لكل سلايد (حتى 6)
    for ($i = 1; $i <= 6; $i++) {
        $wp_customize->add_setting('slider_image_'.$i, array(
            'default'   => '',
            'transport' => 'refresh',
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'slider_image_'.$i, array(
            'label'    => __('Slider Image #'.$i, 'zayxyz'),
            'section'  => 'slider_settings',
            'settings' => 'slider_image_'.$i,
        )));
        $wp_customize->add_setting('slider_bg_color_'.$i, array(
            'default'   => '#ffffff',
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_hex_color',
        ));
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'slider_bg_color_'.$i, array(
            'label'    => __('Slider Background Color #'.$i, 'zayxyz'),
            'section'  => 'slider_settings',
            'settings' => 'slider_bg_color_'.$i,
        )));
        $wp_customize->add_setting('slider_title_'.$i, array(
            'default'   => __('Slider Title #'.$i, 'zayxyz'),
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('slider_title_'.$i, array(
            'label'    => __('Slider Title #'.$i, 'zayxyz'),
            'section'  => 'slider_settings',
            'settings' => 'slider_title_'.$i,
            'type'     => 'text',
        ));
        $wp_customize->add_setting('slider_sub_title_'.$i, array(
            'default'   => __('Slider Sub Title #'.$i, 'zayxyz'),
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('slider_sub_title_'.$i, array(
            'label'    => __('Slider Sub Title #'.$i, 'zayxyz'),
            'section'  => 'slider_settings',
            'settings' => 'slider_sub_title_'.$i,
            'type'     => 'text',
        ));
        $wp_customize->add_setting('slider_desc_'.$i, array(
            'default'   => __('Slider Description #'.$i, 'zayxyz'),
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_textarea_field',
        ));
        $wp_customize->add_control('slider_desc_'.$i, array(
            'label'    => __('Slider Description #'.$i, 'zayxyz'),
            'section'  => 'slider_settings',
            'settings' => 'slider_desc_'.$i,
            'type'     => 'textarea',
        ));
        $wp_customize->add_setting('slider_button_text_'.$i, array(
            'default'   => __('Learn More', 'zayxyz'),
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('slider_button_text_'.$i, array(
            'label'    => __('Slider Button Text #'.$i, 'zayxyz'),
            'section'  => 'slider_settings',
            'settings' => 'slider_button_text_'.$i,
            'type'     => 'text',
        ));
        $wp_customize->add_setting('slider_button_url_'.$i, array(
            'default'   => '#',
            'transport' => 'refresh',
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control('slider_button_url_'.$i, array(
            'label'    => __('Slider Button URL #'.$i, 'zayxyz'),
            'section'  => 'slider_settings',
            'settings' => 'slider_button_url_'.$i,
            'type'     => 'url',
        ));
    }

    // About Page Panel
    $wp_customize->add_panel('about_page_panel', array(
        'title' => __('About Page Settings', 'codevers2e'),
        'priority' => 50,
        'description' => __('Manage all sections of the About Page.', 'codevers2e')
    ));

    // About Page: Hero Section
    $wp_customize->add_section('about_hero_section', array(
        'title' => __('Hero Section', 'codevers2e'),
        'panel' => 'about_page_panel',
        'priority' => 10
    ));
    $wp_customize->add_setting('about_bg_color', array('default' => '#59ab6e', 'sanitize_callback' => 'sanitize_hex_color'));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'about_bg_color', array('label' => __('Hero Background Color', 'codevers2e'), 'section' => 'about_hero_section')));
    $wp_customize->add_setting('about_title', array('default' => 'About Us', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('about_title', array('label' => __('Hero Title', 'codevers2e'), 'section' => 'about_hero_section'));
    $wp_customize->add_setting('about_description', array('default' => 'Lorem ipsum dolor sit amet...', 'sanitize_callback' => 'wp_kses_post'));
    $wp_customize->add_control('about_description', array('label' => __('Hero Description', 'codevers2e'), 'section' => 'about_hero_section', 'type' => 'textarea'));
    $wp_customize->add_setting('about_image', array('sanitize_callback' => 'esc_url_raw'));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'about_image', array('label' => __('Hero Image', 'codevers2e'), 'section' => 'about_hero_section')));
    $wp_customize->add_setting('about_image_width', array('default' => '300', 'sanitize_callback' => 'absint'));
    $wp_customize->add_control('about_image_width', array('label' => __('Hero Image Width (px)', 'codevers2e'), 'section' => 'about_hero_section', 'type' => 'number'));

    // About Page: Hero Buttons
    $wp_customize->add_setting('about_services_button_enabled', array('default' => true, 'sanitize_callback' => 'rest_sanitize_boolean'));
    $wp_customize->add_control('about_services_button_enabled', array('label' => __('Show Services Button', 'codevers2e'), 'section' => 'about_hero_section', 'type' => 'checkbox'));
    $wp_customize->add_setting('about_services_button_text', array('default' => 'Our Services', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('about_services_button_text', array('label' => __('Services Button Text', 'codevers2e'), 'section' => 'about_hero_section'));
    $wp_customize->add_setting('about_services_button_url', array('default' => '#services', 'sanitize_callback' => 'esc_url_raw'));
    $wp_customize->add_control('about_services_button_url', array('label' => __('Services Button URL', 'codevers2e'), 'section' => 'about_hero_section', 'type' => 'url'));
    $wp_customize->add_setting('about_services_button_style', array('default' => 'btn-light', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('about_services_button_style', array(
        'label' => __('Services Button Style', 'codevers2e'),
        'section' => 'about_hero_section',
        'type' => 'select',
        'choices' => array(
            'btn-light' => __('Light', 'codevers2e'),
            'btn-dark' => __('Dark', 'codevers2e'),
            'btn-primary' => __('Primary', 'codevers2e'),
            'btn-secondary' => __('Secondary', 'codevers2e'),
            'btn-success' => __('Success', 'codevers2e'),
            'btn-info' => __('Info', 'codevers2e'),
            'btn-warning' => __('Warning', 'codevers2e'),
            'btn-danger' => __('Danger', 'codevers2e'),
            'btn-outline-light' => __('Outline Light', 'codevers2e'),
            'btn-outline-dark' => __('Outline Dark', 'codevers2e'),
            'btn-outline-primary' => __('Outline Primary', 'codevers2e'),
            'btn-outline-secondary' => __('Outline Secondary', 'codevers2e'),
            'btn-outline-success' => __('Outline Success', 'codevers2e'),
            'btn-outline-info' => __('Outline Info', 'codevers2e'),
            'btn-outline-warning' => __('Outline Warning', 'codevers2e'),
            'btn-outline-danger' => __('Outline Danger', 'codevers2e')
        )
    ));

    $wp_customize->add_setting('about_brands_button_enabled', array('default' => true, 'sanitize_callback' => 'rest_sanitize_boolean'));
    $wp_customize->add_control('about_brands_button_enabled', array('label' => __('Show Brands Button', 'codevers2e'), 'section' => 'about_hero_section', 'type' => 'checkbox'));
    $wp_customize->add_setting('about_brands_button_text', array('default' => 'Our Brands', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('about_brands_button_text', array('label' => __('Brands Button Text', 'codevers2e'), 'section' => 'about_hero_section'));
    $wp_customize->add_setting('about_brands_button_url', array('default' => '#brands', 'sanitize_callback' => 'esc_url_raw'));
    $wp_customize->add_control('about_brands_button_url', array('label' => __('Brands Button URL', 'codevers2e'), 'section' => 'about_hero_section', 'type' => 'url'));
    $wp_customize->add_setting('about_brands_button_style', array('default' => 'btn-outline-light', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('about_brands_button_style', array(
        'label' => __('Brands Button Style', 'codevers2e'),
        'section' => 'about_hero_section',
        'type' => 'select',
        'choices' => array(
            'btn-light' => __('Light', 'codevers2e'),
            'btn-dark' => __('Dark', 'codevers2e'),
            'btn-primary' => __('Primary', 'codevers2e'),
            'btn-secondary' => __('Secondary', 'codevers2e'),
            'btn-success' => __('Success', 'codevers2e'),
            'btn-info' => __('Info', 'codevers2e'),
            'btn-warning' => __('Warning', 'codevers2e'),
            'btn-danger' => __('Danger', 'codevers2e'),
            'btn-outline-light' => __('Outline Light', 'codevers2e'),
            'btn-outline-dark' => __('Outline Dark', 'codevers2e'),
            'btn-outline-primary' => __('Outline Primary', 'codevers2e'),
            'btn-outline-secondary' => __('Outline Secondary', 'codevers2e'),
            'btn-outline-success' => __('Outline Success', 'codevers2e'),
            'btn-outline-info' => __('Outline Info', 'codevers2e'),
            'btn-outline-warning' => __('Outline Warning', 'codevers2e'),
            'btn-outline-danger' => __('Outline Danger', 'codevers2e')
        )
    ));

    // Button Size Settings
    $wp_customize->add_setting('about_buttons_size', array('default' => 'btn-lg', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('about_buttons_size', array(
        'label' => __('Button Size', 'codevers2e'),
        'section' => 'about_hero_section',
        'type' => 'select',
        'choices' => array(
            'btn-sm' => __('Small', 'codevers2e'),
            '' => __('Default', 'codevers2e'),
            'btn-lg' => __('Large', 'codevers2e')
        )
    ));

    // Button Spacing
    $wp_customize->add_setting('about_buttons_spacing', array('default' => 'me-3', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('about_buttons_spacing', array(
        'label' => __('Button Spacing', 'codevers2e'),
        'section' => 'about_hero_section',
        'type' => 'select',
        'choices' => array(
            '' => __('No Spacing', 'codevers2e'),
            'me-1' => __('Small Gap', 'codevers2e'),
            'me-2' => __('Medium Gap', 'codevers2e'),
            'me-3' => __('Large Gap', 'codevers2e'),
            'me-4' => __('Extra Large Gap', 'codevers2e'),
            'me-5' => __('Huge Gap', 'codevers2e')
        )
    ));

    // About Page: Services Section
    $wp_customize->add_section('about_services_section', array(
        'title' => __('Services Section', 'codevers2e'),
        'panel' => 'about_page_panel',
        'priority' => 20,
        'description' => __('Customize the Services section on the About page.', 'codevers2e')
    ));
    $wp_customize->add_setting('services_title', array('default' => 'Our Services', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('services_title', array('label' => __('Section Title', 'codevers2e'), 'section' => 'about_services_section'));
    $wp_customize->add_setting('services_description', array('default' => 'Lorem ipsum dolor sit amet...', 'sanitize_callback' => 'wp_kses_post'));
    $wp_customize->add_control('services_description', array('label' => __('Section Description', 'codevers2e'), 'section' => 'about_services_section', 'type' => 'textarea'));

    // Number of services
    $wp_customize->add_setting('services_count', array('default' => 4, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control('services_count', array(
        'label' => __('Number of Services', 'codevers2e'),
        'section' => 'about_services_section',
        'type' => 'number',
        'input_attrs' => array('min' => 1, 'max' => 8, 'step' => 1),
        'priority' => 10
    ));

    // Individual service settings
    $max_services = 8;
    for ($i = 1; $i <= $max_services; $i++) {
        // Service Title
        $wp_customize->add_setting("service_{$i}_title", array('default' => '', 'sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control("service_{$i}_title", array(
            'label' => sprintf(__('Service %d: Title', 'codevers2e'), $i),
            'section' => 'about_services_section',
            'type' => 'text',
            'priority' => 20 + ($i * 10),
             'active_callback' => function() use ($wp_customize, $i) {
                return $wp_customize->get_setting('services_count')->value() >= $i;
            }
        ));

        // Service Description
        $wp_customize->add_setting("service_{$i}_description", array('default' => '', 'sanitize_callback' => 'wp_kses_post'));
        $wp_customize->add_control("service_{$i}_description", array(
            'label' => sprintf(__('Service %d: Description', 'codevers2e'), $i),
            'section' => 'about_services_section',
            'type' => 'textarea',
            'priority' => 20 + ($i * 10) + 1,
            'active_callback' => function() use ($wp_customize, $i) {
                return $wp_customize->get_setting('services_count')->value() >= $i;
            }
        ));

        // Service Icon
        $wp_customize->add_setting("service_{$i}_icon", array('default' => 'fa-star', 'sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control("service_{$i}_icon", array(
            'label' => sprintf(__('Service %d: Icon Class', 'codevers2e'), $i),
            'description' => __('Enter a Font Awesome class (e.g., fa-truck).', 'codevers2e'),
            'section' => 'about_services_section',
            'type' => 'text',
            'priority' => 20 + ($i * 10) + 2,
            'active_callback' => function() use ($wp_customize, $i) {
                return $wp_customize->get_setting('services_count')->value() >= $i;
            }
        ));

        // Service Icon Background Color
        $wp_customize->add_setting("service_{$i}_icon_bg_color", array('default' => '#59ab6e', 'sanitize_callback' => 'sanitize_hex_color'));
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, "service_{$i}_icon_bg_color", array(
            'label' => sprintf(__('Service %d: Icon Background', 'codevers2e'), $i),
            'section' => 'about_services_section',
            'priority' => 20 + ($i * 10) + 3,
            'active_callback' => function() use ($wp_customize, $i) {
                return $wp_customize->get_setting('services_count')->value() >= $i;
            }
        )));

        // Service Icon Color
        $wp_customize->add_setting("service_{$i}_icon_color", array('default' => '#ffffff', 'sanitize_callback' => 'sanitize_hex_color'));
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, "service_{$i}_icon_color", array(
            'label' => sprintf(__('Service %d: Icon Color', 'codevers2e'), $i),
            'section' => 'about_services_section',
            'priority' => 20 + ($i * 10) + 4,
            'active_callback' => function() use ($wp_customize, $i) {
                return $wp_customize->get_setting('services_count')->value() >= $i;
            }
        )));
    }

    // About Page: Team Section
    $wp_customize->add_section('about_team_section', array(
        'title' => __('Team Section', 'codevers2e'),
        'panel' => 'about_page_panel',
        'priority' => 30,
        'description' => __('Customize the Team section on the About page.', 'codevers2e')
    ));

    // Section Title
    $wp_customize->add_setting('team_section_title', array('default' => 'Our Team', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('team_section_title', array('label' => __('Section Title', 'codevers2e'), 'section' => 'about_team_section'));

    // Section Description
    $wp_customize->add_setting('team_section_description', array('default' => 'Meet the talented people behind our success', 'sanitize_callback' => 'sanitize_textarea_field'));
    $wp_customize->add_control('team_section_description', array('label' => __('Section Description', 'codevers2e'), 'section' => 'about_team_section', 'type' => 'textarea'));

    // Number of Team Members
    $wp_customize->add_setting('team_members_count', array('default' => 3, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control('team_members_count', array(
        'label' => __('Number of Team Members', 'codevers2e'),
        'section' => 'about_team_section',
        'type' => 'number',
        'input_attrs' => array('min' => 1, 'max' => 6, 'step' => 1),
        'priority' => 10
    ));

    // Individual Team Member Settings
    $max_members = 6;
    for ($i = 1; $i <= $max_members; $i++) {
        $active_callback = function() use ($wp_customize, $i) {
            return $wp_customize->get_setting('team_members_count')->value() >= $i;
        };

        // Member Image
        $wp_customize->add_setting("team_member_{$i}_image", array('sanitize_callback' => 'esc_url_raw'));
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "team_member_{$i}_image", array(
            'label' => sprintf(__('Member %d: Image', 'codevers2e'), $i),
            'section' => 'about_team_section',
            'priority' => 20 + ($i * 10),
            'active_callback' => $active_callback
        )));

        // Member Name
        $wp_customize->add_setting("team_member_{$i}_name", array('default' => "Team Member {$i}", 'sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control("team_member_{$i}_name", array(
            'label' => sprintf(__('Member %d: Name', 'codevers2e'), $i),
            'section' => 'about_team_section',
            'priority' => 20 + ($i * 10) + 1,
            'active_callback' => $active_callback
        ));

        // Member Position
        $wp_customize->add_setting("team_member_{$i}_position", array('default' => 'Position Title', 'sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control("team_member_{$i}_position", array(
            'label' => sprintf(__('Member %d: Position', 'codevers2e'), $i),
            'section' => 'about_team_section',
            'priority' => 20 + ($i * 10) + 2,
            'active_callback' => $active_callback
        ));

        // Member Description
        $wp_customize->add_setting("team_member_{$i}_description", array('default' => 'A brief overview of the member or his position in the team.', 'sanitize_callback' => 'wp_kses_post'));
        $wp_customize->add_control("team_member_{$i}_description", array(
            'label' => sprintf(__('Member %d: Description', 'codevers2e'), $i),
            'section' => 'about_team_section',
            'type' => 'textarea',
            'priority' => 20 + ($i * 10) + 3,
            'active_callback' => $active_callback
        ));
        
        // Member Rating
        $wp_customize->add_setting("team_member_{$i}_rating", array('default' => 5, 'sanitize_callback' => 'absint'));
        $wp_customize->add_control("team_member_{$i}_rating", array(
            'label' => sprintf(__('Member %d: Rating (1-5)', 'codevers2e'), $i),
            'section' => 'about_team_section',
            'type' => 'number',
            'input_attrs' => array('min' => 1, 'max' => 5, 'step' => 1),
            'priority' => 20 + ($i * 10) + 4,
            'active_callback' => $active_callback
        ));
        
        // Social Links
        $socials = array(
            'twitter' => 'fab fa-twitter', 
            'linkedin' => 'fab fa-linkedin-in', 
            'facebook' => 'fab fa-facebook-f'
        );
        foreach($socials as $social => $icon) {
             $wp_customize->add_setting("team_member_{$i}_{$social}_url", array('default' => '#', 'sanitize_callback' => 'esc_url_raw'));
             $wp_customize->add_control("team_member_{$i}_{$social}_url", array(
                'label' => sprintf(__('Member %d: %s URL', 'codevers2e'), $i, ucfirst($social)),
                'section' => 'about_team_section',
                'type' => 'url',
                'priority' => 20 + ($i * 10) + 5 + array_search($social, array_keys($socials)),
                'active_callback' => $active_callback
            ));
        }
    }

    // About Page: Brands Section
    $wp_customize->add_section('about_brands_section', array(
        'title' => __('Brands Section', 'codevers2e'),
        'panel' => 'about_page_panel',
        'priority' => 40,
        'description' => __('Customize the Brands carousel on the About page.', 'codevers2e')
    ));

    // Section Title
    $wp_customize->add_setting('brands_title', array('default' => 'Our Brands', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('brands_title', array('label' => __('Section Title', 'codevers2e'), 'section' => 'about_brands_section'));

    // Section Description
    $wp_customize->add_setting('brands_description', array('default' => 'We partner with the world\'s leading brands to deliver exceptional products and services.', 'sanitize_callback' => 'wp_kses_post'));
    $wp_customize->add_control('brands_description', array('label' => __('Section Description', 'codevers2e'), 'section' => 'about_brands_section', 'type' => 'textarea'));
    
    // Number of Brands
    $wp_customize->add_setting('brands_count', array('default' => 6, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control('brands_count', array(
        'label' => __('Number of Brands to Display', 'codevers2e'),
        'section' => 'about_brands_section',
        'type' => 'number',
        'input_attrs' => array('min' => 0, 'max' => 18, 'step' => 1),
        'priority' => 10
    ));
    
    // Brands per slide
    $wp_customize->add_setting('brands_per_slide', array('default' => 6, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control('brands_per_slide', array(
        'label' => __('Brands per Slide', 'codevers2e'),
        'section' => 'about_brands_section',
        'type' => 'number',
        'input_attrs' => array('min' => 2, 'max' => 6, 'step' => 1),
        'priority' => 11
    ));

    // Individual Brand Settings
    $max_brands = 18;
    for ($i = 1; $i <= $max_brands; $i++) {
        $active_callback = function() use ($wp_customize, $i) {
            return $wp_customize->get_setting('brands_count')->value() >= $i;
        };

        // Brand Image
        $wp_customize->add_setting("brand_image_{$i}", array('sanitize_callback' => 'esc_url_raw'));
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "brand_image_{$i}", array(
            'label' => sprintf(__('Brand %d: Image', 'codevers2e'), $i),
            'section' => 'about_brands_section',
            'priority' => 20 + ($i * 10),
            'active_callback' => $active_callback
        )));

        // Brand Link
        $wp_customize->add_setting("brand_link_{$i}", array('default' => '#', 'sanitize_callback' => 'esc_url_raw'));
        $wp_customize->add_control("brand_link_{$i}", array(
            'label' => sprintf(__('Brand %d: Link', 'codevers2e'), $i),
            'section' => 'about_brands_section',
            'type' => 'url',
            'priority' => 20 + ($i * 10) + 1,
            'active_callback' => $active_callback
        ));
        
        // Brand Alt Text
        $wp_customize->add_setting("brand_alt_{$i}", array('default' => '', 'sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control("brand_alt_{$i}", array(
            'label' => sprintf(__('Brand %d: Alt Text', 'codevers2e'), $i),
            'description' => __('Alternative text for the brand image.', 'codevers2e'),
            'section' => 'about_brands_section',
            'type' => 'text',
            'priority' => 20 + ($i * 10) + 2,
            'active_callback' => $active_callback
        ));
    }

    // About Page: Stats Bar Section
    $wp_customize->add_section('about_stats_section', array(
        'title' => __('Stats Bar Section', 'codevers2e'),
        'panel' => 'about_page_panel',
        'priority' => 50,
        'description' => __('Customize the statistics bar.', 'codevers2e')
    ));

    $wp_customize->add_setting('stats_bar_bg_color', array('default' => '#343a40', 'sanitize_callback' => 'sanitize_hex_color'));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'stats_bar_bg_color', array(
        'label' => __('Background Color', 'codevers2e'),
        'section' => 'about_stats_section',
    )));

    $wp_customize->add_setting('stats_count', array('default' => 4, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control('stats_count', array(
        'label' => __('Number of Stats', 'codevers2e'),
        'section' => 'about_stats_section',
        'type' => 'number',
        'input_attrs' => array('min' => 1, 'max' => 4, 'step' => 1)
    ));

    for ($i = 1; $i <= 4; $i++) {
        $active_callback = function() use ($wp_customize, $i) { return $wp_customize->get_setting('stats_count')->value() >= $i; };
        $wp_customize->add_setting("stat_{$i}_value", array('sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control("stat_{$i}_value", array('label' => sprintf(__('Stat %d: Value', 'codevers2e'), $i), 'section' => 'about_stats_section', 'active_callback' => $active_callback));
        $wp_customize->add_setting("stat_{$i}_label", array('sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control("stat_{$i}_label", array('label' => sprintf(__('Stat %d: Label', 'codevers2e'), $i), 'section' => 'about_stats_section', 'active_callback' => $active_callback));
    }

    // About Page: Testimonials Section
    $wp_customize->add_section('about_testimonials_section', array(
        'title' => __('Testimonials Section', 'codevers2e'),
        'panel' => 'about_page_panel',
        'priority' => 60
    ));
    $wp_customize->add_setting('testimonials_title', array('default' => 'What Our Clients Say', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('testimonials_title', array('label' => __('Section Title', 'codevers2e'), 'section' => 'about_testimonials_section'));
    $wp_customize->add_setting('testimonials_description', array('default' => 'Don\'t just take our word for it', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('testimonials_description', array('label' => __('Section Description', 'codevers2e'), 'section' => 'about_testimonials_section'));

    $wp_customize->add_setting('testimonials_count', array('default' => 3, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control('testimonials_count', array(
        'label' => __('Number of Testimonials', 'codevers2e'),
        'section' => 'about_testimonials_section',
        'type' => 'number',
        'input_attrs' => array('min' => 1, 'max' => 9, 'step' => 1)
    ));
    
    $wp_customize->add_setting('testimonials_per_slide', array('default' => 3, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control('testimonials_per_slide', array(
        'label' => __('Testimonials per Slide', 'codevers2e'),
        'section' => 'about_testimonials_section',
        'type' => 'number',
        'input_attrs' => array('min' => 1, 'max' => 3, 'step' => 1)
    ));
    
    for ($i = 1; $i <= 9; $i++) {
        $active_callback = function() use ($wp_customize, $i) { return $wp_customize->get_setting('testimonials_count')->value() >= $i; };
        $wp_customize->add_setting("testimonial_{$i}_image", array('sanitize_callback' => 'esc_url_raw'));
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "testimonial_{$i}_image", array('label' => sprintf(__('Testimonial %d: Client Image', 'codevers2e'), $i), 'section' => 'about_testimonials_section', 'active_callback' => $active_callback)));
        $wp_customize->add_setting("testimonial_{$i}_name", array('sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control("testimonial_{$i}_name", array('label' => sprintf(__('Testimonial %d: Client Name', 'codevers2e'), $i), 'section' => 'about_testimonials_section', 'active_callback' => $active_callback));
        $wp_customize->add_setting("testimonial_{$i}_position", array('sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control("testimonial_{$i}_position", array('label' => sprintf(__('Testimonial %d: Position, Company', 'codevers2e'), $i), 'section' => 'about_testimonials_section', 'active_callback' => $active_callback));
        $wp_customize->add_setting("testimonial_{$i}_quote", array('sanitize_callback' => 'wp_kses_post'));
        $wp_customize->add_control("testimonial_{$i}_quote", array('label' => sprintf(__('Testimonial %d: Quote', 'codevers2e'), $i), 'section' => 'about_testimonials_section', 'type' => 'textarea', 'active_callback' => $active_callback));
        
        // Testimonial Rating
        $wp_customize->add_setting("testimonial_{$i}_rating", array('default' => 5, 'sanitize_callback' => 'absint'));
        $wp_customize->add_control("testimonial_{$i}_rating", array(
            'label' => sprintf(__('Testimonial %d: Rating (1-5)', 'codevers2e'), $i),
            'section' => 'about_testimonials_section',
            'type' => 'number',
            'input_attrs' => array('min' => 1, 'max' => 5, 'step' => 1),
            'active_callback' => $active_callback
        ));
    }

    // Contact Page Settings
    $wp_customize->add_panel('contact_page_panel', array(
        'title' => __('Contact Page Settings', 'codevers2e'),
        'priority' => 60,
        'description' => __('Manage all sections of the Contact Page.', 'codevers2e')
    ));

    // -- Header Section --
    $wp_customize->add_section('contact_header_section', array(
        'title' => __('Page Header', 'codevers2e'),
        'panel' => 'contact_page_panel',
    ));
    $wp_customize->add_setting('contact_title', array('default' => 'Contact Us', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_title', array('label' => __('Title', 'codevers2e'), 'section' => 'contact_header_section'));
    $wp_customize->add_setting('contact_description', array('default' => 'Proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'sanitize_callback' => 'wp_kses_post'));
    $wp_customize->add_control('contact_description', array('label' => __('Description', 'codevers2e'), 'section' => 'contact_header_section', 'type' => 'textarea'));
    $wp_customize->add_setting('contact_header_bg_gradient_start', array('default' => '#59ab6e', 'sanitize_callback' => 'sanitize_hex_color'));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'contact_header_bg_gradient_start', array('label' => __('Background Gradient Start', 'codevers2e'), 'section' => 'contact_header_section')));
    $wp_customize->add_setting('contact_header_bg_gradient_end', array('default' => '#4a8f5c', 'sanitize_callback' => 'sanitize_hex_color'));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'contact_header_bg_gradient_end', array('label' => __('Background Gradient End', 'codevers2e'), 'section' => 'contact_header_section')));

    // -- Map Section --
    $wp_customize->add_section('contact_map_section', array(
        'title' => __('Interactive Map', 'codevers2e'),
        'panel' => 'contact_page_panel',
    ));
    $wp_customize->add_setting('map_latitude', array('default' => '23.013104', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('map_latitude', array('label' => __('Latitude', 'codevers2e'), 'section' => 'contact_map_section'));
    $wp_customize->add_setting('map_longitude', array('default' => '43.394365', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('map_longitude', array('label' => __('Longitude', 'codevers2e'), 'section' => 'contact_map_section'));
    $wp_customize->add_setting('map_zoom', array('default' => 15, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control('map_zoom', array('label' => __('Zoom Level', 'codevers2e'), 'section' => 'contact_map_section', 'type' => 'number'));
    $wp_customize->add_setting('map_marker_image', array('sanitize_callback' => 'esc_url_raw'));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'map_marker_image', array('label' => __('Custom Map Marker', 'codevers2e'), 'section' => 'contact_map_section')));
    $wp_customize->add_setting('map_popup_title', array('default' => 'codevers2e eCommerce Template', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('map_popup_title', array('label' => __('Marker Popup Text', 'codevers2e'), 'section' => 'contact_map_section'));

    // -- Contact Info Section --
    $wp_customize->add_section('contact_info_section', array(
        'title' => __('Contact Information', 'codevers2e'),
        'panel' => 'contact_page_panel',
    ));
    $wp_customize->add_setting('contact_info_title', array('default' => 'Get In Touch', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_info_title', array('label' => __('Section Title', 'codevers2e'), 'section' => 'contact_info_section'));
    
    // Location
    $wp_customize->add_setting('contact_info_location_label', array('default' => 'Our Location', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_info_location_label', array('label' => __('Location Label', 'codevers2e'), 'section' => 'contact_info_section'));
    $wp_customize->add_setting('contact_info_location_data', array('default' => get_theme_mod('footer_address'), 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_info_location_data', array('label' => __('Location Address', 'codevers2e'), 'section' => 'contact_info_section'));

    // Phone
    $wp_customize->add_setting('contact_info_phone_label', array('default' => 'Phone Number', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_info_phone_label', array('label' => __('Phone Label', 'codevers2e'), 'section' => 'contact_info_section'));
    $wp_customize->add_setting('contact_info_phone_data', array('default' => get_theme_mod('footer_phone'), 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_info_phone_data', array('label' => __('Phone Number', 'codevers2e'), 'section' => 'contact_info_section'));

    // Email
    $wp_customize->add_setting('contact_info_email_label', array('default' => 'Email Address', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_info_email_label', array('label' => __('Email Label', 'codevers2e'), 'section' => 'contact_info_section'));
    $wp_customize->add_setting('contact_info_email_data', array('default' => get_theme_mod('footer_email'), 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_info_email_data', array('label' => __('Email Address', 'codevers2e'), 'section' => 'contact_info_section'));

    $wp_customize->add_setting('working_hours_label', array('default' => 'Working Hours', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('working_hours_label', array('label' => __('Working Hours Label', 'codevers2e'), 'section' => 'contact_info_section'));
    $wp_customize->add_setting('working_hours_weekdays', array('default' => 'Monday-Friday: 9AM-6PM', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('working_hours_weekdays', array('label' => __('Weekdays Hours', 'codevers2e'), 'section' => 'contact_info_section'));
    $wp_customize->add_setting('working_hours_weekend', array('default' => 'Saturday: 10AM-4PM', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('working_hours_weekend', array('label' => __('Weekend Hours', 'codevers2e'), 'section' => 'contact_info_section'));


    // -- Contact Form Section --
    $wp_customize->add_section('contact_form_section', array(
        'title' => __('Contact Form', 'codevers2e'),
        'panel' => 'contact_page_panel',
    ));
    $wp_customize->add_setting('contact_form_title', array('default' => 'Send Us a Message', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_form_title', array('label' => __('Form Title', 'codevers2e'), 'section' => 'contact_form_section'));

    $form_fields = array(
        'name' => 'Full Name',
        'email' => 'Email Address',
        'phone' => 'Phone Number',
        'subject' => 'Subject',
        'message' => 'Your Message'
    );
    foreach($form_fields as $field => $default_label) {
        $wp_customize->add_setting("contact_form_{$field}_label", array('default' => $default_label, 'sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control("contact_form_{$field}_label", array('label' => ucfirst($field) . ' Field Label', 'section' => 'contact_form_section'));
        $wp_customize->add_setting("contact_form_{$field}_placeholder", array('sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control("contact_form_{$field}_placeholder", array('label' => ucfirst($field) . ' Field Placeholder', 'section' => 'contact_form_section'));
    }

    $wp_customize->add_setting('contact_form_submit_text', array('default' => 'Send Message', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_form_submit_text', array('label' => __('Submit Button Text', 'codevers2e'), 'section' => 'contact_form_section'));
    
    $wp_customize->add_setting('contact_form_success_message', array('default' => 'Your message has been sent successfully!', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_form_success_message', array('label' => __('Success Message', 'codevers2e'), 'section' => 'contact_form_section', 'type' => 'textarea'));

    $wp_customize->add_setting('contact_form_bg_color', array('default' => '#ffffff', 'sanitize_callback' => 'sanitize_hex_color'));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'contact_form_bg_color', array('label' => __('Form Background Color', 'codevers2e'), 'section' => 'contact_form_section')));
    $wp_customize->add_setting('contact_button_bg_color', array('default' => '#59ab6e', 'sanitize_callback' => 'sanitize_hex_color'));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'contact_button_bg_color', array('label' => __('Button Background Color', 'codevers2e'), 'section' => 'contact_form_section')));
    $wp_customize->add_setting('contact_button_hover_color', array('default' => '#4a8f5c', 'sanitize_callback' => 'sanitize_hex_color'));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'contact_button_hover_color', array('label' => __('Button Hover Color', 'codevers2e'), 'section' => 'contact_form_section')));

    // Shop Settings
    $wp_customize->add_section('zayxyz_shop_settings', array(
        'title'    => __('Shop Settings', 'zayxyz'),
        'priority' => 120,
    ));

    // PayPal Button Setting
    $wp_customize->add_setting('zayxyz_show_paypal_button', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));

    $wp_customize->add_control('zayxyz_show_paypal_button_control', array(
        'label'    => __('Show PayPal Button on Product Page', 'zayxyz'),
        'section'  => 'zayxyz_shop_settings',
        'settings' => 'zayxyz_show_paypal_button',
        'type'     => 'checkbox',
    ));

    // Remove the panel
    // $wp_customize->remove_panel('nav_menus');
    
    // Add a new section for Shipping Information
    $wp_customize->add_section('shipping_info_section', array(
        'title'    => __('Shipping Information', 'zayxyz'),
        'priority' => 160,
    ));

    // Setting for Visibility
    $wp_customize->add_setting('shipping_info_visibility', array(
        'default'   => true,
        'sanitize_callback' => 'wp_validate_boolean',
        'transport' => 'refresh',
    ));

    // Control for Visibility
    $wp_customize->add_control('shipping_info_visibility_control', array(
        'label'    => __('Show Shipping Information', 'zayxyz'),
        'section'  => 'shipping_info_section',
        'settings' => 'shipping_info_visibility',
        'type'     => 'checkbox',
    ));

    // Setting for Delivery Time
    $wp_customize->add_setting('shipping_info_delivery_time', array(
        'default'   => '2-5 business days',
        'sanitize_callback' => 'sanitize_text_field',
        'transport' => 'refresh',
    ));

    // Control for Delivery Time
    $wp_customize->add_control('shipping_info_delivery_time_control', array(
        'label'    => __('Delivery Time', 'zayxyz'),
        'section'  => 'shipping_info_section',
        'settings' => 'shipping_info_delivery_time',
        'type'     => 'text',
    ));

    // Setting for Shipping Cost
    $wp_customize->add_setting('shipping_info_cost', array(
        'default'   => 'Free for orders over $200',
        'sanitize_callback' => 'sanitize_text_field',
        'transport' => 'refresh',
    ));

    // Control for Shipping Cost
    $wp_customize->add_control('shipping_info_cost_control', array(
        'label'    => __('Shipping Cost', 'zayxyz'),
        'section'  => 'shipping_info_section',
        'settings' => 'shipping_info_cost',
        'type'     => 'text',
    ));

    // Setting for Payment Method
    $wp_customize->add_setting('shipping_info_payment_method', array(
        'default'   => 'Credit Card / Mada / PayPal',
        'sanitize_callback' => 'sanitize_text_field',
        'transport' => 'refresh',
    ));

    // Control for Payment Method
    $wp_customize->add_control('shipping_info_payment_method_control', array(
        'label'    => __('Payment Method', 'zayxyz'),
        'section'  => 'shipping_info_section',
        'settings' => 'shipping_info_payment_method',
        'type'     => 'text',
    ));

    // Setting for Warranty
    $wp_customize->add_setting('shipping_info_warranty', array(
        'default'   => '1-year factory warranty',
        'sanitize_callback' => 'sanitize_text_field',
        'transport' => 'refresh',
    ));

    // Control for Warranty
    $wp_customize->add_control('shipping_info_warranty_control', array(
        'label'    => __('Warranty', 'zayxyz'),
        'section'  => 'shipping_info_section',
        'settings' => 'shipping_info_warranty',
        'type'     => 'text',
    ));

    // خيار إظهار/إخفاء الإيميل في الهيدر
    $wp_customize->add_setting('show_header_email', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('show_header_email', array(
        'label'    => __('Show email in header', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'show_header_email',
        'type'     => 'checkbox',
    ));

    // خيار إظهار/إخفاء الهاتف في الهيدر
    $wp_customize->add_setting('show_header_phone', array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('show_header_phone', array(
        'label'    => __('Show phone number in header', 'zayxyz'),
        'section'  => 'home_settings',
        'settings' => 'show_header_phone',
        'type'     => 'checkbox',
    ));

    // عدد التصنيفات المعروضة في قسم التصنيفات
    $wp_customize->add_setting('categories_count', array(
        'default'   => 3,
        'transport' => 'refresh',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('categories_count', array(
        'label'    => __('Number of categories to show', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'type'     => 'number',
        'input_attrs' => array(
            'min' => 1,
            'max' => 20,
        ),
    ));

    // نمط خط عنوان قسم التصنيفات
    $wp_customize->add_setting('categories_title_font_style', array(
        'default'   => 'normal',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('categories_title_font_style', array(
        'label'    => __('Categories Title Font Style', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'type'     => 'select',
        'choices'  => array(
            'normal' => __('Normal', 'zayxyz'),
            'bold'   => __('Bold', 'zayxyz'),
            'italic' => __('Italic', 'zayxyz'),
            'bold_italic' => __('Bold Italic', 'zayxyz'),
        ),
    ));

    // نمط خط وصف قسم التصنيفات
    $wp_customize->add_setting('categories_desc_font_style', array(
        'default'   => 'normal',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('categories_desc_font_style', array(
        'label'    => __('Categories Description Font Style', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'type'     => 'select',
        'choices'  => array(
            'normal' => __('Normal', 'zayxyz'),
            'bold'   => __('Bold', 'zayxyz'),
            'italic' => __('Italic', 'zayxyz'),
            'bold_italic' => __('Bold Italic', 'zayxyz'),
        ),
    ));

    // عدد المنتجات المميزة في Spotlight
    $wp_customize->add_setting('spotlight_count', array(
        'default'   => 3,
        'transport' => 'refresh',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('spotlight_count', array(
        'label'    => __('Number of spotlight products to show', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'type'     => 'number',
        'input_attrs' => array(
            'min' => 1,
            'max' => 20,
        ),
    ));

    // نمط خط عنوان spotlight
    $wp_customize->add_setting('spotlight_title_font_style', array(
        'default'   => 'normal',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('spotlight_title_font_style', array(
        'label'    => __('Spotlight Title Font Style', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'type'     => 'select',
        'choices'  => array(
            'normal' => __('Normal', 'zayxyz'),
            'bold'   => __('Bold', 'zayxyz'),
            'italic' => __('Italic', 'zayxyz'),
            'bold_italic' => __('Bold Italic', 'zayxyz'),
        ),
    ));

    // نمط خط وصف spotlight
    $wp_customize->add_setting('spotlight_desc_font_style', array(
        'default'   => 'normal',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('spotlight_desc_font_style', array(
        'label'    => __('Spotlight Description Font Style', 'zayxyz'),
        'section'  => 'zayxyz_body_settings',
        'type'     => 'select',
        'choices'  => array(
            'normal' => __('Normal', 'zayxyz'),
            'bold'   => __('Bold', 'zayxyz'),
            'italic' => __('Italic', 'zayxyz'),
            'bold_italic' => __('Bold Italic', 'zayxyz'),
        ),
    ));

    // =====================
    // إعدادات ودجات الشريط الجانبي (Sidebar Widgets)
    // =====================
    $wp_customize->add_section('zayxyz_sidebar_widget_settings', array(
        'title'    => __('Widget Sidebar Settings', 'zayxyz'),
        'priority' => 130,
    ));
    // لون عنوان الودجت الجانبي
    $wp_customize->add_setting('sidebar_widget_title_color', array(
        'default'   => '#1565c0',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'sidebar_widget_title_color', array(
        'label'    => __('Sidebar Widget Title Color', 'zayxyz'),
        'section'  => 'zayxyz_sidebar_widget_settings',
        'settings' => 'sidebar_widget_title_color',
    )));
    // نص عنوان Product Categories
    $wp_customize->add_setting('sidebar_widget_title_categories', array(
        'default'   => 'Product Categories',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('sidebar_widget_title_categories', array(
        'label'    => __('Product Categories Title', 'zayxyz'),
        'section'  => 'zayxyz_sidebar_widget_settings',
        'settings' => 'sidebar_widget_title_categories',
        'type'     => 'text',
    ));
    // نص عنوان Filter by Price
    $wp_customize->add_setting('sidebar_widget_title_filter', array(
        'default'   => 'Filter by Price',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('sidebar_widget_title_filter', array(
        'label'    => __('Filter by Price Title', 'zayxyz'),
        'section'  => 'zayxyz_sidebar_widget_settings',
        'settings' => 'sidebar_widget_title_filter',
        'type'     => 'text',
    ));
    // نص عنوان Search Products
    $wp_customize->add_setting('sidebar_widget_title_search', array(
        'default'   => 'Search Products',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('sidebar_widget_title_search', array(
        'label'    => __('Search Products Title', 'zayxyz'),
        'section'  => 'zayxyz_sidebar_widget_settings',
        'settings' => 'sidebar_widget_title_search',
        'type'     => 'text',
    ));
    // Contact Page: Interactive Map Info
    $wp_customize->add_section('contact_map_section', array(
        'title' => __('Interactive Map', 'codevers2e'),
        'panel' => 'contact_page_panel',
    ));
    // Location
    $wp_customize->add_setting('contact_show_location', array('default' => true, 'sanitize_callback' => 'wp_validate_boolean'));
    $wp_customize->add_control('contact_show_location', array('label' => __('Show Location', 'codevers2e'), 'section' => 'contact_map_section', 'type' => 'checkbox'));
    $wp_customize->add_setting('contact_location_text', array('default' => '1234 Consectetur at ligula 10660', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_location_text', array('label' => __('Location Text', 'codevers2e'), 'section' => 'contact_map_section'));
    // Phone
    $wp_customize->add_setting('contact_show_phone', array('default' => true, 'sanitize_callback' => 'wp_validate_boolean'));
    $wp_customize->add_control('contact_show_phone', array('label' => __('Show Phone', 'codevers2e'), 'section' => 'contact_map_section', 'type' => 'checkbox'));
    $wp_customize->add_setting('contact_phone_text', array('default' => '010-020-03405', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('contact_phone_text', array('label' => __('Phone Text', 'codevers2e'), 'section' => 'contact_map_section'));
    // Email
    $wp_customize->add_setting('contact_show_email', array('default' => true, 'sanitize_callback' => 'wp_validate_boolean'));
    $wp_customize->add_control('contact_show_email', array('label' => __('Show Email', 'codevers2e'), 'section' => 'contact_map_section', 'type' => 'checkbox'));
    $wp_customize->add_setting('contact_email_text', array('default' => 'info@company.com', 'sanitize_callback' => 'sanitize_email'));
    $wp_customize->add_control('contact_email_text', array('label' => __('Email Text', 'codevers2e'), 'section' => 'contact_map_section'));
    // Social Links
    $socials = array('facebook','instagram','twitter','linkedin');
    foreach($socials as $social) {
        $wp_customize->add_setting('contact_show_'.$social, array('default' => true, 'sanitize_callback' => 'wp_validate_boolean'));
        $wp_customize->add_control('contact_show_'.$social, array('label' => __('Show '.ucfirst($social), 'codevers2e'), 'section' => 'contact_map_section', 'type' => 'checkbox'));
        $wp_customize->add_setting('contact_'.$social.'_url', array('default' => '#', 'sanitize_callback' => 'esc_url_raw'));
        $wp_customize->add_control('contact_'.$social.'_url', array('label' => __(ucfirst($social).' URL', 'codevers2e'), 'section' => 'contact_map_section', 'type' => 'url'));
    }

    // [SHOP SETTINGS] قسم إعدادات المتجر
    $wp_customize->add_section('shop_settings', array(
        'title'    => __('SHOP SETTINGS', 'zayxyz'),
        'priority' => 50,
    ));
    // حقل تجريبي كبداية (سيتم إضافة باقي الحقول لاحقًا)
    $wp_customize->add_setting('shop_settings_note', array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('shop_settings_note', array(
        'label'    => __('All shop display options will appear here.', 'zayxyz'),
        'section'  => 'shop_settings',
        'settings' => 'shop_settings_note',
        'type'     => 'hidden',
    ));

    // إعدادات SHOP SETTINGS
    // 1. عدد المنتجات لكل تصنيف
    $wp_customize->add_setting('shop_products_per_category', array(
        'default'   => 9,
        'transport' => 'refresh',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('shop_products_per_category', array(
        'label'    => __('Products Per Category', 'zayxyz'),
        'section'  => 'shop_settings',
        'type'     => 'number',
        'input_attrs' => array('min' => 1, 'max' => 50),
    ));

    // 2. طريقة عرض المنتجات
    $wp_customize->add_setting('shop_product_display_mode', array(
        'default'   => 'grouped',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('shop_product_display_mode', array(
        'label'    => __('Product Display Mode', 'zayxyz'),
        'section'  => 'shop_settings',
        'type'     => 'select',
        'choices'  => array(
            'grouped'   => __('Grouped by Category', 'zayxyz'),
            'random'    => __('Random Products', 'zayxyz'),
            'featured'  => __('Featured Products Only', 'zayxyz'),
            'customcat' => __('By Specific Category', 'zayxyz'),
        ),
    ));

    // 3. اختيار تصنيفات مخصصة (يظهر فقط إذا تم اختيار By Specific Category)
    $all_product_cats = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));
    $cat_choices = array();
    if (!empty($all_product_cats) && !is_wp_error($all_product_cats)) {
        foreach ($all_product_cats as $cat) {
            $cat_choices[$cat->term_id] = $cat->name;
        }
    }
    $wp_customize->add_setting('shop_custom_category_selection', array(
        'default'   => array(),
        'transport' => 'refresh',
        'sanitize_callback' => function($input) {
            return array_map('absint', (array)$input);
        },
    ));
    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'shop_custom_category_selection',
        array(
            'label'    => __('Select Categories', 'zayxyz'),
            'section'  => 'shop_settings',
            'type'     => 'select',
            'choices'  => $cat_choices,
            'input_attrs' => array('multiple' => 'multiple'),
            'description' => __('Choose categories to display if "By Specific Category" is selected.', 'zayxyz'),
        )
    ));

    // --- NUMBER SETTING (Pagination) ---
    $wp_customize->add_setting('shop_number_setting_title', array(
        'sanitize_callback' => 'sanitize_text_field',
        'default' => '',
    ));
    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'shop_number_setting_title',
        array(
            'label'    => __('NUMBER SETTING', 'zayxyz'),
            'section'  => 'shop_settings',
            'type'     => 'hidden',
            'description' => '<span style="font-weight:bold;font-size:1.1em;display:block;margin:10px 0 5px 0;">' . __('NUMBER SETTING (Pagination)', 'zayxyz') . '</span>',
        )
    ));
    // إعدادات شكل وألوان الترقيم
    $wp_customize->add_setting('shop_pagination_style', array(
        'default'   => 'circle',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('shop_pagination_style', array(
        'label'    => __('Pagination Style', 'zayxyz'),
        'section'  => 'shop_settings',
        'type'     => 'select',
        'choices'  => array(
            'circle'   => __('Circle', 'zayxyz'),
            'square'   => __('Square', 'zayxyz'),
            'rounded'  => __('Rounded Rectangle', 'zayxyz'),
        ),
    ));
    $wp_customize->add_setting('shop_pagination_bg_color', array(
        'default'   => '#ffffff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'shop_pagination_bg_color', array(
        'label'    => __('Pagination Background Color', 'zayxyz'),
        'section'  => 'shop_settings',
        'settings' => 'shop_pagination_bg_color',
    )));
    $wp_customize->add_setting('shop_pagination_active_color', array(
        'default'   => '#2dce89',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'shop_pagination_active_color', array(
        'label'    => __('Pagination Active Color', 'zayxyz'),
        'section'  => 'shop_settings',
        'settings' => 'shop_pagination_active_color',
    )));
    $wp_customize->add_setting('shop_pagination_text_color', array(
        'default'   => '#222222',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'shop_pagination_text_color', array(
        'label'    => __('Pagination Text Color', 'zayxyz'),
        'section'  => 'shop_settings',
        'settings' => 'shop_pagination_text_color',
    )));

    // ... existing code ...
    $wp_customize->add_section('zayxyz_shipping_info', array(
        'title'    => __('Shipping Information', 'zayxyz'),
        'priority' => 50,
    ));

    // Control for 'Related products' heading
    $wp_customize->add_setting('related_products_heading', array(
        'default'   => __('Related products', 'zayxyz'),
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('related_products_heading', array(
        'label'    => __('Related Products Heading', 'zayxyz'),
        'section'  => 'zayxyz_shipping_info',
        'settings' => 'related_products_heading',
        'type'     => 'text',
    ));

    // Control for 'You May Also Like' heading
    $wp_customize->add_setting('you_may_also_like_heading', array(
        'default'   => __('You May Also Like', 'zayxyz'),
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('you_may_also_like_heading', array(
        'label'    => __('You May Also Like Heading', 'zayxyz'),
        'section'  => 'zayxyz_shipping_info',
        'settings' => 'you_may_also_like_heading',
        'type'     => 'text',
    ));

    // Control for 'Shipping Options' label (change to 'Change addresses')
    $wp_customize->add_setting('shipping_options_label', array(
        'default'   => __('Change addresses', 'zayxyz'),
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('shipping_options_label', array(
        'label'    => __('Shipping Options Label', 'zayxyz'),
        'section'  => 'zayxyz_shipping_info',
        'settings' => 'shipping_options_label',
        'type'     => 'text',
    ));
    // ... existing code ...

    // Control for 'Standard Shipping' label
    $wp_customize->add_setting('standard_shipping_label', array(
        'default'   => __('Standard Shipping', 'zayxyz'),
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('standard_shipping_label', array(
        'label'    => __('Standard Shipping Label', 'zayxyz'),
        'section'  => 'zayxyz_shipping_info',
        'settings' => 'standard_shipping_label',
        'type'     => 'text',
    ));
    // Control for 'Standard Shipping' time
    $wp_customize->add_setting('standard_shipping_time', array(
        'default'   => __('3-5 business days', 'zayxyz'),
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('standard_shipping_time', array(
        'label'    => __('Standard Shipping Time', 'zayxyz'),
        'section'  => 'zayxyz_shipping_info',
        'settings' => 'standard_shipping_time',
        'type'     => 'text',
    ));
    // Control for 'Express Shipping' label
    $wp_customize->add_setting('express_shipping_label', array(
        'default'   => __('Express Shipping', 'zayxyz'),
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('express_shipping_label', array(
        'label'    => __('Express Shipping Label', 'zayxyz'),
        'section'  => 'zayxyz_shipping_info',
        'settings' => 'express_shipping_label',
        'type'     => 'text',
    ));
    // Control for 'Express Shipping' time
    $wp_customize->add_setting('express_shipping_time', array(
        'default'   => __('1-2 business days', 'zayxyz'),
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('express_shipping_time', array(
        'label'    => __('Express Shipping Time', 'zayxyz'),
        'section'  => 'zayxyz_shipping_info',
        'settings' => 'express_shipping_time',
        'type'     => 'text',
    ));
    // Control for 'Return Policy' title
    $wp_customize->add_setting('return_policy_title', array(
        'default'   => __('Return Policy', 'zayxyz'),
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('return_policy_title', array(
        'label'    => __('Return Policy Title', 'zayxyz'),
        'section'  => 'zayxyz_shipping_info',
        'settings' => 'return_policy_title',
        'type'     => 'text',
    ));
    // Control for 'Return Policy' text
    $wp_customize->add_setting('return_policy_text', array(
        'default'   => __('We offer 30-day money back guarantee for all our products. If you\'re not satisfied with your purchase, simply return it for a full refund.', 'zayxyz'),
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('return_policy_text', array(
        'label'    => __('Return Policy Text', 'zayxyz'),
        'section'  => 'zayxyz_shipping_info',
        'settings' => 'return_policy_text',
        'type'     => 'text',
    ));
}




add_action('customize_register', 'zayxyz_customize_register_home');