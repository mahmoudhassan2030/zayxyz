<?php
/**
 * Template Name: Home
 *
 * Displays Only Home template
 *
 * @package WordPress
 * @subpackage codevers2e 
 * @since codevers2e  1.0
 */
get_header(); ?>

<?php get_template_part('section-slider'); ?>


<!-- Modal -->
<div class="modal fade bg-white" id="templatemo_search" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="w-100 pt-1 mb-5 text-right">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?php echo esc_url(home_url('/')); ?>" method="get" class="modal-content modal-body border-0 p-0">
            <div class="input-group mb-2">
                <input type="text" class="form-control" id="inputModalSearch" name="s" placeholder="Search ...">
                <input type="hidden" name="post_type" value="product">
                <button type="submit" class="input-group-text bg-success text-light">
                    <i class="fa fa-fw fa-search text-white"></i>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- سلايدر جديد يعتمد على الحقول المخصصة في الـ Customizer -->
<?php
$slides = array();
for (
    $i = 1; $i <= 6; $i++) {
    $img = get_theme_mod("slider_image_$i");
    // جلب رابط الصورة بشكل مضمون
    if (!empty($img) && is_numeric($img)) {
        $img_url = wp_get_attachment_url($img);
    } elseif (!empty($img) && filter_var($img, FILTER_VALIDATE_URL)) {
        $img_url = $img;
    } else {
        $img_url = '';
    }
    $title = get_theme_mod("slider_title_$i");
    $sub_title = get_theme_mod("slider_sub_title_$i");
    $desc = get_theme_mod("slider_desc_$i");
    $btn_text = get_theme_mod("slider_button_text_$i");
    $btn_url = get_theme_mod("slider_button_url_$i");
    if ($img_url) {
        $slides[] = array(
            'img' => $img_url,
            'title' => $title,
            'sub_title' => $sub_title,
            'desc' => $desc,
            'btn_text' => $btn_text,
            'btn_url' => $btn_url,
        );
    }
}
?>

<?php
// دالة لتحويل قيمة الاستايل إلى CSS
function get_font_style_css($style) {
    switch ($style) {
        case 'bold': return 'font-weight:bold;';
        case 'italic': return 'font-style:italic;';
        case 'bold_italic': return 'font-weight:bold;font-style:italic;';
        default: return '';
    }
}
?>

<section class="container py-5">
    <div class="row text-center pt-3">
        <div class="col-lg-6 m-auto">
            <h1 class="h1 text-uppercase fw-bold mb-3" style="color: <?php echo esc_attr(get_theme_mod('categories_title_color', '#1565c0')); ?>;<?php echo get_font_style_css(get_theme_mod('categories_title_font_style', 'normal')); ?>">
                <?php echo esc_html(get_theme_mod('categories_section_title', __('Categories of The Month!', 'zayxyz'))); ?>
            </h1>
            <p class="lead mb-4" style="color: <?php echo esc_attr(get_theme_mod('categories_desc_color', '#1976d2')); ?>;<?php echo get_font_style_css(get_theme_mod('categories_desc_font_style', 'normal')); ?>">
                <?php echo esc_html(get_theme_mod('categories_section_desc', __('Discover our curated collection of premium products!', 'zayxyz'))); ?>
            </p>
            <?php if (get_theme_mod('categories_btn_show', true)) : ?>
                <a href="<?php echo esc_url(get_theme_mod('categories_btn_url', '#')); ?>" class="btn px-4 py-2 mb-3" style="background: <?php echo esc_attr(get_theme_mod('categories_btn_bg', '#1565c0')); ?>; color: <?php echo esc_attr(get_theme_mod('categories_btn_color', '#fff')); ?>; border: none; font-weight:600;">
                    <?php echo esc_html(get_theme_mod('categories_btn_text', 'Shop Now')); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="row justify-content-center">
        <?php
        $transient_key = 'home_categories_' . get_locale();
        $categories_count = intval(get_theme_mod('categories_count', 6));
        $cached_categories = get_transient($transient_key);
        
        if (isset($_GET['flush_cache'])) {
            delete_transient($transient_key);
            $cached_categories = false;
        }
        
        if ($cached_categories !== false) {
            $categories = $cached_categories;
        } else {
            $args = array(
                'post_type' => 'monthly_category',
                'posts_per_page' => $categories_count,
                'orderby' => 'date',
                'order' => 'DESC',
                'post_status' => 'publish'
            );

            $categories = get_posts($args);
            set_transient($transient_key, $categories, 12 * HOUR_IN_SECONDS);
        }

        if ($categories && !empty($categories)) :
            echo '<div class="row g-4 mb-4 justify-content-center">';
            
            $counter = 0;
            foreach ($categories as $category) :
                if ($counter >= $categories_count) break;
                $image_id = get_post_thumbnail_id($category->ID);
                $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'medium') : '';
                
                if (empty($image_url)) {
                    $image_url = get_template_directory_uri() . '/assets/img/default-category.jpg';
                }
                
                // الحصول على رابط تصنيف المنتجات في ووكومرس
                $shop_url = get_post_meta($category->ID, 'category_shop_url', true);
                
                // إذا لم يكن الرابط موجوداً، البحث عن التصنيف في ووكومرس
                if (empty($shop_url)) {
                    $term = get_term_by('name', $category->post_title, 'product_cat');
                    if ($term && !is_wp_error($term)) {
                        $shop_url = get_term_link($term);
                    } else {
                        $shop_url = '#';
                    }
                }
                ?>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="category-card h-100 p-4 bg-white rounded-3 shadow-sm text-center animated" data-aos="zoom-in-up">
                        <a href="<?php echo esc_url($shop_url); ?>" class="d-block mb-3">
                            <div class="category-image-wrapper mx-auto animated" data-aos="flip-left">
                                <img src="<?php echo esc_url($image_url); ?>" 
                                     class="img-fluid" 
                                     alt="<?php echo esc_attr($category->post_title); ?>">
                            </div>
                        </a>
                        <h5 class="fw-bold mb-3"><?php echo esc_html($category->post_title); ?></h5>
                        <a href="<?php echo esc_url($shop_url); ?>" class="btn btn-outline-success px-3 py-2">
                            <?php echo esc_html(get_theme_mod('categories_button_text', __('Go Shop', 'zayxyz'))); ?>
                        </a>
                    </div>
                </div>
                <?php
                
                $counter++;
                if ($counter % 3 === 0 && $counter < count($categories)) {
                    echo '</div><div class="row g-4 mb-4 justify-content-center">';
                }
            endforeach;
            
            echo '</div>';
        else:
            ?>
            <div class="col-12">
                <div class="alert alert-info text-center py-4">
                    <i class="fas fa-info-circle fa-2x mb-3"></i>
                    <h4><?php esc_html_e('No categories available', 'zayxyz'); ?></h4>
                    <p class="mb-0"><?php esc_html_e('Please add categories from the admin panel', 'zayxyz'); ?></p>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="text-center mt-4">
        <a href="?flush_cache=1" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-sync me-1"></i> <?php esc_html_e('Refresh Categories', 'zayxyz'); ?>
        </a>
    </div>
</section>
<!-- End Categories of The Month -->

<!-- Start Special Offer Section -->
<!-- تم حذف التكرار: <?php get_template_part('template-parts/special-offer'); ?> -->
<!-- End Special Offer Section -->

<!-- Start Featured Products -->
<section class="bg-light">
    <div class="container py-5">
        <div class="row text-center py-3">
            <div class="col-lg-6 m-auto">
                <h1 class="h1 mb-3" style="color: <?php echo esc_attr(get_theme_mod('spotlight_title_color', '#1565c0')); ?>;<?php echo get_font_style_css(get_theme_mod('spotlight_title_font_style', 'normal')); ?>">
                    <?php echo esc_html(get_theme_mod('spotlight_section_title', __('Product Spotlight!', 'zayxyz'))); ?>
                </h1>
                <p class="mb-4" style="color: <?php echo esc_attr(get_theme_mod('spotlight_desc_color', '#1976d2')); ?>;<?php echo get_font_style_css(get_theme_mod('spotlight_desc_font_style', 'normal')); ?>">
                    <?php echo esc_html(get_theme_mod('spotlight_section_desc', __('Take a closer look at our most recommended items?', 'zayxyz'))); ?>
                </p>
                <?php if (get_theme_mod('spotlight_btn_show', true)) : ?>
                    <a href="<?php echo esc_url(get_theme_mod('spotlight_btn_url', '#')); ?>" class="btn px-4 py-2 mb-3" style="background: <?php echo esc_attr(get_theme_mod('spotlight_btn_bg', '#1565c0')); ?>; color: <?php echo esc_attr(get_theme_mod('spotlight_btn_color', '#fff')); ?>; border: none; font-weight:600;">
                        <?php echo esc_html(get_theme_mod('spotlight_btn_text', 'See More')); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="row">
            <?php
            // الحصول على عدد المنتجات من الإعدادات
            $products_count = get_theme_mod('spotlight_count', 3);
            
            // جلب المنتجات المميزة
            $featured_query = new WP_Query(array(
                'post_type' => 'product',
                'posts_per_page' => $products_count,
                'post_status' => 'publish',
                'tax_query' => array(
                    array(
                        'taxonomy' => 'product_visibility',
                        'field'    => 'name',
                        'terms'    => 'featured',
                    )
                )
            ));
            
            if ($featured_query->have_posts()) :
                while ($featured_query->have_posts()) : $featured_query->the_post();
                    global $product;
            ?>
                    <div class="col-12 col-md-4 mb-4">
                        <?php wc_get_template_part('content', 'product'); ?>
                    </div>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
            ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <div class="mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="currentColor" class="bi bi-info-circle text-info" viewBox="0 0 16 16">
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                            <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                        </svg>
                    </div>
                    <h3 class="h2 text-muted mb-3">
                        <?php esc_html_e('لا توجد منتجات مميزة حالياً', 'textdomain'); ?>
                    </h3>
                    <p class="lead text-muted">
                        <?php esc_html_e('سيتم عرض المنتج المميز هنا بمجرد تحديده من لوحة التحكم', 'textdomain'); ?>
                    </p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- End Featured Products -->

<!-- Start Special Offer -->
<?php if (get_theme_mod('offer_show', true)) : ?>
<section class="special-offer-section" style="background: <?php echo esc_attr(get_theme_mod('offer_bg', '#f5f6fa')); ?>;">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <?php if (get_theme_mod('offer_discount_bar_show', true)) : ?>
                <div class="offer-progress mb-3" style="max-width: 420px; margin: 0 auto 18px auto;">
                    <?php
                        $discount_text = get_theme_mod('offer_discount_text', '30% OFF');
                        preg_match('/(\d+)%/', $discount_text, $matches);
                        $discount_percent = isset($matches[1]) ? intval($matches[1]) : 0;
                        $bar_grad_start = get_theme_mod('offer_bar_gradient_start', '#ff9800');
                        $bar_grad_end = get_theme_mod('offer_bar_gradient_end', '#ffe259');
                        $text_color = get_theme_mod('offer_discount_color', '#fff');
                        $old_price = get_theme_mod('offer_old_price', '133');
                        $new_price = get_theme_mod('offer_new_price', '111');
                    ?>
                    <div class="offer-progress-bar-container" style="position: relative; height: 54px; background: rgba(255,255,255,0.18); border-radius: 28px; overflow: hidden; box-shadow: 0 6px 32px rgba(0,0,0,0.13); min-width: 120px; backdrop-filter: blur(4px); display: flex; align-items: center;">
                        <div class="offer-progress-bar" style="width: <?php echo $discount_percent; ?>%; background: linear-gradient(90deg, <?php echo esc_attr($bar_grad_start); ?>, <?php echo esc_attr($bar_grad_end); ?>); height: 100%; border-radius: 28px; display: flex; align-items: center; justify-content: flex-end; transition: width 0.7s; position: absolute; left: 0; top: 0; box-shadow: 0 2px 12px rgba(0,0,0,0.10);">
                            <span class="offer-progress-bar-text" style="color: <?php echo esc_attr($text_color); ?>; font-weight: bold; font-size: 1.3rem; letter-spacing: 1px; width: 100%; text-align: center; position: relative; z-index:2; white-space:nowrap; text-shadow: 0 1px 8px rgba(0,0,0,0.13); mix-blend-mode: lighten;">
                                <i class="fas fa-bolt me-2" style="color: #fff700; filter: drop-shadow(0 1px 4px #fff70099);"></i>
                                <?php echo esc_html($discount_text); ?>
                            </span>
                        </div>
                        <span class="offer-progress-percent" style="position: absolute; right: 18px; top: 50%; transform: translateY(-50%); font-size: 1.1rem; font-weight: bold; color: <?php echo esc_attr($bar_grad_start); ?>; z-index: 3; text-shadow: 0 1px 8px #fff; background: rgba(255,255,255,0.7); border-radius: 12px; padding: 2px 12px; min-width: 48px; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,0.07);">
                            <?php echo $discount_percent; ?>%
                        </span>
                    </div>
                    <div class="d-flex justify-content-center align-items-center gap-3 mb-4" style="margin-top: 6px;">
                        <span style="font-size: 1.1rem; color: #888; text-decoration: line-through; font-weight: 500;">$<?php echo esc_html($old_price); ?></span>
                        <span style="font-size: 1.3rem; color: <?php echo esc_attr($bar_grad_start); ?>; font-weight: bold;">$<?php echo esc_html($new_price); ?></span>
                    </div>
                </div>
                <?php endif; ?>
                <h2 class="special-offer-title mt-2 mb-3" style="color: <?php echo esc_attr(get_theme_mod('offer_title_color', '#1565c0')); ?>;">
                    <?php echo esc_html(get_theme_mod('offer_title', 'Special Offer!')); ?>
                </h2>
                <p class="offer-description mb-4" style="color: <?php echo esc_attr(get_theme_mod('offer_desc_color', '#1976d2')); ?>;">
                    <?php echo esc_html(get_theme_mod('offer_desc', 'Get 30% off on all summer collection items. Limited time offer!')); ?>
                </p>
                <?php if (get_theme_mod('offer_timer_show', true)) : ?>
                <?php
                    $offer_end_date = get_theme_mod('offer_end_date', date('Y-m-d', strtotime('+7 days')));
                    $offer_end_time = get_theme_mod('offer_end_time', '23:59');
                ?>
                <div class="offer-timer mb-4" style="color: <?php echo esc_attr(get_theme_mod('offer_timer_color', '#1565c0')); ?>;">
                    <i class="fas fa-clock"></i>
                    <span><?php echo esc_html(get_theme_mod('offer_timer_text', 'Offer ends in:')); ?></span>
                    <div class="countdown-timer">
                        <div class="countdown-segment">
                            <span class="countdown-number" id="days">00</span>
                            <span class="countdown-label">Days</span>
                        </div>
                        <div class="countdown-separator">:</div>
                        <div class="countdown-segment">
                            <span class="countdown-number" id="hours">00</span>
                            <span class="countdown-label">Hours</span>
                        </div>
                        <div class="countdown-separator">:</div>
                        <div class="countdown-segment">
                            <span class="countdown-number" id="minutes">00</span>
                            <span class="countdown-label">Minutes</span>
                        </div>
                        <div class="countdown-separator">:</div>
                        <div class="countdown-segment">
                            <span class="countdown-number" id="seconds">00</span>
                            <span class="countdown-label">Seconds</span>
                        </div>
                    </div>
                </div>
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    var endDateStr = "<?php echo esc_js($offer_end_date); ?>";
                    var endTimeStr = "<?php echo esc_js($offer_end_time); ?>";
                    var endDateTime = new Date(endDateStr + 'T' + endTimeStr + ':00');

                    function updateCountdown() {
                        var now = new Date();
                        var diff = endDateTime - now;

                        if (diff <= 0) {
                            document.getElementById('days').textContent = '00';
                            document.getElementById('hours').textContent = '00';
                            document.getElementById('minutes').textContent = '00';
                            document.getElementById('seconds').textContent = '00';
                            return;
                        }

                        var days = Math.floor(diff / (1000 * 60 * 60 * 24));
                        var hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
                        var minutes = Math.floor((diff / (1000 * 60)) % 60);
                        var seconds = Math.floor((diff / 1000) % 60);

                        document.getElementById('days').textContent = days.toString().padStart(2, '0');
                        document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
                        document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
                        document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
                    }

                    updateCountdown();
                    setInterval(updateCountdown, 1000);
                });
                </script>
                <?php endif; ?>
                <a href="<?php echo esc_url(get_theme_mod('offer_btn_url', '#')); ?>" class="btn px-4 py-2 mb-3" style="background: <?php echo esc_attr(get_theme_mod('offer_btn_bg', '#1565c0')); ?>; color: <?php echo esc_attr(get_theme_mod('offer_btn_color', '#fff')); ?>; border: none; font-weight:600;">
                    <?php echo esc_html(get_theme_mod('offer_btn_text', 'Shop Now')); ?>
                </a>
            </div>
            <div class="col-lg-6">
                <div class="offer-images" data-aos="fade-left">
                    <?php for ($i = 1; $i <= 2; $i++) : 
                        $img = get_theme_mod('offer_image_' . $i, get_template_directory_uri() . '/assets/img/offer-' . $i . '.jpg');
                    ?>
                    <div class="offer-image">
                        <img src="<?php echo esc_url($img); ?>" alt="" class="img-fluid">
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<!-- End Special Offer -->

<?php get_footer(); ?>


<script>

    // تهيئة الكاروسيل مع إعدادات مخصصة
const myCarousel = new bootstrap.Carousel('#template-mo-zay-hero-carousel', {
    interval: 6000,
    wrap: true,
    touch: true,
    keyboard: true,
    pause: 'hover'
});

// إضافة تأثير سلس للانتقال
document.querySelectorAll('.carousel-item').forEach(item => {
    item.style.transition = 'transform 0.7s ease-in-out, opacity 0.7s ease-in-out';
});
document.addEventListener('DOMContentLoaded', function() {
    // Initialize carousel
    const myCarousel = document.getElementById('template-mo-zay-hero-carousel');
    const carousel = new bootstrap.Carousel(myCarousel, {
        interval: 5000,
        wrap: true
    });
    
    // Lazy load images
    if ('loading' in HTMLImageElement.prototype) {
        const images = document.querySelectorAll('img.lazyload');
        images.forEach(img => {
            img.src = img.dataset.src;
        });
    } else {
        // Dynamically load a polyfill if needed
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.3.2/lazysizes.min.js';
        document.body.appendChild(script);
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});


