<?php
/**
 * Template Name: about
 *
 * Displays the about template
 *
 * @package WordPress
 * @subpackage codevers2e 
 * @since codevers2e  1.0
 */

get_header(); ?>

<!-- Hero Section -->
<section class="bg-success py-5" style="background-color: <?php echo esc_attr(get_theme_mod('about_bg_color', '#59ab6e')); ?> !important;">
    <div class="container">
        <div class="row align-items-center py-5">
            <div class="col-md-8 text-white">
                <h1 class="about-title display-4 fw-bold mb-4">
                    <?php echo esc_html(get_theme_mod('about_title', 'About Us')); ?>
                </h1>
                <p class="about-description lead">
                    <?php echo wp_kses_post(get_theme_mod('about_description', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.')); ?>
                </p>
                <div class="mt-4">
                    <?php
                    // Get button settings
                    $services_enabled = get_theme_mod('about_services_button_enabled', true);
                    $brands_enabled = get_theme_mod('about_brands_button_enabled', true);
                    $services_text = esc_html(get_theme_mod('about_services_button_text', 'Our Services'));
                    $brands_text = esc_html(get_theme_mod('about_brands_button_text', 'Our Brands'));
                    $services_url = esc_url(get_theme_mod('about_services_button_url', '#services'));
                    $brands_url = esc_url(get_theme_mod('about_brands_button_url', '#brands'));
                    $services_style = esc_attr(get_theme_mod('about_services_button_style', 'btn-light'));
                    $brands_style = esc_attr(get_theme_mod('about_brands_button_style', 'btn-outline-light'));
                    $button_size = esc_attr(get_theme_mod('about_buttons_size', 'btn-lg'));
                    $button_spacing = esc_attr(get_theme_mod('about_buttons_spacing', 'me-3'));
                    
                    // Services Button
                    if ($services_enabled) : ?>
                        <a href="<?php echo $services_url; ?>" class="btn <?php echo $services_style; ?> <?php echo $button_size; ?> <?php echo $button_spacing; ?>">
                            <?php echo $services_text; ?>
                        </a>
                    <?php endif; ?>
                    
                    <!-- Brands Button -->
                    <?php if ($brands_enabled) : ?>
                        <a href="<?php echo $brands_url; ?>" class="btn <?php echo $brands_style; ?> <?php echo $button_size; ?>">
                            <?php echo $brands_text; ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <?php 
                $about_image = esc_url(get_theme_mod('about_image', get_template_directory_uri() . '/assets/img/about-hero.svg'));
                $about_image_width = esc_attr(get_theme_mod('about_image_width', '300'));
                $about_title = esc_attr(get_theme_mod('about_title', 'About Us'));
                ?>
                <img class="img-fluid rounded-circle shadow-lg animate__animated animate__pulse" 
                     style="width: <?php echo $about_image_width; ?>px; height: auto;" 
                     src="<?php echo $about_image; ?>" 
                     alt="<?php echo $about_title; ?>"
                     loading="lazy">
            </div>
        </div>
    </div>
</section>

<!-- Services Section -->
<section id="services" class="container py-5">
    <div class="row text-center pt-5 pb-3">
        <div class="col-lg-8 mx-auto">
            <h2 class="h1 services-title mb-4">
                <?php echo esc_html(get_theme_mod('services_title', 'Our Services')); ?>
            </h2>
            <p class="services-description text-muted mb-5">
                <?php echo wp_kses_post(get_theme_mod('services_description', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod Lorem ipsum dolor sit amet.')); ?>
            </p>
        </div>
    </div>
    <div class="row g-4">
        <?php
        $services_count = get_theme_mod('services_count', 4);
        for ($i = 1; $i <= $services_count; $i++) :
            $title = get_theme_mod("service_{$i}_title");
            $description = get_theme_mod("service_{$i}_description");
            $icon = get_theme_mod("service_{$i}_icon");
            $icon_bg_color = get_theme_mod("service_{$i}_icon_bg_color", '#59ab6e');
            $icon_color = get_theme_mod("service_{$i}_icon_color", '#ffffff');

            // Default values if settings are empty
            $title = $title ? esc_html($title) : "Service {$i}";
            $description = $description ? wp_kses_post($description) : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.';
            $icon = $icon ? esc_attr($icon) : 'fa-star';
            
            if (empty(get_theme_mod("service_{$i}_title"))) {
                continue; // Skip if title is not set to avoid empty blocks
            }
        ?>
        <div class="col-md-6 col-lg-3">
            <div class="card h-100 border-0 shadow-sm hover-shadow transition-all">
                <div class="card-body text-center p-4">
                    <div class="icon-wrapper rounded-circle d-inline-flex align-items-center justify-content-center mb-4" style="width: 80px; height: 80px; background-color: <?php echo esc_attr($icon_bg_color); ?>;">
                        <i class="fa <?php echo $icon; ?> fa-2x" style="color: <?php echo esc_attr($icon_color); ?>;"></i>
                    </div>
                    <h3 class="h5 card-title mb-3">
                        <?php echo $title; ?>
                    </h3>
                    <p class="card-text text-muted">
                        <?php echo $description; ?>
                    </p>
                </div>
            </div>
        </div>
        <?php endfor; ?>
    </div>
</section>

<!-- Team Section -->
<section class="bg-light py-5">
    <div class="container py-5">
        <div class="row text-center mb-5">
            <div class="col-lg-8 mx-auto">
                <h2 class="display-5 fw-bold mb-3"><?php echo esc_html(get_theme_mod('team_section_title', 'Our Team')); ?></h2>
                <p class="lead text-muted"><?php echo esc_html(get_theme_mod('team_section_description', 'Meet the talented people behind our success')); ?></p>
            </div>
        </div>
        <div class="row g-4">
            <?php
            $team_members_count = get_theme_mod('team_members_count', 3);
            for ($i = 1; $i <= $team_members_count; $i++) :
                $image = get_theme_mod("team_member_{$i}_image");
                $name = get_theme_mod("team_member_{$i}_name", "Team Member {$i}");
                $position = get_theme_mod("team_member_{$i}_position", "Position Title");
                $description = get_theme_mod("team_member_{$i}_description", "A brief overview of the member or his position in the team.");
                $rating = get_theme_mod("team_member_{$i}_rating", 5);

                $socials = array(
                    'twitter' => array('icon' => 'fab fa-twitter', 'url' => get_theme_mod("team_member_{$i}_twitter_url", '#')),
                    'linkedin' => array('icon' => 'fab fa-linkedin-in', 'url' => get_theme_mod("team_member_{$i}_linkedin_url", '#')),
                    'facebook' => array('icon' => 'fab fa-facebook-f', 'url' => get_theme_mod("team_member_{$i}_facebook_url", '#')),
                );
            ?>
            <div class="col-md-4">
                <div class="card team-card shadow-sm h-100">
                    <div class="team-avatar mx-auto mt-4 mb-2" style="
                        <?php if ($image) : ?>
                            background-image: url('<?php echo esc_url($image); ?>');
                            background-size: cover;
                            background-position: center;
                            background-repeat: no-repeat;
                        <?php else: ?>
                            background-color: #e9ecef; /* Placeholder color */
                        <?php endif; ?>
                    "></div>
                    <div class="card-body text-center p-4">
                        <h3 class="h5 mb-2"><?php echo esc_html($name); ?></h3>
                        <p class="text-muted mb-2"><?php echo esc_html($position); ?></p>
                        <p class="team-desc mb-3"><?php echo wp_kses_post($description); ?></p>
                        <div class="team-stars mb-3">
                            <?php for ($star = 1; $star <= 5; $star++) : ?>
                                <i class="<?php echo ($star <= $rating) ? 'fas' : 'far'; ?> fa-star"></i>
                            <?php endfor; ?>
                        </div>
                        <div class="d-flex justify-content-center gap-2">
                            <?php foreach ($socials as $name => $data) : ?>
                                <?php if (!empty($data['url']) && $data['url'] !== '#') : ?>
                                    <a href="<?php echo esc_url($data['url']); ?>" class="btn btn-sm btn-outline-secondary rounded-circle p-2" title="<?php echo ucfirst($name); ?>" target="_blank" rel="noopener noreferrer">
                                        <i class="<?php echo esc_attr($data['icon']); ?>"></i>
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endfor; ?>
        </div>
    </div>
</section>

<!-- Brands Section -->
<section id="brands" class="py-5">
    <div class="container my-4">
        <div class="row text-center py-3">
            <div class="col-lg-8 mx-auto">
                <h2 class="h1 brands-title mb-4">
                    <?php echo esc_html(get_theme_mod('brands_title', 'Our Brands')); ?>
                </h2>
                <p class="brands-description text-muted mb-5">
                    <?php echo wp_kses_post(get_theme_mod('brands_description', 'We partner with the world\'s leading brands to deliver exceptional products and services.')); ?>
                </p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <div class="brand-carousel">
                    <?php
                    $brands_count = intval(get_theme_mod('brands_count', 6));
                    $brands_per_slide = intval(get_theme_mod('brands_per_slide', 6));
                    
                    if ($brands_count > 0 && $brands_per_slide > 0) :
                        $slides_count = ceil($brands_count / $brands_per_slide);
                        
                        for ($slide = 0; $slide < $slides_count; $slide++) :
                            $is_active = $slide === 0 ? ' active' : '';
                        ?>
                        <div class="brand-slide<?php echo $is_active; ?>">
                            <div class="row justify-content-center g-4">
                                <?php
                                    $start_brand = $slide * $brands_per_slide + 1;
                                    $end_brand = min($start_brand + $brands_per_slide - 1, $brands_count);

                                    for ($i = $start_brand; $i <= $end_brand; $i++) :
                                        $brand_image = get_theme_mod("brand_image_{$i}");
                                        
                                        if (empty($brand_image)) {
                                            continue;
                                        }

                                        $brand_link = esc_url(get_theme_mod("brand_link_{$i}", '#'));
                                        $brand_alt_text = get_theme_mod("brand_alt_{$i}");
                                        $brand_alt = !empty($brand_alt_text) ? esc_attr($brand_alt_text) : sprintf(esc_attr__('Brand %d Logo', 'codevers2e'), $i);
                                    ?>
                                <div class="col-4 col-md-2">
                                    <a href="<?php echo $brand_link; ?>" class="d-block p-3 bg-white shadow-sm rounded-3 h-100 d-flex align-items-center justify-content-center" target="_blank" rel="noopener noreferrer">
                                        <img class="img-fluid brand-img" 
                                             src="<?php echo esc_url($brand_image); ?>" 
                                             alt="<?php echo $brand_alt; ?>"
                                             loading="lazy"
                                             style="max-height: 60px;">
                                    </a>
                                </div>
                                <?php endfor; ?>
                            </div>
                        </div>
                        <?php endfor; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Stats Bar Section -->
<?php
$stats_count = get_theme_mod('stats_count', 0);
if ($stats_count > 0) :
    $stats_bar_bg_color = get_theme_mod('stats_bar_bg_color', '#343a40');
?>
<section class="py-5 text-white" style="background-color: <?php echo esc_attr($stats_bar_bg_color); ?>;">
    <div class="container">
        <div class="row text-center">
            <?php for ($i = 1; $i <= $stats_count; $i++) :
                $value = get_theme_mod("stat_{$i}_value");
                $label = get_theme_mod("stat_{$i}_label");
                if ($value && $label) : ?>
                <div class="col-md-3 col-6">
                    <h3 class="display-6 fw-bold"><?php echo esc_html($value); ?></h3>
                    <p class="mb-0"><?php echo esc_html($label); ?></p>
                </div>
            <?php endif; endfor; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Testimonials Section -->
<?php
$testimonials_count = get_theme_mod('testimonials_count', 0);
if ($testimonials_count > 0) :
    $testimonials_per_slide = get_theme_mod('testimonials_per_slide', 3);
    $slides_count = ceil($testimonials_count / $testimonials_per_slide);
?>
<section class="py-5">
    <div class="container">
        <div class="row text-center mb-5">
            <div class="col-lg-8 mx-auto">
                <h2 class="h1"><?php echo esc_html(get_theme_mod('testimonials_title', 'What Our Clients Say')); ?></h2>
                <p class="text-muted"><?php echo esc_html(get_theme_mod('testimonials_description', 'Don\'t just take our word for it')); ?></p>
            </div>
        </div>
        <div id="testimonial-carousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php for ($slide = 0; $slide < $slides_count; $slide++) : ?>
                <div class="carousel-item <?php echo ($slide === 0) ? 'active' : ''; ?>">
                    <div class="row justify-content-center align-items-stretch">
                        <?php
                        $start_testimonial = $slide * $testimonials_per_slide + 1;
                        $end_testimonial = min($start_testimonial + $testimonials_per_slide - 1, $testimonials_count);
                        for ($i = $start_testimonial; $i <= $end_testimonial; $i++) :
                            $name = get_theme_mod("testimonial_{$i}_name");
                            if (empty($name)) continue;
                            
                            $image = get_theme_mod("testimonial_{$i}_image");
                            $position = get_theme_mod("testimonial_{$i}_position");
                            $quote = get_theme_mod("testimonial_{$i}_quote");
                            $rating = get_theme_mod("testimonial_{$i}_rating", 5);

                        $col_class = 'col-lg-4';
                        $cards_on_this_slide = $end_testimonial - $start_testimonial + 1;
                        if ($cards_on_this_slide < $testimonials_per_slide) {
                           switch($cards_on_this_slide) {
                               case 1:
                                   $col_class = 'col-lg-6';
                                   break;
                               case 2:
                                   $col_class = 'col-lg-5';
                                   break;
                           }
                        }
                        ?>
                        <div class="<?php echo $col_class; ?> col-md-6 mb-4 d-flex">
                            <div class="card h-100 border-0 shadow-sm p-4 flex-fill">
                                <div class="card-body text-center d-flex flex-column">
                                    <?php if ($image) : ?>
                                        <img src="<?php echo esc_url($image); ?>" class="rounded-circle mb-3" alt="<?php echo esc_attr($name); ?>" style="width: 80px; height: 80px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="rounded-circle mb-3 bg-secondary mx-auto" style="width: 80px; height: 80px;"></div>
                                    <?php endif; ?>
                                    <h5 class="card-title fw-bold"><?php echo esc_html($name); ?></h5>
                                    <h6 class="card-subtitle mb-2 text-muted"><?php echo esc_html($position); ?></h6>
                                    <p class="card-text fst-italic text-muted flex-grow-1">"<?php echo wp_kses_post($quote); ?>"</p>
                                    <div class="text-warning mt-3">
                                        <?php for ($star = 1; $star <= 5; $star++) : ?>
                                            <i class="<?php echo ($star <= $rating) ? 'fas' : 'far'; ?> fa-star"></i>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
                <?php endfor; ?>
            </div>
            <?php if ($slides_count > 1) : ?>
                <button class="carousel-control-prev" type="button" data-bs-target="#testimonial-carousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true" style="filter: invert(1);"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#testimonial-carousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true" style="filter: invert(1);"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php get_footer(); ?>
