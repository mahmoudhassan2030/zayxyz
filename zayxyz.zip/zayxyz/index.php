<?php get_header(); ?>

<!-- Main Content Wrapper -->
<main id="main-content" class="container py-5">
    <div class="row">
        <!-- Main Content Area (يمكنك إضافة حلقة ووردبريس هنا لاحقاً) -->
        <div class="col-lg-8">
            <!-- Content will be added here if needed -->
        </div>
        <!-- Sidebar -->
        <div class="col-lg-4">
            <aside class="sidebar">
                <?php get_sidebar(); ?>
            </aside>
        </div>
    </div>
</main>
<style>

    /* Main Layout */
#main-content {
    padding-top: 3rem;
    padding-bottom: 5rem;
}

/* Pagination */
.pagination {
    display: flex;
    justify-content: center;
    margin-top: 3rem;
}

.page-numbers {
    display: flex;
    list-style: none;
    padding: 0;
    gap: 0.5rem;
    flex-wrap: wrap;
}

.page-numbers li {
    margin: 0.2rem;
}

.page-numbers a,
.page-numbers span {
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 40px;
    height: 40px;
    border-radius: 50%;
    text-decoration: none;
    padding: 0 0.5rem;
    font-weight: 600;
    transition: all 0.3s ease;
    font-size: 0.9rem;
}

.page-numbers a {
    color: #333;
    border: 1px solid #ddd;
}

.page-numbers a:hover {
    background: #59ab6e;
    color: white;
    border-color: #59ab6e;
}

.page-numbers .current {
    background: #59ab6e;
    color: white;
    border-color: #59ab6e;
}

/* View Options */
.view-options .btn {
    border-radius: 50%;
    width: 36px;
    height: 36px;
    padding: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.view-options .btn.active {
    background: #59ab6e;
    color: white;
    border-color: #59ab6e;
}

/* Grid/List View */
.grid-view .post-card {
    display: block;
}

.list-view .posts-container {
    flex-direction: column;
}

.list-view .col-md-6 {
    flex: 0 0 100%;
    max-width: 100%;
}

.list-view .post-card {
    display: flex;
    flex-direction: row;
}

.list-view .post-thumbnail {
    flex: 0 0 40%;
    max-width: 40%;
}

.list-view .card-body {
    flex: 0 0 60%;
    max-width: 60%;
}

/* Responsive Design */
@media (max-width: 991.98px) {
    .list-view .post-card {
        flex-direction: column;
    }
    
    .list-view .post-thumbnail,
    .list-view .card-body {
        flex: 0 0 100%;
        max-width: 100%;
    }
}

@media (max-width: 767.98px) {
    .featured-posts .col-md-6 {
        margin-bottom: 2rem;
    }
    
    .grid-view .col-md-6 {
        margin-bottom: 2rem;
    }
}
</style>
<?php get_footer(); ?>
