<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <title><?php wp_title('|', true, 'right'); ?> <?php bloginfo('name'); ?></title>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/apple-icon.png">
    <?php if (get_theme_mod('zayxyz_favicon')) : ?>
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo esc_url(get_theme_mod('zayxyz_favicon')); ?>">
    <?php else : ?>
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/favicon.ico">
    <?php endif; ?>

    <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/templatemo.css">
    <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/custom.css">
    <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/style.css">
    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/fontawesome.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- مكتبة AOS للحركات العصرية -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" />
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>document.addEventListener('DOMContentLoaded', function(){AOS.init({duration:900, once:true});});</script>
    <?php wp_head(); ?>
  
    <?php
    $gradient_start = get_theme_mod('gradient_start_color', '');
    $gradient_end = get_theme_mod('gradient_end_color', '');
    ?>
    <?php if (!empty($gradient_start) && !empty($gradient_end)) : ?>
    <style>
        header, .navbar, #templatemo_nav_top, footer, #tempaltemo_footer {
            background: transparent !important;
            background-color: transparent !important;
            box-shadow: none !important;
            border: none !important;
        }
    </style>
    <?php endif; ?>
    <?php
    $global_btn_bg = get_theme_mod('global_btn_bg', '#1565c0');
    $global_btn_color = get_theme_mod('global_btn_color', '#fff');
    $global_btn_bg_hover = get_theme_mod('global_btn_bg_hover', '#1976d2');
    $global_btn_color_hover = get_theme_mod('global_btn_color_hover', '#fff');
    ?>
    <style>
        .btn, .button, .btn-special, .woocommerce-mini-cart__buttons .button, .woocommerce ul.products li.product .button, .woocommerce-page ul.products li.product .button {
            background: <?php echo esc_attr($global_btn_bg); ?> !important;
            color: <?php echo esc_attr($global_btn_color); ?> !important;
            border: none !important;
        }
        .btn:hover, .button:hover, .btn-special:hover, .woocommerce-mini-cart__buttons .button:hover, .woocommerce ul.products li.product .button:hover, .woocommerce-page ul.products li.product .button:hover {
            background: <?php echo esc_attr($global_btn_bg_hover); ?> !important;
            color: <?php echo esc_attr($global_btn_color_hover); ?> !important;
        }
    </style>
</head>

<body <?php body_class(); ?>>

    <!-- Start Top Nav -->
    <?php $topbar_bg_color = get_theme_mod('topbar_bg_color', '#222'); ?>
    <style>
        .header-top-bar {
            background: linear-gradient(90deg, #38b2ac, #4299e1) !important; /* يمكنك تغيير التدرج من هنا أو ربطه بالـ Customizer */
        }
        #templatemo_nav_top {
            background: transparent !important;
        }
        .main-navbar, .navbar, .navbar-light, .navbar-expand-lg, .shadow {
            background: transparent !important;
            background-color: transparent !important;
            box-shadow: none !important;
            border: none !important;
        }
    </style>
    <div class="header-top-bar">
        <nav class="navbar navbar-expand-lg navbar-light d-none d-lg-block" id="templatemo_nav_top">
            <div class="container text-light">
                <div class="w-100 d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <?php if ( get_theme_mod('show_header_email', true) ) : ?>
                            <span class="header-email">
                                <i class="fa fa-envelope"></i>
                                <?php echo esc_html( get_theme_mod('company_email', 'info@company.com') ); ?>
                            </span>
                        <?php endif; ?>

                        <?php if ( get_theme_mod('show_header_phone', true) ) : ?>
                            <span class="header-phone">
                                <i class="fa fa-phone"></i>
                                <?php echo esc_html( get_theme_mod('company_phone', '010-020-0340') ); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex align-items-center">
        <?php if (get_theme_mod('show_social_icons', true)) : ?>
         <div class="social-icons">
            <?php
            $social_links = array(
                'facebook' => array('icon' => 'fab fa-facebook-f', 'url' => get_theme_mod('social_facebook'), 'show' => get_theme_mod('show_facebook_icon', true)),
                'twitter' => array('icon' => 'fab fa-twitter', 'url' => get_theme_mod('social_twitter'), 'show' => get_theme_mod('show_twitter_icon', true)),
                'instagram' => array('icon' => 'fab fa-instagram', 'url' => get_theme_mod('social_instagram'), 'show' => get_theme_mod('show_instagram_icon', true)),
                'linkedin' => array('icon' => 'fab fa-linkedin-in', 'url' => get_theme_mod('social_linkedin'), 'show' => get_theme_mod('show_linkedin_icon', true)),
                'youtube' => array('icon' => 'fab fa-youtube', 'url' => get_theme_mod('social_youtube'), 'show' => get_theme_mod('show_youtube_icon', true)),
                'whatsapp' => array('icon' => 'fab fa-whatsapp', 'url' => get_theme_mod('social_whatsapp'), 'show' => get_theme_mod('show_whatsapp_icon', true)),
            );
            foreach ($social_links as $platform => $data) {
                if (!empty($data['url']) && $data['show']) {
                    echo '<a href="' . esc_url($data['url']) . '" target="_blank" class="social-icon-link" title="' . ucfirst($platform) . '"><i class="' . esc_attr($data['icon']) . '" ></i></a>';
                }
            }
            ?>
         </div>
        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>
    </div>
    <!-- Close Top Nav -->

    <!-- Header -->
    <nav class="navbar main-navbar navbar-expand-lg navbar-light shadow">
        <div class="container d-flex justify-content-between align-items-center">

            <a class="navbar-brand text-success logo h1 align-self-center" href="<?php echo esc_url(home_url('/')); ?>">
                <?php
                $force_logo_text = get_theme_mod('force_logo_text', false);
                if (!$force_logo_text && has_custom_logo()) {
                    the_custom_logo();
                } else {
                    echo '<span style="color: ' . esc_attr(get_theme_mod('site_logo_color', '#59ab6e')) . ' !important;">';
                    echo esc_html(get_theme_mod('site_logo_text', get_bloginfo('name')));
                    echo '</span>';
                }
                ?>
            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="align-self-center collapse navbar-collapse flex-fill  d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
                
                <div class="flex-fill">
                    <?php wp_nav_menu(array(
                        'theme_location'    => 'primary',
                        'depth'             => 2,
                        'container'         => 'ul',
                        'container_class'   => '',
                        'container_id'      => '',
                        'menu_class'        => 'nav navbar-nav d-flex justify-content-between mx-lg-auto',
                        'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
                    )); ?>
                </div>
                
                <div class="navbar align-self-center d-flex align-items-center">
                    <!-- البحث -->
                    <a class="nav-icon search-icon me-2" href="#" data-bs-toggle="modal" data-bs-target="#templatemo_search" title="Search">
                        <i class="fas fa-search"></i>
                    </a>
                    <!-- السلة -->
                    <div class="custom-cart-wrapper">
                        <div id="mini-cart-container">
                            <?php get_template_part('inc/mini-cart-content'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- Close Header -->
    
    <!-- Modal البحث المحسن -->
    <div class="modal fade" id="templatemo_search" tabindex="-1" role="dialog" aria-labelledby="searchModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title" id="searchModalLabel">
                        <i class="fas fa-search me-2"></i>
                        <?php esc_html_e('Search Products', 'textdomain'); ?>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="get" action="<?php echo esc_url(home_url('/')); ?>" class="search-form">
                        <div class="input-group mb-3">
                            <input type="text" name="s" placeholder="<?php esc_attr_e('Type your search here...', 'textdomain'); ?>" class="form-control" required>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search me-2"></i>
                                <?php esc_html_e('Search', 'textdomain'); ?>
                            </button>
                        </div>
                    </form>
                    
                    <!-- اقتراحات البحث السريع -->
                    <div class="quick-search-suggestions mt-4">
                        <h6 class="text-muted mb-3">
                            <i class="fas fa-lightbulb me-2"></i>
                            <?php esc_html_e('Quick Suggestions', 'textdomain'); ?>
                        </h6>
                        <div class="d-flex flex-wrap gap-2">
                            <a href="<?php echo esc_url(home_url('/?s=New')); ?>" class="btn btn-outline-secondary btn-sm">
                                <?php esc_html_e('New Products', 'textdomain'); ?>
                            </a>
                            <a href="<?php echo esc_url(home_url('/?s=Offer')); ?>" class="btn btn-outline-secondary btn-sm">
                                <?php esc_html_e('Special Offers', 'textdomain'); ?>
                            </a>
                            <a href="<?php echo esc_url(home_url('/?s=Popular')); ?>" class="btn btn-outline-secondary btn-sm">
                                <?php esc_html_e('Most Popular', 'textdomain'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Update cart quantity
        function updateCartQuantity(key, quantity) {
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=update_cart_item&cart_key=${key}&quantity=${quantity}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update cart counters
                    document.querySelector('.cart-count').textContent = data.cart_count;
                    document.querySelector('.cart-total').innerHTML = data.cart_total;
                    
                    // Update specific item
                    const itemElement = document.querySelector(`.cart-item[data-key="${key}"]`);
                    if (itemElement) {
                        const priceElement = itemElement.querySelector('.cart-item-price');
                        if (priceElement) {
                            priceElement.innerHTML = data.item_price;
                        }
                    }
                    
                    // Update cart summary
                    if (data.cart_subtotal) {
                        const subtotalElement = document.querySelector('.cart-summary .cart-total span:last-child');
                        if (subtotalElement) {
                            subtotalElement.innerHTML = data.cart_subtotal;
                        }
                    }
                }
            })
            .catch(error => console.error('Error:', error));
        }
        
        // Remove item from cart
        function removeCartItem(key) {
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=remove_cart_item&cart_key=${key}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update cart counters
                    document.querySelector('.cart-count').textContent = data.cart_count;
                    document.querySelector('.cart-total').innerHTML = data.cart_total;
                    
                    // Remove item element
                    const itemElement = document.querySelector(`.cart-item[data-key="${key}"]`);
                    if (itemElement) {
                        itemElement.remove();
                    }
                    
                    // Update cart summary
                    if (data.cart_subtotal) {
                        const subtotalElement = document.querySelector('.cart-summary .cart-total span:last-child');
                        if (subtotalElement) {
                            subtotalElement.innerHTML = data.cart_subtotal;
                        }
                    }
                    
                    // If cart is empty, show empty message
                    if (data.cart_count == 0) {
                        document.querySelector('.cart-items').innerHTML = `
                            <div class="text-center py-4">
                                <i class="fas fa-shopping-cart fa-2x text-muted mb-3"></i>
                                <p class="mb-0"><?php esc_html_e('Your cart is empty', 'textdomain'); ?></p>
                            </div>
                        `;
                        // تصفير أو إخفاء السعر في الميني كارت
                        const subtotalElement = document.querySelector('.cart-summary .cart-total span:last-child');
                        if (subtotalElement) {
                            subtotalElement.innerHTML = '0';
                        }
                        document.querySelector('.cart-summary').innerHTML = '';
                        // تصفير السعر في الهيدر أو أي مكان آخر
                        const cartTotalText = document.querySelector('.cart-total-text');
                        if (cartTotalText) {
                            cartTotalText.innerHTML = '0';
                        }
                    }
                }
            })
            .catch(error => console.error('Error:', error));
        }
        
        // دالة لإعادة تفعيل الأحداث على عناصر الميني كارت
        function rebindMiniCartEvents() {
            document.querySelectorAll('.quantity-btn.minus').forEach(button => {
                button.replaceWith(button.cloneNode(true));
            });
            document.querySelectorAll('.quantity-btn.plus').forEach(button => {
                button.replaceWith(button.cloneNode(true));
            });
            document.querySelectorAll('.quantity-input').forEach(input => {
                input.replaceWith(input.cloneNode(true));
            });
            document.querySelectorAll('.remove-item').forEach(button => {
                button.replaceWith(button.cloneNode(true));
            });

            document.querySelectorAll('.quantity-btn.minus').forEach(button => {
                button.addEventListener('click', function() {
                    const key = this.getAttribute('data-key');
                    const input = this.closest('.cart-item-quantity').querySelector('.quantity-input');
                    let quantity = parseInt(input.value);
                    if (quantity > 1) {
                        quantity--;
                        input.value = quantity;
                        updateCartQuantity(key, quantity);
                    }
                });
            });
            document.querySelectorAll('.quantity-btn.plus').forEach(button => {
                button.addEventListener('click', function() {
                    const key = this.getAttribute('data-key');
                    const input = this.closest('.cart-item-quantity').querySelector('.quantity-input');
                    let quantity = parseInt(input.value);
                    quantity++;
                    input.value = quantity;
                    updateCartQuantity(key, quantity);
                });
            });
            document.querySelectorAll('.quantity-input').forEach(input => {
                input.addEventListener('change', function() {
                    const key = this.getAttribute('data-key');
                    let quantity = parseInt(this.value);
                    if (quantity < 1) quantity = 1;
                    this.value = quantity;
                    updateCartQuantity(key, quantity);
                });
            });
            document.querySelectorAll('.remove-item').forEach(button => {
                button.addEventListener('click', function() {
                    const key = this.getAttribute('data-key');
                    removeCartItem(key);
                });
            });
        }

        // استدعاء الدالة عند تحميل الصفحة أول مرة
        rebindMiniCartEvents();

        // عند تحديث الميني كارت عبر AJAX (مثلاً بعد إضافة منتج)
        document.addEventListener('miniCartRefreshed', function() {
            rebindMiniCartEvents();
        });

        // إذا كان هناك كود يقوم بتحديث الميني كارت عبر AJAX، أضف بعده:
        // document.dispatchEvent(new Event('miniCartRefreshed'));
    });
    </script>

    <?php
    // إعدادات الألوان من التخصيص
    $primary   = get_theme_mod('primary_color', '#6a82fb');
    $secondary = get_theme_mod('secondary_color', '#2dce89');
    $bg        = get_theme_mod('background_color_custom', '#f5f6fa');
    $text      = get_theme_mod('main_text_color', '#2c3e50');
    $btn_bg    = get_theme_mod('button_bg_color', '#6a82fb');
    $btn_text  = get_theme_mod('button_text_color', '#fff');
    $btn_pad   = get_theme_mod('button_padding', '12px 32px');
    $btn_rad   = get_theme_mod('button_radius', '25px');
    $header_grad1 = get_theme_mod('header_gradient_color_1', $primary);
    $header_grad2 = get_theme_mod('header_gradient_color_2', $secondary);
    $footer_bg = get_theme_mod('footer_bg_color', '#2c3e50');
    $body_bg_color = get_theme_mod('body_bg_color', '#f5f6fa');
    $header_bg_color = get_theme_mod('header_bg_color', '#6a82fb');
    $topbar_bg_color = get_theme_mod('topbar_bg_color', '#222');
    $body_grad_start = get_theme_mod('body_bg_gradient_start', '#f5f6fa');
    $body_grad_end = get_theme_mod('body_bg_gradient_end', '#e0e0e0');
    $header_grad_start = get_theme_mod('header_bg_gradient_start', '#6a82fb');
    $header_grad_end = get_theme_mod('header_bg_gradient_end', '#2dce89');
    $topbar_grad_start = get_theme_mod('topbar_bg_gradient_start', '#59ab6e');
    $topbar_grad_end = get_theme_mod('topbar_bg_gradient_end', '#4a8f5c');
    $logo_bg_color = get_theme_mod('logo_bg_color', '');
    ?>
    <?php if (!is_home() && !is_front_page()) : ?>
    <style>
    body {
        background: <?php echo esc_attr($body_bg_color); ?> !important;
        color: <?php echo esc_attr($text); ?> !important;
    }
    header, .navbar, #templatemo_nav_top {
        background: linear-gradient(135deg, <?php echo esc_attr($header_grad1); ?> 0%, <?php echo esc_attr($header_grad2); ?> 100%) !important;
        color: #fff !important;
    }
    .btn, .button, .btn-special, .woocommerce-mini-cart__buttons .button, .woocommerce ul.products li.product .button, .woocommerce-page ul.products li.product .button {
        background: <?php echo esc_attr($btn_bg); ?> !important;
        color: <?php echo esc_attr($btn_text); ?> !important;
        border-radius: <?php echo esc_attr($btn_rad); ?> !important;
        padding: <?php echo esc_attr($btn_pad); ?> !important;
        font-weight: 600;
        text-decoration: none !important;
        border: none !important;
        box-shadow: 0 2px 8px rgba(45, 206, 137, 0.08) !important;
        transition: all 0.3s;
    }
    .btn:hover, .button:hover, .btn-special:hover, .woocommerce-mini-cart__buttons .button:hover, .woocommerce ul.products li.product .button:hover, .woocommerce-page ul.products li.product .button:hover {
        background: <?php echo esc_attr($secondary); ?> !important;
        color: #fff !important;
        transform: translateY(-2px) scale(1.04);
    }
    a, a:visited, a:active, a:focus, a:hover {
        color: <?php echo esc_attr($primary); ?>;
        text-decoration: none !important;
        outline: none;
        box-shadow: none;
    }
    a:hover {
        color: <?php echo esc_attr($secondary); ?>;
    }
    footer, #tempaltemo_footer {
        background: <?php echo esc_attr($footer_bg); ?> !important;
        color: #fff !important;
    }
    </style>
    <?php endif; ?>
    <?php if (is_page('contact') || is_page('about')) : ?>
    <style>
        header, .navbar, #templatemo_nav_top {
            background: transparent !important;
            background-color: transparent !important;
            box-shadow: none !important;
            border: none !important;
        }
    </style>
    <?php endif; ?>
    <?php
    $gradient_start = get_theme_mod('gradient_start_color', '');
    $gradient_end = get_theme_mod('gradient_end_color', '');
    if (!empty($gradient_start) && !empty($gradient_end)) : ?>
    <style id="force-header-transparent">
        header, .navbar, #templatemo_nav_top {
            background: transparent !important;
            background-color: transparent !important;
            box-shadow: none !important;
            border: none !important;
        }
    </style>
    <?php endif; ?>
    <style id="custom-header-navbar-bg">
        header,
        .navbar,
        .main-navbar,
        .navbar-light,
        .navbar-expand-lg,
        .shadow {
            background: <?php echo esc_attr($header_bg_color); ?> !important;
            background-color: <?php echo esc_attr($header_bg_color); ?> !important;
            box-shadow: none !important;
            border: none !important;
        }
    </style>
    <style id="custom-theme-colors">
        body {
            background: <?php echo esc_attr($body_bg_color); ?> !important;
        }
        header, .navbar {
            background: <?php echo esc_attr($header_bg_color); ?> !important;
            background-color: <?php echo esc_attr($header_bg_color); ?> !important;
        }
        #templatemo_nav_top {
            background: <?php echo esc_attr($topbar_bg_color); ?> !important;
            background-color: <?php echo esc_attr($topbar_bg_color); ?> !important;
        }
    </style>
    <style id="custom-theme-gradients">
        body {
            background: linear-gradient(135deg, <?php echo esc_attr($body_grad_start); ?>, <?php echo esc_attr($body_grad_end); ?>) !important;
        }
        header, .navbar {
            background: linear-gradient(135deg, <?php echo esc_attr($header_grad_start); ?>, <?php echo esc_attr($header_grad_end); ?>) !important;
            background-color: unset !important;
        }
        #templatemo_nav_top {
            background: linear-gradient(135deg, <?php echo esc_attr($topbar_grad_start); ?>, <?php echo esc_attr($topbar_grad_end); ?>) !important;
            background-color: unset !important;
        }
    </style>
   
</body>
</html>