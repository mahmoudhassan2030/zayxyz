<?php
/**
 * The template for displaying all single posts
 *
 * @package ZayXYZ
 */

get_header(); ?>

<!-- Single Post Page Wrapper -->
<div class="container-fluid py-5 bg-light">
    <div class="container">
        <article id="post-<?php the_ID(); ?>" <?php post_class('single-article-pro card border-0 shadow-sm mb-5'); ?>>
            <!-- Post Header -->
            <header class="single-post-header p-4 mb-4">
                <div class="d-flex flex-wrap align-items-center justify-content-between mb-2">
                    <div class="d-flex flex-wrap align-items-center text-muted small">
                        <span class="me-3"><i class="fas fa-calendar-alt me-1"></i><?php echo get_the_date(); ?></span>
                        <span class="me-3"><i class="fas fa-user me-1"></i><?php the_author_posts_link(); ?></span>
                    </div>
                    <div>
                        <?php if (has_category()) : ?>
                            <span class="category-badge"> <?php echo get_the_category_list(', '); ?> </span>
                        <?php endif; ?>
                    </div>
                </div>
                <h1 class="h1 fw-bold mb-0"><?php the_title(); ?></h1>
            </header>
            <!-- Featured Image -->
            <?php if (has_post_thumbnail()) : ?>
                <div class="single-post-featured mb-4">
                    <?php the_post_thumbnail('large', ['class' => 'img-fluid rounded w-100']); ?>
                </div>
            <?php endif; ?>
            <!-- Post Content -->
            <div class="single-post-content entry-content px-3 px-md-4 pb-4">
                <?php
                the_content();
                wp_link_pages([
                    'before' => '<div class="page-links bg-light p-2 mt-3 rounded"><strong>' . esc_html__('Pages:', 'zayxyz') . '</strong> ',
                    'after'  => '</div>',
                ]);
                ?>
            </div>
            <!-- Post Footer -->
            <footer class="mt-5 pt-4 border-top px-3 px-md-4 pb-4">
                <div class="row gx-4">
                    <!-- Author Box -->
                    <div class="col-md-6 mb-4 mb-md-0">
                        <?php $author_bio = get_the_author_meta('description');
                        if ($author_bio) : ?>
                            <div class="author-box d-flex align-items-center">
                                <div class="me-3">
                                    <?php echo get_avatar(get_the_author_meta('ID'), 70, '', '', ['class' => 'rounded-circle']); ?>
                                </div>
                                <div>
                                    <h5 class="mb-1 fw-bold"><?php the_author(); ?></h5>
                                    <p class="text-muted small mb-0"><?php echo esc_html($author_bio); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <!-- Navigation -->
                    <div class="col-md-6">
                        <div class="post-navigation bg-dark text-white rounded p-3">
                            <h6 class="fw-bold mb-2"> <?php esc_html_e('Post Navigation', 'zayxyz'); ?> </h6>
                            <div class="d-flex justify-content-between small">
                                <div class="nav-previous text-start">
                                    <?php previous_post_link('%link', '<i class="fas fa-chevron-left me-1"></i>%title'); ?>
                                </div>
                                <div class="nav-next text-end">
                                    <?php next_post_link('%link', '%title<i class="fas fa-chevron-right ms-1"></i>'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </article>
        <!-- Comments -->
        <?php if (comments_open() || get_comments_number()) :
            comments_template();
        endif; ?>
    </div>
</div>

<?php get_footer(); ?>

