# توحيد أزرار "أضف إلى السلة" و"شراء الآن" - ZayXYZ Theme

## نظرة عامة
تم توحيد طريقة عمل أزرار "أضف إلى السلة" و"شراء الآن" في جميع صفحات القالب لضمان تجربة مستخدم متسقة ومتناسقة.

## التحديثات المنجزة

### 1. قوالب WooCommerce المحدثة

#### `woocommerce/loop/add-to-cart.php` (جديد)
- قالب موحد لأزرار حلقة المنتجات
- يدعم جميع أنواع المنتجات (بسيط، متغير، خارجي، مجمع)
- يستخدم الكلاسات الموحدة: `add-to-cart-btn`, `buy-now-btn`

#### `woocommerce/single-product/add-to-cart/simple.php`
- تم تحديث الأزرار لتستخدم الكلاسات الموحدة
- إضافة أيقونات Font Awesome
- تحسين المظهر والتفاعل

#### `woocommerce/single-product/add-to-cart/variable.php`
- تم تحديث الأزرار لتستخدم الكلاسات الموحدة
- إضافة أيقونات Font Awesome
- تحسين المظهر والتفاعل

#### `woocommerce/loop/featured-products.php` (جديد)
- قالب للمنتجات المميزة
- يستخدم نفس القوالب الموحدة

#### `woocommerce/loop/new-products.php` (جديد)
- قالب للمنتجات الجديدة
- يستخدم نفس القوالب الموحدة

### 2. ملفات JavaScript المحدثة

#### `assets/js/main-functions.js`
- توحيد التعامل مع جميع الأزرار
- إضافة أحداث موحدة لـ `add-to-cart-btn` و `buy-now-btn`
- دعم AJAX لإضافة المنتجات إلى السلة
- دعم زر "شراء الآن" مع التوجيه للدفع
- CSS موحد لجميع الأزرار

#### `assets/js/main-product.js`
- تحديث التعامل مع أزرار صفحة المنتج
- إزالة التعارضات مع الأزرار الموحدة
- تحسين تجربة المستخدم

### 3. ملف functions.php المحدث

#### دوال AJAX الجديدة
- `zayxyz_ajax_add_to_cart()` - معالجة موحدة لإضافة المنتجات
- دعم زر "شراء الآن" مع إفراغ السلة
- تحسين الأمان والتحقق من صحة البيانات

#### دوال العرض الجديدة
- `zayxyz_display_featured_products()` - عرض المنتجات المميزة
- `zayxyz_display_new_products()` - عرض المنتجات الجديدة

### 4. الكلاسات الموحدة

#### أزرار "أضف إلى السلة"
```html
<button class="add-to-cart-btn" data-product_id="123" data-product_type="simple">
    <i class="fas fa-shopping-cart me-2"></i>
    Add to Cart
</button>
```

#### أزرار "شراء الآن"
```html
<button class="buy-now-btn" data-product_id="123" data-product_type="simple">
    <i class="fas fa-bolt me-2"></i>
    Buy Now
</button>
```

#### أزرار المنتجات المتغيرة
```html
<a href="/product-url" class="select-options-btn">
    <i class="fas fa-cog me-2"></i>
    Select Options
</a>
```

### 5. الميزات الجديدة

#### تجربة مستخدم محسنة
- تأثيرات بصرية عند النقر (loading state)
- رسائل تأكيد واضحة
- تحديث فوري لعدد العناصر في السلة
- منع النقر المتكرر

#### دعم متعدد الأجهزة
- تصميم متجاوب للأزرار
- تحسين العرض على الأجهزة المحمولة
- أحجام أزرار مناسبة لكل سياق

#### أمان محسن
- التحقق من nonce
- تنظيف البيانات المدخلة
- معالجة الأخطاء

## كيفية الاستخدام

### في القوالب المخصصة
```php
// للمنتجات البسيطة
<button type="button" 
        class="add-to-cart-btn" 
        data-product_id="<?php echo esc_attr($product->get_id()); ?>"
        data-product_type="simple">
    <i class="fas fa-shopping-cart me-2"></i>
    <?php echo esc_html($product->single_add_to_cart_text()); ?>
</button>

// للمنتجات المتغيرة
<a href="<?php echo esc_url($product->get_permalink()); ?>" 
   class="select-options-btn">
    <i class="fas fa-cog me-2"></i>
    <?php esc_html_e('Select Options', 'zayxyz'); ?>
</a>
```

### في JavaScript المخصص
```javascript
// إضافة منتج إلى السلة
$(document).on('click', '.add-to-cart-btn', function(e) {
    e.preventDefault();
    // الكود موجود في main-functions.js
});

// شراء الآن
$(document).on('click', '.buy-now-btn', function(e) {
    e.preventDefault();
    // الكود موجود في main-functions.js
});
```

## الصفحات المدعومة

1. **صفحة المنتج الفردي** - أزرار كاملة مع خيارات
2. **أرشيف المنتجات** - أزرار سريعة
3. **المنتجات ذات الصلة** - أزرار موحدة
4. **المنتجات المميزة** - أزرار موحدة
5. **المنتجات الجديدة** - أزرار موحدة
6. **المعاينة السريعة** - أزرار موحدة
7. **السلايدرز** - أزرار موحدة

## التوافق

- ✅ WooCommerce 5.0+
- ✅ WordPress 5.8+
- ✅ جميع أنواع المنتجات
- ✅ جميع الأجهزة والمتصفحات
- ✅ AJAX متوافق
- ✅ SEO friendly

## الدعم

لأي استفسارات أو مشاكل، يرجى التواصل مع فريق التطوير.

---
**تاريخ التحديث:** 2024  
**الإصدار:** 1.0  
**المطور:** ZayXYZ Theme Team 