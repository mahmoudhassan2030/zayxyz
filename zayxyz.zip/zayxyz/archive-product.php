<?php
/**
 * The Template for displaying product archives, including the main shop page
 */
if (is_search()) {
    // إذا كان البحث، استخدم قالب index.php لعرض جميع النتائج
    include get_template_directory() . '/index.php';
    return;
}
get_header(); ?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar - Enhanced with modern design -->
        <aside class="col-lg-3 mb-4 mb-lg-0" aria-label="<?php esc_attr_e('Product Filters', 'codevers2e'); ?>">
            <!-- Mobile Filter Toggle -->
            <button class="btn btn-primary w-100 d-lg-none mb-4" id="sidebarToggle">
                <i class="fas fa-filter me-2"></i>
                <?php esc_html_e('Show Filters', 'codevers2e'); ?>
            </button>

            <div class="sidebar-content card border-0 shadow-sm rounded-lg overflow-hidden animate__animated animate__fadeInLeft d-lg-block" id="sidebarContent">
                <!-- Categories Section -->
                <div class="category-section">
                    <div class="card-header bg-primary text-white py-3">
                        <h4 class="mb-0 h5"><?php esc_html_e('Product Categories', 'codevers2e'); ?></h4>
                    </div>
                    <div class="card-body p-0">
                        <?php
                        // دالة لعرض التصنيفات بشكل شجري متداخل
                        function zayxyz_display_category_tree($parent = 0, $level = 0) {
                            $args = array(
                                'taxonomy'     => 'product_cat',
                                'hide_empty'   => true,
                                'parent'       => $parent,
                                'orderby'      => 'name',
                                'order'        => 'ASC',
                            );
                            $categories = get_terms($args);
                            if (!empty($categories) && !is_wp_error($categories)) {
                                echo '<ul class="category-tree level-' . $level . '">';
                                foreach ($categories as $category) {
                                    $category_link = get_term_link($category);
                                    $is_current = is_tax('product_cat', $category->term_id);
                                    $thumbnail_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                                    $image = $thumbnail_id ? wp_get_attachment_image_url($thumbnail_id, 'thumbnail') : wc_placeholder_img_src();
                                    echo '<li class="category-tree-item' . ($is_current ? ' active' : '') . '">';
                                    echo '<a href="' . esc_url($category_link) . '" class="d-flex align-items-center ' . ($is_current ? 'text-primary fw-bold' : 'text-dark') . '"' . ($is_current ? ' aria-current="true"' : '') . '>';
                                    echo '<img src="' . esc_url($image) . '" alt="' . esc_attr($category->name) . '" class="category-thumb me-2 rounded" width="32" height="32">';
                                    echo '<span class="category-name flex-grow-1">' . esc_html($category->name) . '</span>';
                                    echo '<span class="badge bg-light text-dark rounded-pill ms-2">' . esc_html($category->count) . '</span>';
                                    echo '</a>';
                                    // عرض التصنيفات الفرعية بشكل متداخل
                                    zayxyz_display_category_tree($category->term_id, $level + 1);
                                    echo '</li>';
                                }
                                echo '</ul>';
                            }
                        }
                        // عرض الشجرة من التصنيفات الرئيسية
                        zayxyz_display_category_tree();
                        ?>
                    </div>
                </div>
                
                <!-- Price Filter -->
                <div class="price-filter mt-4">
                    <div class="card-header bg-primary text-white py-3">
                        <h4 class="mb-0 h5"><?php esc_html_e('Filter by Price', 'codevers2e'); ?></h4>
                    </div>
                    <div class="card-body p-3">
                        <?php
                        if (function_exists('the_widget')) {
                            the_widget('WC_Widget_Price_Filter', array(), array('before_widget' => '<div class="widget">', 'after_widget' => '</div>'));
                        }
                        ?>
                    </div>
                </div>
                
                <!-- Product Search -->
                <div class="product-search mt-4">
                    <div class="card-header bg-primary text-white py-3">
                        <h4 class="mb-0 h5"><?php esc_html_e('Search Products', 'codevers2e'); ?></h4>
                    </div>
                    <div class="card-body p-3">
                        <form role="search" method="get" class="woocommerce-product-search" action="<?php echo esc_url(home_url('/')); ?>">
                            <div class="input-group">
                                <input type="search" class="form-control" placeholder="<?php esc_attr_e('Search products...', 'codevers2e'); ?>" 
                                       value="<?php echo get_search_query(); ?>" name="s" />
                                <button type="submit" class="btn btn-primary" aria-label="<?php esc_attr_e('Search', 'codevers2e'); ?>">
                                    <i class="fas fa-search"></i>
                                </button>
                                <input type="hidden" name="post_type" value="product" />
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Active Filters -->
                <?php if (is_filtered()): ?>
                    <div class="active-filters mt-4">
                        <div class="card-header bg-primary text-white py-3">
                            <h4 class="mb-0 h5"><?php esc_html_e('Active Filters', 'codevers2e'); ?></h4>
                        </div>
                        <div class="card-body p-3">
                            <div class="active-filters-list">
                                <?php wc_get_template('loop/active-filters.php'); ?>
                            </div>
                            <a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>" class="btn btn-sm btn-outline-danger mt-3 w-100">
                                <?php esc_html_e('Clear all filters', 'codevers2e'); ?>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </aside>

        <!-- Main Products Grid -->
        <section class="col-lg-9">
            <!-- Category Banner -->
            <?php if (is_product_category()): 
                $current_cat = get_queried_object();
                $banner_id = get_term_meta($current_cat->term_id, 'banner_id', true);
                $banner = $banner_id ? wp_get_attachment_image_url($banner_id, 'full') : '';
                $description = term_description();
            ?>
                <div class="category-banner mb-5 rounded-3 overflow-hidden shadow-sm position-relative">
                    <?php if ($banner): ?>
                        <img src="<?php echo esc_url($banner); ?>" alt="<?php echo esc_attr($current_cat->name); ?>" 
                             class="w-100" style="height: 250px; object-fit: cover;">
                    <?php endif; ?>
                    
                    <div class="banner-content position-absolute bottom-0 start-0 w-100 p-4 text-white bg-gradient-dark">
                        <h1 class="display-5 mb-2"><?php echo esc_html($current_cat->name); ?></h1>
                        <?php if ($description): ?>
                            <div class="category-description"><?php echo wp_kses_post($description); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <!-- Shop Title -->
                <!-- <div class="shop-title text-center mb-5">
                    <h1 class="display-4 fw-bold text-primary mb-3"><?php woocommerce_page_title(); ?></h1>
                    <p class="lead text-muted"><?php esc_html_e('Discover our curated collection of premium products', 'codevers2e'); ?></p>
                </div> -->
            <?php endif; ?>
            
            <!-- Sorting and Results -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4 bg-light p-3 rounded-3 shadow-sm">
                <div class="result-count text-muted mb-2 mb-md-0">
                    <?php woocommerce_result_count(); ?>
                </div>
                <div class="catalog-ordering">
                    <form method="get" class="woocommerce-ordering">
                        <?php woocommerce_catalog_ordering(); ?>
                    </form>
                </div>
            </div>
            
            <?php
            // جلب إعدادات العرض من customizer
            $display_mode = get_theme_mod('shop_product_display_mode', 'grouped');
            $products_per_cat = absint(get_theme_mod('shop_products_per_category', 9));
            $custom_cats = get_theme_mod('shop_custom_category_selection', array());
            if (!is_array($custom_cats)) $custom_cats = array();

            if ($display_mode === 'random') {
                // منتجات عشوائية
                $args = array(
                    'post_type' => 'product',
                    'posts_per_page' => $products_per_cat,
                    'orderby' => 'rand',
                );
                $rand_query = new WP_Query($args);
                if ($rand_query->have_posts()) {
                    echo '<div class="shop-category-group mb-5">';
                    echo '<h2 class="shop-category-title mb-4 px-3 py-2 bg-light rounded-3 fw-bold">' . esc_html__('Random Products', 'zayxyz') . '</h2>';
                    echo '<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">';
                    while ($rand_query->have_posts()) : $rand_query->the_post();
                        echo '<div class="col">';
                        wc_get_template_part('content', 'product');
                        echo '</div>';
                    endwhile;
                    echo '</div></div>';
                } else {
                    echo '<div class="alert alert-info">' . esc_html__('No products found.', 'zayxyz') . '</div>';
                }
                wp_reset_postdata();
            } elseif ($display_mode === 'featured') {
                // منتجات مميزة فقط
                $args = array(
                    'post_type' => 'product',
                    'posts_per_page' => $products_per_cat,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'product_visibility',
                            'field'    => 'name',
                            'terms'    => 'featured',
                            'operator' => 'IN',
                        ),
                    ),
                );
                $feat_query = new WP_Query($args);
                if ($feat_query->have_posts()) {
                    echo '<div class="shop-category-group mb-5">';
                    echo '<h2 class="shop-category-title mb-4 px-3 py-2 bg-light rounded-3 fw-bold">' . esc_html__('Featured Products', 'zayxyz') . '</h2>';
                    echo '<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">';
                    while ($feat_query->have_posts()) : $feat_query->the_post();
                        echo '<div class="col">';
                        wc_get_template_part('content', 'product');
                        echo '</div>';
                    endwhile;
                    echo '</div></div>';
                } else {
                    echo '<div class="alert alert-info">' . esc_html__('No featured products found.', 'zayxyz') . '</div>';
                }
                wp_reset_postdata();
            } elseif ($display_mode === 'customcat' && !empty($custom_cats)) {
                // حسب تصنيفات مخصصة
                foreach ($custom_cats as $cat_id) {
                    $cat = get_term($cat_id, 'product_cat');
                    if (!$cat || is_wp_error($cat)) continue;
                    $args = array(
                        'post_type' => 'product',
                        'posts_per_page' => $products_per_cat,
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'product_cat',
                                'field'    => 'term_id',
                                'terms'    => $cat_id,
                            ),
                        ),
                    );
                    $cat_query = new WP_Query($args);
                    if ($cat_query->have_posts()) {
                        echo '<div class="shop-category-group mb-5">';
                        echo '<h2 class="shop-category-title mb-4 px-3 py-2 bg-light rounded-3 fw-bold">' . esc_html($cat->name) . '</h2>';
                        echo '<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">';
                        while ($cat_query->have_posts()) : $cat_query->the_post();
                            echo '<div class="col">';
                            wc_get_template_part('content', 'product');
                            echo '</div>';
                        endwhile;
                        echo '</div></div>';
                    }
                    wp_reset_postdata();
                }
            } else {
                // Grouped by Category (افتراضي)
                $main_cats = get_terms(array(
                    'taxonomy' => 'product_cat',
                    'hide_empty' => true,
                    'parent' => 0,
                    'orderby' => 'name',
                    'order' => 'ASC',
                ));
                if (!empty($main_cats) && !is_wp_error($main_cats)) :
                    foreach ($main_cats as $cat) :
                        $args = array(
                            'post_type' => 'product',
                            'posts_per_page' => $products_per_cat,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'product_cat',
                                    'field'    => 'term_id',
                                    'terms'    => $cat->term_id,
                                ),
                            ),
                        );
                        $cat_query = new WP_Query($args);
                        if ($cat_query->have_posts()) {
                            echo '<div class="shop-category-group mb-5">';
                            echo '<h2 class="shop-category-title mb-4 px-3 py-2 bg-light rounded-3 fw-bold">' . esc_html($cat->name) . '</h2>';
                            echo '<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">';
                            while ($cat_query->have_posts()) : $cat_query->the_post();
                                echo '<div class="col">';
                                wc_get_template_part('content', 'product');
                                echo '</div>';
                            endwhile;
                            echo '</div></div>';
                        }
                        wp_reset_postdata();
                    endforeach;
                else:
                    echo '<div class="alert alert-info">' . esc_html__('No categories or products found.', 'zayxyz') . '</div>';
                endif;
            }
            ?>
        </section>
    </div>
</div>

<!-- Quick View Modal -->
<div class="modal fade" id="quickViewModal" tabindex="-1" aria-labelledby="quickViewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title" id="quickViewModalLabel"><?php esc_html_e('Product Quick View', 'codevers2e'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Content will be loaded here via AJAX -->
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
