<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ZayXYZ
 */

get_header(); ?>

<!-- Search Results Page Wrapper -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-8 mx-auto search-results-col">
                <!-- Search Results Header -->
                <header class="page-header mb-4">
                    <h1 class="page-title">
                        <?php
                        printf(
                            /* translators: %s: search query. */
                            esc_html__('Search Results for: %s', 'zayxyz'),
                            '<span class="text-primary">' . get_search_query() . '</span>'
                        );
                        ?>
                    </h1>
                </header>

                <?php if (have_posts()) : ?>
                    <div class="search-results">
                        <?php
                        /* Start the Loop */
                        while (have_posts()) :
                            the_post();
                            ?>
                            <article id="post-<?php the_ID(); ?>" <?php post_class('search-result-item mb-4 p-4 border rounded'); ?>>
                                <div class="row">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <div class="col-md-3">
                                            <div class="search-result-thumbnail">
                                                <a href="<?php the_permalink(); ?>">
                                                    <?php the_post_thumbnail('medium', array('class' => 'img-fluid rounded')); ?>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-md-9">
                                    <?php else : ?>
                                        <div class="col-12">
                                    <?php endif; ?>
                                    
                                    <header class="entry-header">
                                        <h2 class="entry-title">
                                            <a href="<?php the_permalink(); ?>" class="text-decoration-none">
                                                <?php the_title(); ?>
                                            </a>
                                        </h2>
                                        
                                        <div class="entry-meta text-muted small mb-2">
                                            <span class="posted-on">
                                                <i class="fas fa-calendar-alt me-1"></i>
                                                <?php echo get_the_date(); ?>
                                            </span>
                                            <span class="byline ms-3">
                                                <i class="fas fa-user me-1"></i>
                                                <?php the_author(); ?>
                                            </span>
                                            <?php if (has_category()) : ?>
                                                <span class="cat-links ms-3">
                                                    <i class="fas fa-folder me-1"></i>
                                                    <?php the_category(', '); ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </header>

                                    <div class="entry-summary">
                                        <?php the_excerpt(); ?>
                                    </div>

                                    <footer class="entry-footer">
                                        <a href="<?php the_permalink(); ?>" class="btn btn-primary btn-sm">
                                            <?php esc_html_e('Read More', 'zayxyz'); ?>
                                            <i class="fas fa-arrow-right ms-1"></i>
                                        </a>
                                    </footer>
                                </div>
                            </article>
                            <?php
                        endwhile;
                        ?>
                    </div>

                    <!-- Pagination -->
                    <nav class="pagination-wrapper" aria-label="<?php esc_attr_e('Search results navigation', 'zayxyz'); ?>">
                        <?php
                        the_posts_pagination(array(
                            'mid_size'  => 2,
                            'prev_text' => '<i class="fas fa-chevron-left"></i> ' . __('Previous', 'zayxyz'),
                            'next_text' => __('Next', 'zayxyz') . ' <i class="fas fa-chevron-right"></i>',
                            'class'     => 'pagination justify-content-center',
                        ));
                        ?>
                    </nav>

                <?php else : ?>
                    <div class="no-results text-center py-5">
                        <i class="fas fa-search fa-3x text-muted mb-3"></i>
                        <h2><?php esc_html_e('No results found', 'zayxyz'); ?></h2>
                        <p class="text-muted">
                            <?php esc_html_e('Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'zayxyz'); ?>
                        </p>
                        
                        <div class="search-form-wrapper mt-4">
                            <?php get_search_form(); ?>
                        </div>
                        
                        <div class="suggestions mt-4">
                            <h4><?php esc_html_e('Suggestions:', 'zayxyz'); ?></h4>
                            <ul class="list-unstyled">
                                <li><i class="fas fa-check text-success me-2"></i><?php esc_html_e('Make sure all words are spelled correctly', 'zayxyz'); ?></li>
                                <li><i class="fas fa-check text-success me-2"></i><?php esc_html_e('Try different keywords', 'zayxyz'); ?></li>
                                <li><i class="fas fa-check text-success me-2"></i><?php esc_html_e('Try more general keywords', 'zayxyz'); ?></li>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
get_footer(); 