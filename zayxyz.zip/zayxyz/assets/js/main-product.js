/*
 * ===================================================================
 *   Main Product Page JavaScript - ZayXYZ Theme
 *   تاريخ الإنشاء: 2024
 * ===================================================================
 */

jQuery(document).ready(function($) {
    
    // ===================================
    //   Product Gallery Functionality
    // ===================================
    
    function initProductGallery() {
        const $mainImage = $('#luxury-main-product-image');
        const $thumbnails = $('.luxury-thumbnail');
        
        if ($mainImage.length && $thumbnails.length) {
            // تبديل الصورة الرئيسية عند النقر على الصور المصغرة
            $thumbnails.on('click', function() {
                const $thumbnail = $(this);
                const newImageSrc = $thumbnail.data('image');
                
                if (newImageSrc) {
                    $thumbnails.removeClass('active');
                    $thumbnail.addClass('active');
                    $mainImage.attr('src', newImageSrc);
                    $mainImage.removeClass('zoomed');
                }
            });
            
            // تكبير الصورة
            $('.luxury-gallery-btn.zoom-btn').on('click', function(e) {
                e.preventDefault();
                $mainImage.toggleClass('zoomed');
            });
            
            // فتح الصورة في lightbox
            $('.luxury-gallery-btn.gallery-btn').on('click', function(e) {
                e.preventDefault();
                const currentSrc = $mainImage.attr('src');
                showLightbox(currentSrc);
            });
        }
        
        function showLightbox(imageSrc) {
            const $modal = $(`
                <div class="image-lightbox">
                    <div class="lightbox-content">
                        <button class="lightbox-close">&times;</button>
                        <img src="${imageSrc}" alt="Product Image">
                    </div>
                </div>
            `);
            
            $('body').append($modal);
            $modal.fadeIn(300);
            
            // إغلاق lightbox
            $modal.find('.lightbox-close, .lightbox-content').on('click', function(e) {
                if (e.target === this) {
                    $modal.fadeOut(300, function() {
                        $modal.remove();
                    });
                }
            });
            
            // إغلاق بـ ESC
            $(document).on('keydown.lightbox', function(e) {
                if (e.key === 'Escape') {
                    $modal.fadeOut(300, function() {
                        $modal.remove();
                    });
                    $(document).off('keydown.lightbox');
                }
            });
        }
    }
    
    // ===================================
    //   Single Product Page Add to Cart
    // ===================================
    
    function initSingleProductAddToCart() {
        // منع الإرسال المزدوج
        let isSubmitting = false;
        
        // معالجة النموذج العادي (إضافة إلى السلة)
        $('form.cart').on('submit', function(e) {
            if (isSubmitting) {
                e.preventDefault();
                return false;
            }
            
            const $form = $(this);
            const $submitBtn = $form.find('.single_add_to_cart_button');
            
            // التحقق من المنتجات المتغيرة
            if ($form.hasClass('variations_form')) {
                const $variationId = $form.find('input[name="variation_id"]');
                if (!$variationId.val() || $variationId.val() === '0') {
                    e.preventDefault();
                    showNotice('Please select product options before adding to cart.', 'error');
                    return false;
                }
            }
            
            isSubmitting = true;
            $submitBtn.addClass('loading').prop('disabled', true);
            
            // إعادة تفعيل الزر بعد 3 ثوان
            setTimeout(function() {
                isSubmitting = false;
                $submitBtn.removeClass('loading').prop('disabled', false);
            }, 3000);
        });
        
        // معالجة زر "شراء الآن" في صفحة المنتج
        $(document).on('click', '.buy-now-button', function(e) {
            e.preventDefault();
            
            if (isSubmitting) return false;
            
            const $btn = $(this);
            const $form = $btn.closest('form.cart');
            
            if (!$form.length) return false;
            
            // التحقق من المنتجات المتغيرة
            if ($form.hasClass('variations_form')) {
                const $variationId = $form.find('input[name="variation_id"]');
                if (!$variationId.val() || $variationId.val() === '0') {
                    showNotice('Please select product options before buying now.', 'error');
                    return false;
                }
            }
            
            isSubmitting = true;
            $btn.addClass('loading').prop('disabled', true);
            
            // إضافة حقل مخفي لزر "شراء الآن"
            let $buyNowInput = $form.find('input[name="buy_now"]');
            if (!$buyNowInput.length) {
                $buyNowInput = $('<input type="hidden" name="buy_now" value="1">');
                $form.append($buyNowInput);
            } else {
                $buyNowInput.val('1');
            }
            
            // إرسال النموذج
            $form.submit();
            
            // إعادة تفعيل الزر بعد 3 ثوان
            setTimeout(function() {
                isSubmitting = false;
                $btn.removeClass('loading').prop('disabled', false);
                $buyNowInput.remove();
            }, 3000);
        });
    }
    
    // ===================================
    //   Variation Functionality
    // ===================================
    
    function initVariations() {
        const $form = $('.variations_form.cart');
        
        if ($form.length) {
            const $mainImage = $('#luxury-main-product-image');
            
            // تغيير صورة المنتج عند اختيار متغير
            $form.on('show_variation found_variation', function(event, variation) {
                if (variation && variation.image && variation.image.src && $mainImage.length) {
                    $mainImage.addClass('changing');
                    setTimeout(function() {
                        $mainImage.attr('src', variation.image.src);
                        if (variation.image.srcset) {
                            $mainImage.attr('srcset', variation.image.srcset);
                        }
                        if (variation.image.sizes) {
                            $mainImage.attr('sizes', variation.image.sizes);
                        }
                        $mainImage.removeClass('changing');
                    }, 200);
                }
            });
            
            // إعادة الصورة الافتراضية عند إخفاء المتغير
            $form.on('hide_variation', function() {
                if ($mainImage.length) {
                    const defaultSrc = $mainImage.data('default-src');
                    if (defaultSrc) {
                        $mainImage.addClass('changing');
                        setTimeout(function() {
                            $mainImage.attr('src', defaultSrc);
                            $mainImage.removeClass('changing');
                        }, 200);
                    }
                }
            });
            
            // تحديث أزرار المتغيرات
            $form.on('found_variation', function(event, variation) {
                updateVariationButtons(variation);
            });
            
            $form.on('reset_image', function() {
                resetVariationButtons();
            });
        }
    }
    
    function updateVariationButtons(variation) {
        $('.zayxyz-variation-buttons').each(function() {
            const $group = $(this);
            const attributeName = $group.data('attribute_name');
            const attributeValue = variation.attributes[attributeName];
            
            if (attributeValue) {
                $group.find('.zayxyz-variation-btn').removeClass('active');
                $group.find(`[data-value="${attributeValue}"]`).addClass('active');
            }
        });
    }
    
    function resetVariationButtons() {
        $('.zayxyz-variation-btn').removeClass('active');
    }
    
    // ===================================
    //   Quantity Controls
    // ===================================
    
    function initQuantityControls() {
        // أزرار زيادة/تقليل الكمية
        $(document).on('click', '.quantity-btn', function() {
            const $btn = $(this);
            const $input = $btn.siblings('input[type="number"]');
            const currentValue = parseInt($input.val()) || 1;
            const maxValue = parseInt($input.attr('max')) || 999;
            const minValue = parseInt($input.attr('min')) || 1;
            
            if ($btn.hasClass('quantity-plus')) {
                if (currentValue < maxValue) {
                    $input.val(currentValue + 1).trigger('change');
                }
            } else if ($btn.hasClass('quantity-minus')) {
                if (currentValue > minValue) {
                    $input.val(currentValue - 1).trigger('change');
                }
            }
        });
        
        // التحقق من الكمية المدخلة
        $(document).on('input', 'input[type="number"]', function() {
            const $input = $(this);
            const value = parseInt($input.val()) || 1;
            const maxValue = parseInt($input.attr('max')) || 999;
            const minValue = parseInt($input.attr('min')) || 1;
            
            if (value < minValue) {
                $input.val(minValue);
            } else if (value > maxValue) {
                $input.val(maxValue);
            }
        });
    }
    
    // ===================================
    //   Product Tabs
    // ===================================
    
    function initProductTabs() {
        const $tabs = $('.product-tabs-header .nav-link');
        
        if ($tabs.length) {
            $tabs.on('click', function(e) {
                e.preventDefault();
                
                const $tab = $(this);
                const target = $tab.attr('data-bs-target') || $tab.attr('href');
                
                if (!target) return;
                
                // إزالة التفعيل من جميع التبويبات
                $tabs.removeClass('active').attr('aria-selected', 'false');
                $('.tab-pane').removeClass('show active');
                
                // تفعيل التبويب المحدد
                $tab.addClass('active').attr('aria-selected', 'true');
                $(target).addClass('show active');
            });
        }
    }
    
    // ===================================
    //   Utility Functions
    // ===================================
    
    function showNotice(message, type = 'success') {
        const noticeClass = type === 'error' ? 'woocommerce-error' : 
                           type === 'info' ? 'woocommerce-info' : 'woocommerce-message';
        
        const $notice = $(`
            <div class="${noticeClass} notice" role="alert">
                <div class="notice-content">${message}</div>
                <button class="notice-close">&times;</button>
            </div>
        `);
        
        $('.woocommerce-notices-wrapper').append($notice);
        $notice.fadeIn(300);
        
        // إغلاق الإشعار
        $notice.find('.notice-close').on('click', function() {
            $notice.fadeOut(300, function() {
                $(this).remove();
            });
        });
        
        // إغلاق تلقائي بعد 5 ثوان
        setTimeout(function() {
            $notice.fadeOut(300, function() {
                $(this).remove();
            }, 5000);
        });
    }
    
    // ===================================
    //   Initialize Everything
    // ===================================
    
    function init() {
        initProductGallery();
        initSingleProductAddToCart();
        initVariations();
        initQuantityControls();
        initProductTabs();
        
        console.log('Product page initialized successfully');
    }
    
    // تشغيل التهيئة
    init();
});

// ===================================
//   Dynamic CSS
// ===================================

const productPageCSS = `
    .single_add_to_cart_button.loading,
    .buy-now-button.loading {
        position: relative !important;
        pointer-events: none !important;
        opacity: 0.7 !important;
    }
    
    .single_add_to_cart_button.loading::after,
    .buy-now-button.loading::after {
        content: '' !important;
        position: absolute !important;
        top: 50% !important;
        left: 50% !important;
        width: 20px !important;
        height: 20px !important;
        margin: -10px 0 0 -10px !important;
        border: 2px solid transparent !important;
        border-top: 2px solid currentColor !important;
        border-radius: 50% !important;
        animation: spin 1s linear infinite !important;
    }
    
    .luxury-main-product-image.changing {
        opacity: 0.7;
        transition: opacity 0.2s ease;
    }
    
    .zayxyz-variation-btn {
        padding: 8px 16px !important;
        margin: 2px !important;
        border: 1px solid #ddd !important;
        background: white !important;
        cursor: pointer !important;
        border-radius: 4px !important;
        transition: all 0.3s ease !important;
        font-size: 14px !important;
    }
    
    .zayxyz-variation-btn:hover {
        background: #f8f9fa !important;
        border-color: #007bff !important;
    }
    
    .zayxyz-variation-btn.active {
        background: #007bff !important;
        color: white !important;
        border-color: #007bff !important;
    }
    
    .quantity {
        display: flex !important;
        align-items: center !important;
        border: 1px solid #ddd !important;
        border-radius: 4px !important;
        overflow: hidden !important;
    }
    
    .quantity-btn {
        border: none !important;
        background: #f8f9fa !important;
        width: 30px !important;
        height: 40px !important;
        cursor: pointer !important;
        font-size: 16px !important;
        font-weight: bold !important;
        transition: background-color 0.3s ease !important;
    }
    
    .quantity-btn:hover {
        background: #e9ecef !important;
    }
    
    .quantity input[type="number"] {
        border: none !important;
        text-align: center !important;
        width: 60px !important;
        height: 40px !important;
        padding: 0 !important;
        margin: 0 !important;
    }
    
    .quantity input[type="number"]:focus {
        outline: none !important;
        box-shadow: none !important;
    }
    
    .image-lightbox {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        width: 100% !important;
        height: 100% !important;
        background: rgba(0,0,0,0.9) !important;
        z-index: 9999 !important;
        display: none !important;
    }
    
    .lightbox-content {
        position: absolute !important;
        top: 50% !important;
        left: 50% !important;
        transform: translate(-50%, -50%) !important;
        text-align: center !important;
    }
    
    .lightbox-content img {
        max-width: 90% !important;
        max-height: 90% !important;
        border-radius: 8px !important;
    }
    
    .lightbox-close {
        position: absolute !important;
        top: 20px !important;
        right: 20px !important;
        background: none !important;
        border: none !important;
        color: white !important;
        font-size: 30px !important;
        cursor: pointer !important;
        z-index: 1 !important;
    }
    
    .luxury-main-product-image.zoomed {
        transform: scale(1.5) !important;
        cursor: zoom-out !important;
    }
    
    .notice {
        padding: 15px 20px !important;
        margin: 10px 0 !important;
        border-radius: 4px !important;
        position: relative !important;
        animation: slideInRight 0.3s ease !important;
    }
    
    .notice-close {
        position: absolute !important;
        top: 10px !important;
        right: 10px !important;
        background: none !important;
        border: none !important;
        font-size: 20px !important;
        cursor: pointer !important;
        color: inherit !important;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .luxury-add-to-cart-flex {
        display: flex !important;
        flex-direction: column !important;
        gap: 15px !important;
        margin: 20px 0 !important;
    }
    
    .luxury-add-to-cart-buttons {
        display: flex !important;
        gap: 10px !important;
        flex-wrap: wrap !important;
    }
    
    .luxury-add-to-cart-buttons .button {
        flex: 1 !important;
        min-width: 120px !important;
        padding: 12px 20px !important;
        border-radius: 6px !important;
        font-weight: 600 !important;
        text-align: center !important;
        transition: all 0.3s ease !important;
    }
    
    .buy-now-button {
        background: #28a745 !important;
        color: white !important;
        border: 2px solid #28a745 !important;
    }
    
    .buy-now-button:hover {
        background: #218838 !important;
        border-color: #218838 !important;
        transform: translateY(-2px) !important;
    }
    
    .luxury-quantity-label {
        display: flex !important;
        flex-direction: column !important;
        gap: 8px !important;
    }
    
    .luxury-quantity-label span {
        font-weight: 600 !important;
        color: #333 !important;
    }
    
    .luxury-variations {
        margin: 20px 0 !important;
    }
    
    .luxury-variation-group {
        margin-bottom: 15px !important;
    }
    
    .luxury-variation-label {
        display: block !important;
        font-weight: 600 !important;
        margin-bottom: 8px !important;
        color: #333 !important;
    }
    
    .luxury-variation-options {
        display: flex !important;
        flex-wrap: wrap !important;
        gap: 8px !important;
    }
    
    .luxury-variation-box {
        padding: 8px 16px !important;
        border: 1px solid #ddd !important;
        background: white !important;
        cursor: pointer !important;
        border-radius: 4px !important;
        transition: all 0.3s ease !important;
        font-size: 14px !important;
    }
    
    .luxury-variation-box:hover {
        background: #f8f9fa !important;
        border-color: #007bff !important;
    }
    
    .luxury-variation-box.selected {
        background: #007bff !important;
        color: white !important;
        border-color: #007bff !important;
    }
`;

// إضافة CSS للصفحة
if (!document.getElementById('main-product-css')) {
    const style = document.createElement('style');
    style.id = 'main-product-css';
    style.textContent = productPageCSS;
    document.head.appendChild(style);
}