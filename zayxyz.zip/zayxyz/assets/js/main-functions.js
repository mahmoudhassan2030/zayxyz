/*
 * ===================================================================
 *   Main Functions - ZayXYZ Theme
 *   تاريخ الإنشاء: 2024
 * ===================================================================
 */

jQuery(function($) {

    // ===================================
    //   Professional WooCommerce Notifier
    // ===================================

    // Helper function to show a toast notice
    function show_wc_toast_notice(message, notice_type = 'success') {
        // Clear any existing timers and remove old notices
        $('.wc-toast-notice.visible').remove();

        let notice_class = 'woocommerce-message';
        if (notice_type === 'error') {
            notice_class = 'woocommerce-error';
        } else if (notice_type === 'info') {
            notice_class = 'woocommerce-info';
        }

        const $notice = $(`
            <div class="${notice_class} wc-toast-notice" role="alert">
                <div class="wc-notice-content">${message}</div>
                <button class="wc-notice-close" aria-label="Dismiss">&times;</button>
                <div class="wc-notice-progress"></div>
            </div>
        `).appendTo('body');

        // Show with animation
        setTimeout(() => $notice.addClass('visible'), 10);

        // Auto-dismiss timer
        const timer = setTimeout(() => {
            $notice.removeClass('visible');
            $notice.one('transitionend webkitTransitionEnd oTransitionEnd', function() {
                $(this).remove();
            });
        }, 5000);

        // Manual dismiss
        $notice.on('click', '.wc-notice-close', function(e) {
            e.preventDefault();
            clearTimeout(timer);
            $notice.removeClass('visible');
            $notice.one('transitionend webkitTransitionEnd oTransitionEnd', function() {
                $(this).remove();
            });
        });
    }

    // ===================================
    //   Core Theme Functionality
    // ===================================

    function initSliders() {
        // سلايدر معرض الصور
        $('.product-gallery').each(function() {
            const $container = $(this).find('.gallery-container');
            const $images = $container.find('.gallery-image');
            if ($images.length === 0) return;
            
            const $prev = $(this).find('.prev');
            const $next = $(this).find('.next');
            let currentIndex = 0;
            
            function updateGallery() {
                const scrollPosition = $images.eq(currentIndex).position().left;
                $container.stop().animate({scrollLeft: scrollPosition}, 300);
                $prev.toggleClass('disabled', currentIndex === 0);
                $next.toggleClass('disabled', currentIndex >= $images.length - 1);
            }
            
            $prev.on('click', function(e) {
                e.preventDefault();
                if (currentIndex > 0) {
                    currentIndex--;
                    updateGallery();
                }
            });
            
            $next.on('click', function(e) {
                e.preventDefault();
                if (currentIndex < $images.length - 1) {
                    currentIndex++;
                    updateGallery();
                }
            });
            
            // إضافة نقاط التنقل
            const $dots = $('<div class="gallery-dots"></div>');
            $images.each(function(i) {
                $dots.append(`<span class="dot ${i === 0 ? 'active' : ''}" data-index="${i}"></span>`);
            });
            $(this).append($dots);
            
            $dots.on('click', '.dot', function() {
                currentIndex = parseInt($(this).data('index'));
                updateGallery();
                $dots.find('.dot').removeClass('active');
                $(this).addClass('active');
            });
            
            updateGallery();
        });
        
        // سلايدر المنتجات ذات الصلة
        $('.related-products-slider').each(function() {
            const $slider = $(this);
            const $track = $slider.find('.related-products-track');
            const $items = $track.find('.related-product-item');
            if ($items.length === 0) return;
            
            const $prev = $slider.find('.prev');
            const $next = $slider.find('.next');
            let currentIndex = 0;
            
            function updateSlider() {
                const itemWidth = $items.outerWidth(true);
                const visibleItems = Math.max(1, Math.floor($slider.width() / itemWidth));
                $track.css('transform', `translateX(-${currentIndex * itemWidth * visibleItems}px)`);
                $prev.toggleClass('disabled', currentIndex === 0);
                $next.toggleClass('disabled', currentIndex >= Math.ceil($items.length / visibleItems) - 1);
            }
            
            $prev.on('click', function(e) {
                e.preventDefault();
                if (currentIndex > 0) {
                    currentIndex--;
                    updateSlider();
                }
            });
            
            $next.on('click', function(e) {
                e.preventDefault();
                const visibleItems = Math.max(1, Math.floor($slider.width() / $items.outerWidth(true)));
                if (currentIndex < Math.ceil($items.length / visibleItems) - 1) {
                    currentIndex++;
                    updateSlider();
                }
            });
            
            // إعادة حساب عند تغيير حجم النافذة
            let resizeTimer;
            $(window).on('resize', function() {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(updateSlider, 250);
            });
            
            updateSlider();
        });
    }

    // ===================================
    //   Quick View Functionality
    // ===================================

    function initQuickView() {
        $(document).on('click', '.quick-view-btn', function(e) {
            e.preventDefault();
            
            const $btn = $(this);
            const productId = $btn.data('product-id');
            
            if (!productId) {
                show_wc_toast_notice('Product ID not found', 'error');
                return;
            }
            
            // Show loading state
            $btn.addClass('loading').prop('disabled', true);
            
            $.ajax({
                url: zayxyz_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'zayxyz_get_product_quick_view',
                    product_id: productId,
                    nonce: zayxyz_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Create modal
                        const $modal = $(`
                            <div class="quick-view-modal">
                                <div class="quick-view-overlay"></div>
                                <div class="quick-view-content">
                                    <button class="quick-view-close">&times;</button>
                                    <div class="quick-view-body">${response.data.html}</div>
                                </div>
                            </div>
                        `);
                        
                        $('body').append($modal);
                        $modal.fadeIn(300);
                        
                        // Close modal
                        $modal.find('.quick-view-close, .quick-view-overlay').on('click', function() {
                            $modal.fadeOut(300, function() {
                                $modal.remove();
                            });
                        });
                        
                        // Close on escape key
                        $(document).on('keydown.quickview', function(e) {
                            if (e.key === 'Escape') {
                                $modal.fadeOut(300, function() {
                                    $modal.remove();
                                });
                                $(document).off('keydown.quickview');
                            }
                        });
                        
                    } else {
                        show_wc_toast_notice(response.data.message || 'Failed to load product', 'error');
                    }
                },
                error: function() {
                    show_wc_toast_notice('Network error occurred', 'error');
                },
                complete: function() {
                    $btn.removeClass('loading').prop('disabled', false);
                }
            });
        });
    }

    // ===================================
    //   Unified Cart Functionality
    // ===================================

    function initCart() {
        // Update cart count
        function updateCartCount() {
            $.ajax({
                url: ajax_cart_params.ajax_url,
                type: 'POST',
                data: {
                    action: 'get_cart_details'
                },
                success: function(response) {
                    if (response.count !== undefined) {
                        $('.cart-count').text(response.count);
                        $('.cart-total').html(response.total);
                    }
                }
            });
        }

        // Unified Add to Cart functionality for all buttons
        $(document).on('click', '.add-to-cart-btn', function(e) {
            e.preventDefault();
            
            const $btn = $(this);
            const productId = $btn.data('product_id');
            const productType = $btn.data('product_type');
            const nonce = $btn.data('nonce') || zayxyz_ajax.nonce;
            
            if (!productId) return;
            
            // منع النقر المتكرر
            if ($btn.hasClass('loading')) return;
            
            $btn.addClass('loading');
            
            $.ajax({
                url: ajax_cart_params.ajax_url,
                type: 'POST',
                data: {
                    action: 'zayxyz_ajax_add_to_cart',
                    product_id: productId,
                    quantity: 1,
                    nonce: nonce
                },
                success: function(response) {
                    if (response.success) {
                        show_wc_toast_notice('Product added to cart successfully!', 'success');
                        updateCartCount();
                        // تحديث عدد المنتجات والسعر في الهيدر
                        $.ajax({
                            url: ajax_cart_params.ajax_url,
                            type: 'POST',
                            data: { action: 'get_cart_details' },
                            success: function(res) {
                                if (res.count !== undefined) {
                                    $('.cart-count').text(res.count);
                                }
                                if (res.total !== undefined) {
                                    $('.cart-total').html(res.total);
                                }
                            }
                        });
                        // تحديث مصغر السلة إذا كان موجودًا
                        $.ajax({
                            url: ajax_cart_params.ajax_url,
                            type: 'POST',
                            data: { action: 'get_refreshed_mini_cart' },
                            success: function(res) {
                                if (res.success && res.mini_cart_html) {
                                    $('.mini-cart-content').html(res.mini_cart_html);
                                }
                            }
                        });
                        // تحديث تلقائي لكل أجزاء السلة عبر WooCommerce
                        if (typeof jQuery !== 'undefined') {
                            jQuery(document.body).trigger('wc_fragment_refresh');
                        }
                    } else {
                        show_wc_toast_notice(response.data || 'Failed to add product to cart', 'error');
                    }
                },
                error: function() {
                    show_wc_toast_notice('Network error occurred', 'error');
                },
                complete: function() {
                    $btn.removeClass('loading');
                }
            });
        });

        // Unified Buy Now functionality for all buttons
        $(document).on('click', '.buy-now-btn', function(e) {
            e.preventDefault();
            
            const $btn = $(this);
            const productId = $btn.data('product_id');
            const productType = $btn.data('product_type');
            const nonce = $btn.data('nonce') || zayxyz_ajax.nonce;
            
            if (!productId) return;
            
            // منع النقر المتكرر
            if ($btn.hasClass('loading')) return;
            
            $btn.addClass('loading');
            
            // للمنتجات المتغيرة، التوجيه لصفحة المنتج
            if (productType === 'variable') {
                window.location.href = $btn.attr('href') || window.location.href;
                return;
            }
            
            $.ajax({
                url: ajax_cart_params.ajax_url,
                type: 'POST',
                data: {
                    action: 'zayxyz_ajax_add_to_cart',
                    product_id: productId,
                    quantity: 1,
                    buy_now: 1,
                    nonce: nonce
                },
                success: function(response) {
                    if (response.success) {
                        show_wc_toast_notice('Redirecting to checkout...', 'success');
                        // التوجيه لصفحة الدفع
                        setTimeout(function() {
                            window.location.href = wc_cart_fragments_params.cart_url.replace('/cart/', '/checkout/');
                        }, 1000);
                    } else {
                        show_wc_toast_notice(response.data || 'Failed to process buy now', 'error');
                    }
                },
                error: function() {
                    show_wc_toast_notice('Network error occurred', 'error');
                },
                complete: function() {
                    $btn.removeClass('loading');
                }
            });
        });

        // Update cart item quantity
        $(document).on('change', '.cart-item-quantity', function() {
            const $input = $(this);
            const cartKey = $input.data('cart-key');
            const quantity = parseInt($input.val());
            
            if (quantity < 1) return;
            
            $.ajax({
                url: ajax_cart_params.ajax_url,
                type: 'POST',
                data: {
                    action: 'update_cart_item',
                    cart_key: cartKey,
                    quantity: quantity
                },
                success: function(response) {
                    if (response.success) {
                        updateCartCount();
                        // Update cart totals
                        $('.cart-subtotal').html(response.cart_subtotal);
                        $('.cart-total').html(response.cart_total);
                    }
                }
            });
        });

        // Remove cart item
        $(document).on('click', '.remove-cart-item', function(e) {
            e.preventDefault();
            
            const $btn = $(this);
            const cartKey = $btn.data('cart-key');
            
            $.ajax({
                url: ajax_cart_params.ajax_url,
                type: 'POST',
                data: {
                    action: 'remove_cart_item',
                    cart_key: cartKey
                },
                success: function(response) {
                    if (response.success) {
                        $btn.closest('.cart-item').fadeOut(300, function() {
                            $(this).remove();
                        });
                        updateCartCount();
                    }
                }
            });
        });
    }

    // ===================================
    //   Variation Buttons
    // ===================================

    function initVariationButtons() {
        $(document).on('click', '.zayxyz-variation-btn', function() {
            const $btn = $(this);
            const $group = $btn.closest('.zayxyz-variation-buttons');
            const value = $btn.data('value');
            const attributeName = $group.data('attribute_name');
            
            // Update button states
            $group.find('.zayxyz-variation-btn').removeClass('active');
            $btn.addClass('active');
            
            // Update hidden select
            const $select = $group.siblings('div').find('select');
            if ($select.length) {
                $select.val(value).trigger('change');
            }
            
            // Update hidden input
            const $input = $group.siblings('div').find('input[name="' + attributeName + '"]');
            if ($input.length) {
                $input.val(value);
            }
        });
    }

    // ===================================
    //   Countdown Timer
    // ===================================

    function initCountdown() {
        $('.countdown-timer').each(function() {
            const $timer = $(this);
            const endTime = $timer.data('end-time');
            
            if (!endTime) return;
            
            function updateTimer() {
                const now = new Date().getTime();
                const end = new Date(endTime).getTime();
                const diff = end - now;
                
                if (diff <= 0) {
                    $timer.html('<span class="expired">Offer Expired</span>');
                    return;
                }
                
                const days = Math.floor(diff / (1000 * 60 * 60 * 24));
                const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((diff % (1000 * 60)) / 1000);
                
                $timer.html(`
                    <div class="countdown-item">
                        <span class="countdown-number">${days}</span>
                        <span class="countdown-label">Days</span>
                    </div>
                    <div class="countdown-item">
                        <span class="countdown-number">${hours}</span>
                        <span class="countdown-label">Hours</span>
                    </div>
                    <div class="countdown-item">
                        <span class="countdown-number">${minutes}</span>
                        <span class="countdown-label">Minutes</span>
                    </div>
                    <div class="countdown-item">
                        <span class="countdown-number">${seconds}</span>
                        <span class="countdown-label">Seconds</span>
                    </div>
                `);
            }
            
            updateTimer();
            setInterval(updateTimer, 1000);
        });
    }

    // ===================================
    //   Process Existing Notices
    // ===================================

    function processExistingNotices() {
        $('.woocommerce-message, .woocommerce-error, .woocommerce-info').each(function() {
            const $notice = $(this);
            const message = $notice.text().trim();
            const type = $notice.hasClass('woocommerce-error') ? 'error' : 
                        $notice.hasClass('woocommerce-info') ? 'info' : 'success';
            
            show_wc_toast_notice(message, type);
            $notice.remove();
        });
    }

    // ===================================
    //   Initialize Everything
    // ===================================

    function init() {
        initSliders();
        initQuickView();
        initCart();
        initVariationButtons();
        initCountdown();
        processExistingNotices();
        
        // Add CSS for components
        if (!$('#main-functions-css').length) {
            const css = `
                .wc-toast-notice {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    z-index: 9999;
                    max-width: 400px;
                    padding: 15px 20px;
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                    transform: translateX(100%);
                    transition: transform 0.3s ease;
                    background: white;
                    border-left: 4px solid #28a745;
                }
                
                .wc-toast-notice.visible {
                    transform: translateX(0);
                }
                
                .wc-toast-notice.woocommerce-error {
                    border-left-color: #dc3545;
                }
                
                .wc-toast-notice.woocommerce-info {
                    border-left-color: #17a2b8;
                }
                
                .wc-notice-content {
                    margin-right: 30px;
                }
                
                .wc-notice-close {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                    background: none;
                    border: none;
                    font-size: 20px;
                    cursor: pointer;
                    color: #666;
                }
                
                .wc-notice-progress {
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    height: 3px;
                    background: #28a745;
                    animation: progress 5s linear;
                }
                
                @keyframes progress {
                    from { width: 100%; }
                    to { width: 0%; }
                }
                
                .quick-view-modal {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    z-index: 9999;
                    display: none;
                }
                
                .quick-view-overlay {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0,0,0,0.5);
                }
                
                .quick-view-content {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background: white;
                    border-radius: 8px;
                    max-width: 90%;
                    max-height: 90%;
                    overflow-y: auto;
                }
                
                .quick-view-close {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                    background: none;
                    border: none;
                    font-size: 24px;
                    cursor: pointer;
                    z-index: 1;
                }
                
                .zayxyz-variation-btn {
                    padding: 8px 16px;
                    margin: 2px;
                    border: 1px solid #ddd;
                    background: white;
                    cursor: pointer;
                    border-radius: 4px;
                    transition: all 0.3s ease;
                }
                
                .zayxyz-variation-btn:hover,
                .zayxyz-variation-btn.active {
                    background: #007bff;
                    color: white;
                    border-color: #007bff;
                }
                
                /* Unified Button Styles */
                .add-to-cart-btn,
                .buy-now-btn,
                .select-options-btn,
                .external-product-btn,
                .grouped-product-btn {
                    display: inline-flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    padding: 10px 20px !important;
                    border-radius: 6px !important;
                    font-weight: 600 !important;
                    text-decoration: none !important;
                    transition: all 0.3s ease !important;
                    border: 2px solid transparent !important;
                    cursor: pointer !important;
                    min-width: 120px !important;
                }
                
                .add-to-cart-btn {
                    background: #007bff !important;
                    color: white !important;
                    border-color: #007bff !important;
                }
                
                .add-to-cart-btn:hover {
                    background: #0056b3 !important;
                    border-color: #0056b3 !important;
                    transform: translateY(-2px) !important;
                    box-shadow: 0 4px 8px rgba(0, 123, 255, 0.3) !important;
                }
                
                .buy-now-btn {
                    background: #28a745 !important;
                    color: white !important;
                    border-color: #28a745 !important;
                }
                
                .buy-now-btn:hover {
                    background: #218838 !important;
                    border-color: #218838 !important;
                    transform: translateY(-2px) !important;
                    box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3) !important;
                }
                
                .select-options-btn {
                    background: #6c757d !important;
                    color: white !important;
                    border-color: #6c757d !important;
                }
                
                .select-options-btn:hover {
                    background: #545b62 !important;
                    border-color: #545b62 !important;
                    transform: translateY(-2px) !important;
                    box-shadow: 0 4px 8px rgba(108, 117, 125, 0.3) !important;
                }
                
                .external-product-btn {
                    background: #fd7e14 !important;
                    color: white !important;
                    border-color: #fd7e14 !important;
                }
                
                .external-product-btn:hover {
                    background: #e8690b !important;
                    border-color: #e8690b !important;
                    transform: translateY(-2px) !important;
                    box-shadow: 0 4px 8px rgba(253, 126, 20, 0.3) !important;
                }
                
                .grouped-product-btn {
                    background: #6f42c1 !important;
                    color: white !important;
                    border-color: #6f42c1 !important;
                }
                
                .grouped-product-btn:hover {
                    background: #5a32a3 !important;
                    border-color: #5a32a3 !important;
                    transform: translateY(-2px) !important;
                    box-shadow: 0 4px 8px rgba(111, 66, 193, 0.3) !important;
                }
                
                /* Button Groups */
                .simple-product-buttons,
                .variable-product-buttons {
                    display: flex !important;
                    gap: 10px !important;
                    flex-wrap: wrap !important;
                    justify-content: center !important;
                }
                
                .loop-add-to-cart-buttons {
                    margin-top: 15px !important;
                }
                
                /* Product Card Button Improvements */
                .product-card-custom .loop-add-to-cart-buttons {
                    margin-top: 10px !important;
                }
                
                .product-card-custom .add-to-cart-btn,
                .product-card-custom .buy-now-btn {
                    font-size: 12px !important;
                    padding: 8px 12px !important;
                    min-width: 100px !important;
                }
                
                /* Quick View Button Improvements */
                .luxury-quick-view-container .add-to-cart-btn,
                .luxury-quick-view-container .buy-now-btn {
                    margin: 5px !important;
                }
                
                /* Single Product Page Button Improvements */
                .luxury-add-to-cart-buttons .add-to-cart-btn,
                .luxury-add-to-cart-buttons .buy-now-btn {
                    font-size: 16px !important;
                    padding: 15px 25px !important;
                    min-width: 150px !important;
                }
                
                /* Responsive Button Adjustments */
                @media (max-width: 768px) {
                    .simple-product-buttons,
                    .variable-product-buttons {
                        flex-direction: column !important;
                        gap: 8px !important;
                    }
                    
                    .add-to-cart-btn,
                    .buy-now-btn,
                    .select-options-btn,
                    .external-product-btn,
                    .grouped-product-btn {
                        min-width: 100% !important;
                        justify-content: center !important;
                    }
                }
                
                /* Loading State */
                .add-to-cart-btn.loading,
                .buy-now-btn.loading,
                .select-options-btn.loading,
                .external-product-btn.loading,
                .grouped-product-btn.loading {
                    position: relative !important;
                    pointer-events: none !important;
                    opacity: 0.7 !important;
                }
                
                .add-to-cart-btn.loading::after,
                .buy-now-btn.loading::after,
                .select-options-btn.loading::after,
                .external-product-btn.loading::after,
                .grouped-product-btn.loading::after {
                    content: '' !important;
                    position: absolute !important;
                    top: 50% !important;
                    left: 50% !important;
                    width: 16px !important;
                    height: 16px !important;
                    margin: -8px 0 0 -8px !important;
                    border: 2px solid transparent !important;
                    border-top: 2px solid currentColor !important;
                    border-radius: 50% !important;
                    animation: spin 1s linear infinite !important;
                }
                
                .countdown-timer {
                    display: flex;
                    gap: 10px;
                    justify-content: center;
                }
                
                .countdown-item {
                    text-align: center;
                    min-width: 60px;
                }
                
                .countdown-number {
                    display: block;
                    font-size: 24px;
                    font-weight: bold;
                    color: #007bff;
                }
                
                .countdown-label {
                    display: block;
                    font-size: 12px;
                    color: #666;
                    text-transform: uppercase;
                }
                
                .loading {
                    position: relative;
                    pointer-events: none;
                }
                
                .loading::after {
                    content: '';
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    width: 16px;
                    height: 16px;
                    margin: -8px 0 0 -8px;
                    border: 2px solid transparent;
                    border-top: 2px solid currentColor;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                }
                
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            `;
            
            $('<style id="main-functions-css">' + css + '</style>').appendTo('head');
        }
    }

    // Initialize when document is ready
    init();
});

