<?php
get_header();
?>
<div style="text-align:center; padding: 80px 20px;">
    <h1 style="font-size: 4em; color: #e74c3c;">404</h1>
    <h2 style="margin-bottom: 20px;">Sorry, the page does not exist!</h2>
    <p style="font-size: 1.2em;">It appears you tried to access a page that does not exist or has been deleted..</p>
    <a href="<?php echo home_url(); ?>" style="display:inline-block; margin-top:30px; padding:12px 30px; background:#27ae60; color:#fff; border-radius:6px; text-decoration:none; font-size:1.1em;">Return to the home page</a>
</div>
<?php
get_footer();
?>
