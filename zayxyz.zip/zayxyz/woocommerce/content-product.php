<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>
<div <?php wc_product_class( 'card h-100 product-card-custom overflow-hidden shadow-sm rounded-lg border-0 transition-3d-hover', $product ); ?>>
    <div class="product-image-wrapper position-relative">
        <a href="<?php echo esc_url( get_permalink() ); ?>" class="d-block text-center bg-light">
            <?php 
                woocommerce_show_product_loop_sale_flash(); 
                
                $image_id = $product->get_image_id();
                $gallery_ids = $product->get_gallery_image_ids();
                
                $main_image_url = $image_id ? wp_get_attachment_image_url($image_id, 'woocommerce_thumbnail') : wc_placeholder_img_src();
                $hover_image_url = !empty($gallery_ids) ? wp_get_attachment_image_url($gallery_ids[0], 'woocommerce_thumbnail') : $main_image_url;
            ?>
            <img src="<?php echo esc_url($main_image_url); ?>" alt="<?php echo esc_attr($product->get_name()); ?>" class="card-img-top product-image-main" style="max-height: 250px; object-fit: cover;">
            <img src="<?php echo esc_url($hover_image_url); ?>" alt="<?php echo esc_attr($product->get_name()); ?>" class="card-img-top product-image-hover position-absolute top-0 start-0" style="max-height: 250px; object-fit: cover;">
        </a>

        <div class="product-actions-overlay position-absolute top-50 start-50 translate-middle w-100 text-center">
            <a href="#" class="btn btn-light btn-icon rounded-circle quick-view-button p-2 mx-1" data-product-id="<?php echo esc_attr($product->get_id()); ?>" data-bs-toggle="tooltip" title="Quick View">
                <i class="fas fa-eye fa-lg"></i>
            </a>
            <?php 
            if ( class_exists( 'YITH_WCWL' ) ) {
                echo do_shortcode('[yith_wcwl_add_to_wishlist product_id="' . $product->get_id() . '" container_classes="d-inline-block" button_classes="btn btn-light btn-icon rounded-circle p-2 mx-1" icon="far fa-heart fa-lg" label="" already_in_wishslist_text=""]');
            }
            ?>
        </div>
    </div>

    <div class="card-body d-flex flex-column p-3">
        <div class="product-info text-center">
            <h2 class="woocommerce-loop-product__title h6 mb-2">
                <a class="text-dark text-decoration-none" href="<?php echo esc_url( get_permalink() ); ?>">
                    <?php echo esc_html( $product->get_name() ); ?>
                </a>
            </h2>

            <div class="mb-2">
                <?php wc_get_template('custom-rating.php'); ?>
            </div>
        </div>

        <div class="price-button-container mt-auto">
            <div class="product-price mb-2">
                <?php echo $product->get_price_html(); ?>
            </div>
            
            <?php woocommerce_template_loop_add_to_cart(); ?>
        </div>
    </div>
</div> 