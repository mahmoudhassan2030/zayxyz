<?php
/**
 * Active Filters (fallback template)
 * ------------------------------------------------
 * WooCommerce looks for this template to render the area that shows any
 * currently-applied layered-nav or price filters.  Some installs see warnings
 * if the file is missing (e.g. “failed to open stream” for
 * templates/loop/active-filters.php).  Providing this minimal template removes
 * the warning and gives you a place to customise the markup later.
 *
 * You can extend this at any time to show tags for each active filter and a
 * clear-all link.  For now it simply outputs nothing when no filters are set.
 *
 * @package zayxyz
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Detect active price filters.
$min = isset( $_GET['min_price'] ) ? wc_clean( wp_unslash( $_GET['min_price'] ) ) : '';
$max = isset( $_GET['max_price'] ) ? wc_clean( wp_unslash( $_GET['max_price'] ) ) : '';

$active_filters = array();

if ( '' !== $min || '' !== $max ) {
    $label = sprintf( '%s — %s', $min ? wc_price( (float) $min ) : '0', $max ? wc_price( (float) $max ) : __( '∞', 'woocommerce' ) );
    $remove_url = remove_query_arg( array( 'min_price', 'max_price' ) );
    $active_filters[] = array( 'label' => $label, 'remove' => $remove_url );
}

// You can extend here to include layered nav attribute filters if required.

if ( empty( $active_filters ) ) {
    return; // Nothing to show.
}
?>
<div class="woocommerce-active-filters widget">
    <h3 class="widgettitle"><?php esc_html_e( 'Active Filters', 'woocommerce' ); ?></h3>
    <ul class="active-filters-list">
        <?php foreach ( $active_filters as $filter ) : ?>
            <li>
                <span class="filter-label"><?php echo wp_kses_post( $filter['label'] ); ?></span>
                <a href="<?php echo esc_url( $filter['remove'] ); ?>" class="remove" aria-label="<?php esc_attr_e( 'Remove filter', 'woocommerce' ); ?>">&times;</a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>
