<?php
/**
 * Loop Add to Cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/add-to-cart.php.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.3.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! $product || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
    return;
}

$product_id = $product->get_id();
$product_type = $product->get_type();
$nonce = wp_create_nonce('woocommerce-add-to-cart');
?>

<div class="loop-add-to-cart-buttons">
    <?php if ( $product_type === 'simple' ): ?>
        <!-- منتج بسيط -->
        <div class="simple-product-buttons">
            <button type="button" class="btn-main-action" data-product_id="<?php echo esc_attr($product_id); ?>" data-product_type="simple" data-nonce="<?php echo esc_attr($nonce); ?>">
                <i class="fas fa-shopping-cart me-2"></i>
                <?php echo esc_html($product->single_add_to_cart_text()); ?>
            </button>
            
            <button type="button" class="btn-main-action" data-product_id="<?php echo esc_attr($product_id); ?>" data-product_type="simple" data-nonce="<?php echo esc_attr($nonce); ?>">
                <i class="fas fa-bolt me-2"></i>
                <?php esc_html_e('Buy Now', 'zayxyz'); ?>
            </button>
        </div>
        
    <?php elseif ( $product_type === 'variable' ): ?>
        <!-- منتج متغير -->
        <div class="variable-product-buttons">
            <a href="<?php echo esc_url($product->get_permalink()); ?>" class="btn-main-action">
                <i class="fas fa-cog me-2"></i>
                <?php esc_html_e('Select Options', 'zayxyz'); ?>
            </a>
            
            <a href="<?php echo esc_url($product->get_permalink()); ?>" class="btn-main-action">
                <i class="fas fa-bolt me-2"></i>
                <?php esc_html_e('Buy Now', 'zayxyz'); ?>
            </a>
        </div>
        
    <?php elseif ( $product_type === 'external' ): ?>
        <!-- منتج خارجي -->
        <a href="<?php echo esc_url($product->get_product_url()); ?>" class="btn-main-action" target="_blank" rel="noopener noreferrer">
            <i class="fas fa-external-link-alt me-2"></i>
            <?php echo esc_html($product->single_add_to_cart_text()); ?>
        </a>
        
    <?php elseif ( $product_type === 'grouped' ): ?>
        <!-- منتج مجمع -->
        <a href="<?php echo esc_url($product->get_permalink()); ?>" class="btn-main-action">
            <i class="fas fa-layer-group me-2"></i>
            <?php esc_html_e('View Products', 'zayxyz'); ?>
        </a>
        
    <?php endif; ?>
</div> 