<?php
/**
 * Featured Products Loop
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/featured-products.php.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

// Get featured products
$featured_products = wc_get_featured_product_ids();

if ( empty( $featured_products ) ) {
    return;
}

$args = array(
    'post_type'      => 'product',
    'posts_per_page' => 12,
    'post__in'       => $featured_products,
    'meta_query'     => array(
        array(
            'key'     => '_visibility',
            'value'   => array( 'catalog', 'visible' ),
            'compare' => 'IN'
        )
    )
);

$featured_query = new WP_Query( $args );

if ( $featured_query->have_posts() ) : ?>
    <section class="featured-products py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2 class="text-center mb-5"><?php esc_html_e('Featured Products', 'zayxyz'); ?></h2>
                </div>
            </div>
            
            <div class="featured-products-slider position-relative">
                <div class="slick-slider-wrapper">
                    <div class="products-slick">
                        <?php while ( $featured_query->have_posts() ) : $featured_query->the_post(); ?>
                            <div class="px-2">
                                <?php
                                global $product;
                                wc_get_template_part( 'content', 'product' );
                                ?>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif;

wp_reset_postdata();
?> 