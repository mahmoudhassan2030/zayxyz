<?php
/**
 * New Products Loop
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/new-products.php.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

// Get new products (last 30 days)
$args = array(
    'post_type'      => 'product',
    'posts_per_page' => 12,
    'meta_query'     => array(
        array(
            'key'     => '_visibility',
            'value'   => array( 'catalog', 'visible' ),
            'compare' => 'IN'
        )
    ),
    'date_query'     => array(
        array(
            'after' => '30 days ago'
        )
    )
);

$new_products_query = new WP_Query( $args );

if ( $new_products_query->have_posts() ) : ?>
    <section class="new-products py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2 class="text-center mb-5"><?php esc_html_e('New Arrivals', 'zayxyz'); ?></h2>
                </div>
            </div>
            
            <div class="new-products-slider position-relative">
                <div class="slick-slider-wrapper">
                    <div class="products-slick">
                        <?php while ( $new_products_query->have_posts() ) : $new_products_query->the_post(); ?>
                            <div class="px-2">
                                <?php
                                global $product;
                                wc_get_template_part( 'content', 'product' );
                                ?>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif;

wp_reset_postdata();
?> 