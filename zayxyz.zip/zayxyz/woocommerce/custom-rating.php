<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

global $product;

if ( ! wc_review_ratings_enabled() ) {
    return;
}

$rating_count = $product->get_rating_count();
$average      = $product->get_average_rating();

if ( $rating_count > 0 ) : ?>
    <div class="star-rating-filled d-inline-block mb-3">
        <?php 
        for ($i = 1; $i <= 5; $i++):
            $star_class = ($i <= round($average)) ? 'fas' : 'far';
            $star_color = ($i <= round($average)) ? 'text-warning' : 'text-muted';
        ?>
            <i class="<?php echo $star_class; ?> fa-star <?php echo $star_color; ?>"></i>
        <?php endfor; ?>
    </div>
<?php else : ?>
    <div class="star-rating-empty d-inline-block mb-3">
        <?php for ($i = 1; $i <= 5; $i++) : ?>
            <i class="far fa-star text-muted"></i>
        <?php endfor; ?>
    </div>
<?php endif; ?>