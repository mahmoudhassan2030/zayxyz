<?php
defined('ABSPATH') || exit;

global $product;

/**
 * Hook: woocommerce_before_single_product.
 */
do_action('woocommerce_before_single_product');

if (post_password_required()) {
    echo get_the_password_form();
    return;
}

// Remove default product meta display
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class('luxury-product-container', $product); ?>>
    
    <!-- Premium Breadcrumb -->
    <div class="luxury-breadcrumb-wrapper">
        <nav aria-label="breadcrumb" class="product-breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo home_url(); ?>">
                        <i class="fas fa-home"></i> <?php _e('Home', 'zayxyz'); ?>
                    </a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo get_permalink(wc_get_page_id('shop')); ?>">
                        <i class="fas fa-store"></i> <?php _e('Shop', 'zayxyz'); ?>
                    </a>
                </li>
                <?php
                $categories = get_the_terms($product->get_id(), 'product_cat');
                if ($categories && !is_wp_error($categories)) {
                    $category = $categories[0];
                    echo '<li class="breadcrumb-item"><a href="' . get_term_link($category) . '"><i class="fas fa-tag"></i> ' . $category->name . '</a></li>';
                }
                ?>
                <li class="breadcrumb-item active" aria-current="page">
                    <i class="fas fa-sparkles"></i> <?php echo $product->get_name(); ?>
                </li>
            </ol>
        </nav>
    </div>

    <!-- Premium Product Grid -->
    <div class="luxury-product-grid">
        <!-- Gallery Section -->
        <div class="luxury-gallery-container">
            <div class="luxury-gallery-wrapper">
                <!-- Main Image -->
                <div class="luxury-main-image">
                    <?php
                    if ($product->get_image_id()) {
                        echo wp_get_attachment_image($product->get_image_id(), 'woocommerce_single', false, array(
                            'class' => 'luxury-product-image',
                            'id' => 'luxury-main-product-image',
                            'loading' => 'eager'
                        ));
                    } else {
                        echo '<img src="' . wc_placeholder_img_src('woocommerce_single') . '" alt="' . esc_attr__('Awaiting product image', 'zayxyz') . '" class="luxury-product-image" id="luxury-main-product-image" />';
                    }
                    ?>
                    
                    <!-- Gallery Tools -->
                    <div class="luxury-gallery-tools">
                        <button class="luxury-gallery-btn zoom-btn" data-action="zoom">
                            <i class="fas fa-search-plus"></i>
                        </button>
                        <?php if ($product->get_gallery_image_ids()) : ?>
                            <button class="luxury-gallery-btn gallery-btn" data-action="gallery">
                                <i class="fas fa-expand"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Thumbnails -->
                <div class="luxury-thumbnails-wrapper">
                    <div class="luxury-thumbnails-container">
                        <?php
                        $attachment_ids = $product->get_gallery_image_ids();
                        if ($product->get_image_id()) {
                            echo '<div class="luxury-thumbnail active" data-image="' . wp_get_attachment_image_url($product->get_image_id(), 'woocommerce_single') . '">' . 
                                 wp_get_attachment_image($product->get_image_id(), 'woocommerce_gallery_thumbnail') . '</div>';
                        }
                        
                        if ($attachment_ids) {
                            foreach ($attachment_ids as $attachment_id) {
                                echo '<div class="luxury-thumbnail" data-image="' . wp_get_attachment_image_url($attachment_id, 'woocommerce_single') . '">' . 
                                     wp_get_attachment_image($attachment_id, 'woocommerce_gallery_thumbnail') . '</div>';
                            }
                        }
                        ?>
                    </div>
                    <button class="luxury-thumbnails-nav prev"><i class="fas fa-chevron-left"></i></button>
                    <button class="luxury-thumbnails-nav next"><i class="fas fa-chevron-right"></i></button>
                </div>
            </div>
        </div>

        <!-- Product Summary -->
        <div class="luxury-summary-container">
            <div class="luxury-summary-card">
                <!-- Product Badges -->
                <div class="luxury-product-badges">
                    <?php if ($product->is_on_sale()) : ?>
                        <span class="luxury-badge sale-badge">
                            <i class="fas fa-bolt"></i> <?php _e('HOT DEAL', 'zayxyz'); ?>
                        </span>
                    <?php endif; ?>
                    <?php if ($product->is_featured()) : ?>
                        <span class="luxury-badge featured-badge">
                            <i class="fas fa-crown"></i> <?php _e('PREMIUM', 'zayxyz'); ?>
                        </span>
                    <?php endif; ?>
                    <?php 
                    // شارة جديد إذا كان المنتج منشور خلال آخر 30 يوم
                    $post_date = get_the_date('U', $product->get_id());
                    if ((time() - $post_date) < 30 * 24 * 60 * 60) : ?>
                        <span class="luxury-badge new-badge">
                            <i class="fas fa-star"></i> <?php _e('NEW', 'zayxyz'); ?>
                        </span>
                    <?php endif; ?>
                </div>

                <!-- Product Title -->
                <h1 class="luxury-product-title"><?php the_title(); ?></h1>
                
                <!-- Product Rating -->
                <div class="luxury-product-rating">
                    <?php woocommerce_template_single_rating(); ?>
                    <span class="review-count"><?php echo $product->get_review_count(); ?> <?php _e('reviews', 'zayxyz'); ?></span>
                </div>
                
                <!-- Product Price -->
                <div class="luxury-price-container">
                    <?php woocommerce_template_single_price(); ?>
                    <?php if ($product->is_on_sale()) : ?>
                        <span class="luxury-discount-badge">
                            <?php 
                            $regular_price = (float)$product->get_regular_price();
                            $sale_price = (float)$product->get_sale_price();
                            if ($regular_price > 0) {
                                $discount = round((($regular_price - $sale_price) / $regular_price) * 100);
                                echo '-' . $discount . '%';
                            }
                            ?>
                        </span>
                    <?php endif; ?>
                </div>
                <!-- Guarantee bar or note below the price -->
                <div class="luxury-guarantee-bar">
                    <i class="fas fa-shield-alt"></i>
                    <?php _e('30 Days Money Back Guarantee & Authentic Quality', 'zayxyz'); ?>
                </div>
                
                <!-- Product Short Description -->
                <div class="luxury-short-description">
                    <?php woocommerce_template_single_excerpt(); ?>
                </div>
                
                <!-- Product Availability -->
                <div class="luxury-availability">
                    <i class="fas fa-check-circle"></i>
                    <?php if ($product->is_in_stock()) : ?>
                        <span class="in-stock"><?php _e('In Stock', 'zayxyz'); ?></span>
                    <?php else : ?>
                        <span class="out-of-stock"><?php _e('Out of Stock', 'zayxyz'); ?></span>
                    <?php endif; ?>
                </div>
                
                <!-- Add to Cart Form -->
                <div class="luxury-add-to-cart">
                    <?php woocommerce_template_single_add_to_cart(); ?>
                </div>
                
                <!-- Trust Badges -->
                <div class="luxury-trust-badges">
                    <div class="trust-badge">
                        <i class="fas fa-shield-alt"></i>
                        <span><?php _e('Authentic Quality', 'zayxyz'); ?></span>
                    </div>
                    <div class="trust-badge">
                        <i class="fas fa-truck"></i>
                        <span><?php _e('Free Shipping', 'zayxyz'); ?></span>
                    </div>
                    <div class="trust-badge">
                        <i class="fas fa-undo"></i>
                        <span><?php _e('Easy Returns', 'zayxyz'); ?></span>
                    </div>
                </div>
                
               
                
                <!-- Social Sharing -->
                <div class="luxury-social-sharing">
                    <span><?php _e('Share:', 'zayxyz'); ?></span>
                    <a href="#" class="social-icon facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social-icon twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="social-icon pinterest"><i class="fab fa-pinterest-p"></i></a>
                    <a href="#" class="social-icon whatsapp"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
        </div>
    </div>

    <!-- Premium Product Tabs -->
    <div class="luxury-product-tabs">
        <div class="luxury-tabs-navigation">
            <button class="luxury-tab-btn active" data-tab="description"><?php _e('Description', 'zayxyz'); ?></button>
            <?php if (!$product->is_type('simple')) : ?>
            <button class="luxury-tab-btn" data-tab="additional"><?php _e('Specifications', 'zayxyz'); ?></button>
            <?php endif; ?>
            <button class="luxury-tab-btn" data-tab="reviews"><?php _e('Reviews', 'zayxyz'); ?></button>
            <button class="luxury-tab-btn" data-tab="shipping"><?php _e('Shipping', 'zayxyz'); ?></button>
        </div>
        
        <div class="luxury-tabs-content">
            <!-- Description Tab -->
            <div class="luxury-tab-pane active" id="description-tab">
                <div class="luxury-tab-content">
                    <?php woocommerce_product_description_tab(); ?>
                </div>
            </div>
            
            <!-- Specifications Tab -->
            <?php if (!$product->is_type('simple')) : ?>
            <div class="luxury-tab-pane" id="additional-tab">
                <div class="luxury-specifications-grid">
                    <?php 
                    $attributes = $product->get_attributes();
                    if ($attributes) : ?>
                        <?php foreach ($attributes as $attribute) : ?>
                            <div class="luxury-spec-item">
                                <span class="spec-name"><?php echo wc_attribute_label($attribute->get_name()); ?></span>
                                <span class="spec-value">
                                    <?php
                                    if ($attribute->is_taxonomy()) {
                                        $values = wc_get_product_terms($product->get_id(), $attribute->get_name(), array('fields' => 'names'));
                                        echo apply_filters('woocommerce_attribute', wpautop(wptexturize(implode(', ', $values))), $attribute, $values);
                                    } else {
                                        $values = array_map('trim', explode(WC_DELIMITER, $attribute->get_options()));
                                        echo apply_filters('woocommerce_attribute', wpautop(wptexturize(implode(', ', $values))), $attribute, $values);
                                    }
                                    ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Reviews Tab -->
            <div class="luxury-tab-pane" id="reviews-tab">
                <div class="luxury-reviews-container">
                    <?php comments_template(); ?>
                </div>
            </div>
            
            <!-- Shipping Tab -->
            <div class="luxury-tab-pane" id="shipping-tab">
                <div class="luxury-shipping-info">
                    <div class="luxury-shipping-methods">
                        <h3><?php echo esc_html( get_theme_mod('shipping_options_label', __('Shipping Options', 'zayxyz')) ); ?></h3>
                        <ul>
                            <li>
                                <i class="fas fa-shipping-fast"></i>
                                <strong><?php echo esc_html( get_theme_mod('standard_shipping_label', __('Standard Shipping', 'zayxyz')) ); ?></strong>
                                <span><?php echo esc_html( get_theme_mod('standard_shipping_time', __('3-5 business days', 'zayxyz')) ); ?></span>
                            </li>
                            <li>
                                <i class="fas fa-rocket"></i>
                                <strong><?php echo esc_html( get_theme_mod('express_shipping_label', __('Express Shipping', 'zayxyz')) ); ?></strong>
                                <span><?php echo esc_html( get_theme_mod('express_shipping_time', __('1-2 business days', 'zayxyz')) ); ?></span>
                            </li>
                        </ul>
                    </div>
                    <div class="luxury-return-policy">
                        <h3><?php echo esc_html( get_theme_mod('return_policy_title', __('Return Policy', 'zayxyz')) ); ?></h3>
                        <p><?php echo esc_html( get_theme_mod('return_policy_text', __('We offer 30-day money back guarantee for all our products. If you\'re not satisfied with your purchase, simply return it for a full refund.', 'zayxyz')) ); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Related Products -->
    <div class="luxury-related-products">
        <h2 class="luxury-section-title"><?php echo esc_html( get_theme_mod('you_may_also_like_heading', __('You May Also Like', 'zayxyz')) ); ?></h2>
        <div class="luxury-products-grid">
            <?php
            $args = array(
                'posts_per_page' => 4,
                'columns' => 4,
                'orderby' => 'rand',
                'order' => 'desc'
            );
            woocommerce_related_products($args);
            ?>
        </div>
    </div>
</div>

<?php do_action('woocommerce_after_single_product'); ?>


<!-- Lightbox Gallery -->
<div class="luxury-gallery-lightbox">
    <div class="luxury-lightbox-container">
        <button class="luxury-lightbox-close"><i class="fas fa-times"></i></button>
        <button class="luxury-lightbox-nav prev"><i class="fas fa-chevron-left"></i></button>
        <button class="luxury-lightbox-nav next"><i class="fas fa-chevron-right"></i></button>
        <div class="luxury-lightbox-slider">
            <?php
            if ($product->get_image_id()) {
                echo '<div class="luxury-lightbox-slide">' . 
                     wp_get_attachment_image($product->get_image_id(), 'full') . '</div>';
            }
            
            $attachment_ids = $product->get_gallery_image_ids();
            if ($attachment_ids) {
                foreach ($attachment_ids as $attachment_id) {
                    echo '<div class="luxury-lightbox-slide">' . 
                         wp_get_attachment_image($attachment_id, 'full') . '</div>';
                }
            }
            ?>
        </div>
    </div>
</div>
