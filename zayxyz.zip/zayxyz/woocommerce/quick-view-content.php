<?php
/**
 * The template for displaying product quick view content.
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

global $product;

$image_id = $product->get_image_id();
$gallery_ids = $product->get_gallery_image_ids();

$main_image_url = $image_id ? wp_get_attachment_image_url($image_id, 'woocommerce_single') : wc_placeholder_img_src();
?>
<div class="luxury-quick-view-container">
    <div class="row">
        <!-- Product Gallery -->
        <div class="col-lg-6">
            <div class="luxury-quick-view-gallery">
                <div class="luxury-main-image-container mb-3">
                    <img src="<?php echo esc_url($main_image_url); ?>" 
                         alt="<?php echo esc_attr($product->get_name()); ?>" 
                         class="img-fluid rounded luxury-quick-view-main-image">
                </div>
                
                <?php if (!empty($gallery_ids)) : ?>
                    <div class="luxury-thumbnails-container d-flex flex-wrap gap-2">
                        <?php 
                        // Add main image to gallery as well
                        $all_gallery_ids = array_merge([$image_id], $gallery_ids);
                        foreach ($all_gallery_ids as $gallery_image_id) : 
                            $thumbnail_url = wp_get_attachment_image_url($gallery_image_id, 'woocommerce_thumbnail');
                            $full_image_url = wp_get_attachment_image_url($gallery_image_id, 'woocommerce_single');
                        ?>
                            <img src="<?php echo esc_url($thumbnail_url); ?>" 
                                 alt="<?php echo esc_attr($product->get_name()); ?>" 
                                 class="luxury-thumbnail img-thumbnail" 
                                 data-full-image="<?php echo esc_url($full_image_url); ?>" 
                                 style="width: 80px; height: 80px; object-fit: cover; cursor: pointer;">
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Product Details -->
        <div class="col-lg-6">
            <h2 class="luxury-quick-view-title"><?php echo esc_html($product->get_name()); ?></h2>

            <div class="luxury-rating mb-3">
                <?php echo wc_get_rating_html($product->get_average_rating()); ?>
                <a href="<?php echo get_permalink($product->get_id()); ?>#reviews" class="luxury-review-link" rel="nofollow">
                    (<?php printf(_n('%s review', '%s reviews', $product->get_review_count(), 'woocommerce'), '<span class="count">' . esc_html($product->get_review_count()) . '</span>'); ?>)
                </a>
            </div>

            <div class="luxury-price-container mb-3">
                <?php wc_get_template('single-product/price.php'); ?>
            </div>

            <div class="luxury-description mb-4">
                <?php echo wp_kses_post($product->get_short_description()); ?>
            </div>

            <?php if ($product->is_in_stock()) : ?>
                <?php if ($product->is_type('simple')) : ?>
                    <div class="luxury-add-to-cart-buttons">
                        <button type="button" class="btn-main-action" data-product_id="<?php echo esc_attr($product->get_id()); ?>" data-product_type="simple" data-nonce="<?php echo esc_attr(wp_create_nonce('woocommerce-add-to-cart')); ?>">
                            <i class="fas fa-shopping-cart me-2"></i>
                            <?php echo esc_html($product->single_add_to_cart_text()); ?>
                        </button>
                        <button type="button" class="btn-main-action" data-product_id="<?php echo esc_attr($product->get_id()); ?>" data-product_type="simple" data-nonce="<?php echo esc_attr(wp_create_nonce('woocommerce-add-to-cart')); ?>">
                            <i class="fas fa-bolt me-2"></i>
                            <?php esc_html_e('Buy Now', 'zayxyz'); ?>
                        </button>
                    </div>
                <?php elseif ($product->is_type('variable')) : ?>
                    <a href="<?php echo esc_url($product->get_permalink()); ?>" class="btn-main-action">
                        <i class="fas fa-cog me-2"></i>
                        <?php esc_html_e('Select Options', 'zayxyz'); ?>
                    </a>
                    <a href="<?php echo esc_url($product->get_permalink()); ?>" class="btn-main-action">
                        <i class="fas fa-bolt me-2"></i>
                        <?php esc_html_e('Buy Now', 'zayxyz'); ?>
                    </a>
                <?php endif; ?>
            <?php else : ?>
                <div class="luxury-alert">
                    <?php echo esc_html__('This product is currently out of stock and unavailable.', 'woocommerce'); ?>
                </div>
            <?php endif; ?>

            <div class="mt-4">
                <a href="<?php echo esc_url($product->get_permalink()); ?>" class="luxury-view-details-btn">
                    <?php esc_html_e('View Full Details', 'codevers2e'); ?>
                </a>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Quick view thumbnail click
    $('.luxury-thumbnail').on('click', function() {
        var fullImage = $(this).data('full-image');
        $('.luxury-quick-view-main-image').attr('src', fullImage);
    });
});
</script>