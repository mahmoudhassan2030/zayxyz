<?php
/**
 * Single Product Price
 */

defined('ABSPATH') || exit;

global $product;
?>

<div class="product-price-container">
    <?php if ($product->is_type('variable')): ?>
        <div class="variable-price-wrapper">
            <?php
            $variation_prices = $product->get_variation_prices();
            $min_price = current($variation_prices['price']);
            $max_price = end($variation_prices['price']);
            
            if ($min_price !== $max_price) {
                echo wc_price($min_price) . ' - ' . wc_price($max_price);
            } else {
                echo wc_price($min_price);
            }
            ?>
        </div>
    <?php elseif ($product->is_on_sale()): ?>
        <div class="price-wrapper">
            <span class="regular-price">
                <del><?php echo wc_price($product->get_regular_price()); ?></del>
            </span>
            <span class="sale-price">
                <?php echo wc_price($product->get_sale_price()); ?>
            </span>
        </div>
    <?php else: ?>
        <div class="simple-price-wrapper">
            <span class="current-price">
                <?php echo $product->get_price_html(); ?>
            </span>
        </div>
    <?php endif; ?>
    
    <?php if ($product->is_in_stock()): ?>
        <div class="stock-status in-stock">
            <i class="fas fa-check-circle"></i>
            <span>In Stock</span>
        </div>
    <?php else: ?>
        <div class="stock-status out-of-stock">
            <i class="fas fa-times-circle"></i>
            <span>Out of stock</span>
        </div>
    <?php endif; ?>
</div>