<?php
/**
 * Single Product tabs
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.8.0
 */

if (!defined('ABSPATH')) {
    exit;
}

$product_tabs = apply_filters('woocommerce_product_tabs', array());

if (!empty($product_tabs)) : ?>
    <div class="product-tabs-wrapper">
        <div class="product-tabs-header">
            <ul class="nav nav-tabs" role="tablist">
                <?php foreach ($product_tabs as $key => $product_tab) : 
                    $active_class = $key === 'description' ? 'active' : '';
                    $icon = '';
                    
                    // Add icons based on tab type
                    switch($key) {
                        case 'description':
                            $icon = '<i class="fas fa-file-alt me-2"></i>';
                            break;
                        case 'reviews':
                            $icon = '<i class="fas fa-star me-2"></i>';
                            break;
                        case 'additional_information':
                            $icon = '<i class="fas fa-info-circle me-2"></i>';
                            break;
                    }
                ?>
                    <li class="nav-item" role="presentation">
                        <button 
                            class="nav-link <?php echo esc_attr($active_class); ?>" 
                            id="tab-<?php echo esc_attr($key); ?>-tab" 
                            data-bs-toggle="tab" 
                            data-bs-target="#tab-<?php echo esc_attr($key); ?>" 
                            type="button" 
                            role="tab" 
                            aria-controls="tab-<?php echo esc_attr($key); ?>"
                            aria-selected="<?php echo $key === 'description' ? 'true' : 'false'; ?>"
                        >
                            <?php echo $icon . wp_kses_post(apply_filters('woocommerce_product_' . $key . '_tab_title', $product_tab['title'], $key)); ?>
                        </button>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="tab-content py-4">
            <?php foreach ($product_tabs as $key => $product_tab) : 
                $active_class = $key === 'description' ? 'show active' : '';
            ?>
                <div 
                    class="tab-pane fade <?php echo esc_attr($active_class); ?>" 
                    id="tab-<?php echo esc_attr($key); ?>" 
                    role="tabpanel" 
                    aria-labelledby="tab-<?php echo esc_attr($key); ?>-tab"
                >
                    <div class="tab-content-inner">
                        <?php 
                        if (isset($product_tab['callback'])) {
                            call_user_func($product_tab['callback'], $key, $product_tab);
                        }
                        ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php do_action('woocommerce_product_after_tabs'); ?>
<?php endif; ?>
