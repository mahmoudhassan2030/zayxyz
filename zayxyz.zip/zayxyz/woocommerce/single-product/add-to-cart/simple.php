<?php
/**
 * Simple product add to cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/add-to-cart/simple.php.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.4.0
 */
if (!defined('ABSPATH')) {
    exit;
}
global $product;
if (!$product->is_purchasable()) {
    return;
}
?>
<div class="luxury-add-to-cart-flex">
    <form class="cart" action="<?php echo esc_url(apply_filters('woocommerce_add_to_cart_form_action', $product->get_permalink())); ?>" method="post" enctype='multipart/form-data'>
        <div class="luxury-quantity-label">
            <span><?php esc_html_e('Quantity', 'zayxyz'); ?></span>
            <?php
            do_action('woocommerce_before_add_to_cart_quantity');
            woocommerce_quantity_input(array(), $product, true);
            do_action('woocommerce_after_add_to_cart_quantity');
            ?>
        </div>
        <div class="luxury-add-to-cart-buttons">
            <button type="submit" name="add-to-cart" value="<?php echo esc_attr($product->get_id()); ?>" class="add-to-cart-btn single_add_to_cart_button button alt" data-product_id="<?php echo esc_attr($product->get_id()); ?>" data-product_type="simple" data-nonce="<?php echo esc_attr(wp_create_nonce('woocommerce-add-to-cart')); ?>">
                <i class="fas fa-shopping-cart me-2"></i>
                <?php echo esc_html($product->single_add_to_cart_text()); ?>
            </button>
            <button type="button" class="buy-now-btn buy-now-button button alt" data-product_id="<?php echo esc_attr($product->get_id()); ?>" data-product_type="simple" data-nonce="<?php echo esc_attr(wp_create_nonce('woocommerce-add-to-cart')); ?>">
                <i class="fas fa-bolt me-2"></i>
                <?php esc_html_e('Buy Now', 'zayxyz'); ?>
            </button>
        </div>
    </form>
</div> 