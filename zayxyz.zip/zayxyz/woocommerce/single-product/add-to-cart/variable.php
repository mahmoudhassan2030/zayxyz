<?php
/**
 * Variable product add to cart
 */

defined('ABSPATH') || exit;

global $product;

$attribute_keys = array_keys($attributes);
$variations_json = wp_json_encode($available_variations);
$variations_attr = function_exists('wc_esc_json') ? wc_esc_json($variations_json) : _wp_specialchars($variations_json, ENT_QUOTES, 'UTF-8', true);



/**
 * Variable product add to cart
 */
defined('ABSPATH') || exit;

global $product;

$attribute_keys = array_keys($attributes);
$variations_json = wp_json_encode($available_variations);
$variations_attr = function_exists('wc_esc_json') ? wc_esc_json($variations_json) : _wp_specialchars($variations_json, ENT_QUOTES, 'UTF-8', true);

do_action('woocommerce_before_add_to_cart_form');
?>

<form class="variations_form cart" action="<?php echo esc_url(apply_filters('woocommerce_add_to_cart_form_action', $product->get_permalink())); ?>" method="post" enctype='multipart/form-data' data-product_id="<?php echo absint($product->get_id()); ?>" data-product_variations="<?php echo $variations_attr; ?>">
    <?php do_action('woocommerce_before_variations_form'); ?>

    <?php if (empty($available_variations) && false !== $available_variations) : ?>
        <p class="stock out-of-stock"><?php echo esc_html(apply_filters('woocommerce_out_of_stock_message', __('This product is currently out of stock and unavailable.', 'woocommerce'))); ?></p>
    <?php else : ?>
        <div class="luxury-variations">
            <?php foreach ($attributes as $attribute_name => $options) : ?>
                <div class="luxury-variation-group">
                    <label class="luxury-variation-label" for="<?php echo esc_attr(sanitize_title($attribute_name)); ?>">
                        <?php echo wc_attribute_label($attribute_name); ?>
                    </label>
                    <div class="luxury-variation-options" data-attribute_name="attribute_<?php echo esc_attr(sanitize_title($attribute_name)); ?>">
                        <?php
                        $selected = isset($_REQUEST['attribute_' . sanitize_title($attribute_name)]) ? wc_clean(wp_unslash($_REQUEST['attribute_' . sanitize_title($attribute_name)])) : $product->get_variation_default_attribute($attribute_name);
                        foreach ($options as $option) :
                            $option_value = esc_attr($option);
                            $option_label = esc_html(apply_filters('woocommerce_variation_option_name', $option));
                            $is_selected = $selected === $option_value ? 'selected' : '';
                            echo '<button type="button" class="luxury-variation-box ' . $is_selected . '" data-value="' . $option_value . '">' . $option_label . '</button>';
                        endforeach;
                        // إضافة حقل مخفي لتخزين القيمة المختارة
                        echo '<input type="hidden" name="attribute_' . esc_attr(sanitize_title($attribute_name)) . '" value="' . esc_attr($selected) . '" />';
                        ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- ترتيب الأزرار والعداد بشكل عصري -->
        <div class="luxury-add-to-cart-flex">
            <div class="luxury-add-to-cart-buttons">
                <button type="submit" class="add-to-cart-btn single_add_to_cart_button button alt" data-product_id="<?php echo esc_attr($product->get_id()); ?>" data-product_type="variable" data-nonce="<?php echo esc_attr(wp_create_nonce('woocommerce-add-to-cart')); ?>">
                    <i class="fas fa-shopping-cart me-2"></i>
                    <?php echo esc_html($product->single_add_to_cart_text()); ?>
                </button>
                <button type="button" class="buy-now-btn buy-now-button button" data-product_id="<?php echo esc_attr($product->get_id()); ?>" data-product_type="variable" data-nonce="<?php echo esc_attr(wp_create_nonce('woocommerce-add-to-cart')); ?>">
                    <i class="fas fa-bolt me-2"></i>
                    <?php esc_html_e('Buy Now', 'zayxyz'); ?>
                </button>
            </div>
            <div class="luxury-quantity-label">
                <span>Quantity</span>
                <div class="quantity">
                    <?php do_action('woocommerce_before_add_to_cart_quantity'); ?>
                    <label class="screen-reader-text" for="quantity"><?php _e('Quantity', 'woocommerce'); ?></label>
                    <input type="number" id="quantity" class="input-text qty text" step="1" min="1" max="<?php echo esc_attr($product->get_max_purchase_quantity()); ?>" name="quantity" value="1" title="<?php _e('Qty', 'woocommerce'); ?>" size="4" inputmode="numeric" />
                    <?php do_action('woocommerce_after_add_to_cart_quantity'); ?>
                </div>
            </div>
        </div>

        <input type="hidden" name="add-to-cart" value="<?php echo absint($product->get_id()); ?>" />
        <input type="hidden" name="product_id" value="<?php echo absint($product->get_id()); ?>" />
        <input type="hidden" name="variation_id" class="variation_id" value="0" />

        <?php
        do_action('woocommerce_before_single_variation');
        do_action('woocommerce_single_variation');
        do_action('woocommerce_after_single_variation');
        ?>
    <?php endif; ?>

    <?php do_action('woocommerce_after_variations_form'); ?>
</form>


<!-- Trust Badges -->
<div class="luxury-trust-badges">
    <div class="trust-badge">
        <i class="fas fa-shield-alt"></i>
        <span><?php _e('Authentic Quality', 'zayxyz'); ?></span>
    </div>
    <div class="trust-badge">
        <i class="fas fa-truck"></i>
        <span><?php _e('Free Shipping', 'zayxyz'); ?></span>
    </div>
    <div class="trust-badge">
        <i class="fas fa-undo"></i>
        <span><?php _e('Easy Returns', 'zayxyz'); ?></span>
    </div>
</div>
</div>

<?php
do_action('woocommerce_after_add_to_cart_form');
