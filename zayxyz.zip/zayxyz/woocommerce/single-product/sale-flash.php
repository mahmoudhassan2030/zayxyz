<?php
/**
 * Display product sale flash
 */

defined('ABSPATH') || exit;

global $post, $product;

if (!$product->is_on_sale()) {
    return;
}

$regular_price = $product->get_regular_price();
$sale_price = $product->get_sale_price();

if ($regular_price && $sale_price) {
    $percentage = round((($regular_price - $sale_price) / $regular_price) * 100);
} else {
    $percentage = 0;
}
?>

<div class="product-sale-badge">
    <?php if ($percentage > 0): ?>
        <span class="sale-percentage">-<?php echo $percentage; ?>%</span>
    <?php endif; ?>
    <span class="sale-label">خصم</span>
</div> 