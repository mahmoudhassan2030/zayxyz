<?php
/**
 * Related Products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/related.php.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     3.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $related_products ) : ?>

	<section class="related products py-5">
		<div class="container">
			<?php
			$heading = apply_filters( 'woocommerce_product_related_products_heading', get_theme_mod('related_products_heading', __( 'Related products', 'zayxyz' )) );

			if ( $heading ) :
				?>
				<div class="row">
					<div class="col-12">
						<h2 class="text-center mb-5"><?php echo esc_html( $heading ); ?></h2>
					</div>
				</div>
			<?php endif; ?>

			<div class="related-products-slider position-relative">
				<div class="slick-slider-wrapper">
					<div class="products-slick">
						<?php foreach ( $related_products as $related_product ) : ?>
							<div class="px-2">
								<?php
								$post_object = get_post( $related_product->get_id() );
								setup_postdata( $GLOBALS['post'] =& $post_object );
								wc_get_template_part( 'content', 'product' );
								?>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php
endif;

wp_reset_postdata(); 