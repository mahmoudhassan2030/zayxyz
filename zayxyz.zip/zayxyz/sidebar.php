<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage codevers2e
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	// إذا لم تكن هناك ودجات مفعلة، لا تعرض الشريط الجانبي
	return;
}
?>

<aside id="secondary" class="widget-area">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- #secondary -->